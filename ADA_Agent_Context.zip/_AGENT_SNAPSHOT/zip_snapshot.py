import os
import zipfile
from pathlib import Path

def is_excluded(path_str):
    excludes = ['.git', '.venv', 'venv', 'node_modules', '__pycache__', '.pytest_cache', 'full_pipeline_runs']
    for ex in excludes:
        if f"\\{ex}\\" in path_str or f"/{ex}/" in path_str or path_str.endswith(f"\\{ex}") or path_str.endswith(f"/{ex}"):
            return True
    
    # Exclude large file extensions
    ext = Path(path_str).suffix.lower()
    if ext in ['.gguf', '.safetensors', '.ckpt', '.pt', '.bin', '.pth', '.mp4', '.avi', '.mkv', '.png', '.jpg', '.jpeg', '.webp', '.avif']:
        return True
    return False

def add_dir_to_zip(zipf, dir_path, base_dir, max_size=5*1024*1024):
    p = Path(dir_path)
    if not p.exists():
        return
    for root, dirs, files in os.walk(p):
        for d in list(dirs):
            if is_excluded(os.path.join(root, d)):
                dirs.remove(d)
        for f in files:
            file_path = os.path.join(root, f)
            if is_excluded(file_path):
                continue
            try:
                if os.path.getsize(file_path) > max_size:
                    continue
                arcname = os.path.relpath(file_path, base_dir)
                zipf.write(file_path, arcname)
            except Exception as e:
                print(f"Failed to add {file_path}: {e}")

def main():
    repo_dir = Path("D:/IA/Ada")
    out_zip = Path("D:/IA/ADA_Agent_Context.zip")
    
    # Pre-calculate manifest info
    total_files = 0
    total_size = 0
    included_files = []
    
    # We will just write the manifest before zipping
    manifest_path = repo_dir / "_AGENT_SNAPSHOT" / "SNAPSHOT_MANIFEST.txt"
    
    def count_dir(dir_path):
        nonlocal total_files, total_size
        p = Path(dir_path)
        if not p.exists(): return
        for root, dirs, files in os.walk(p):
            for d in list(dirs):
                if is_excluded(os.path.join(root, d)):
                    dirs.remove(d)
            for f in files:
                file_path = os.path.join(root, f)
                if is_excluded(file_path): continue
                if os.path.getsize(file_path) > 5*1024*1024: continue
                total_files += 1
                total_size += os.path.getsize(file_path)
                included_files.append(file_path)

    count_dir(repo_dir / "ada_app")
    count_dir(repo_dir / "config")
    count_dir(repo_dir / "schemas")
    count_dir(repo_dir / "tests")
    count_dir(repo_dir / "workflows/production")
    count_dir(repo_dir / "workflows/legacy")
    count_dir(repo_dir / "docs")
    
    # also add docs in root and ada.py
    for md_file in repo_dir.glob("*.md"):
        if not is_excluded(str(md_file)):
            total_files += 1
            total_size += os.path.getsize(md_file)
            included_files.append(str(md_file))
    if (repo_dir / "ada.py").exists():
        total_files += 1
        total_size += os.path.getsize(repo_dir / "ada.py")
        included_files.append(str(repo_dir / "ada.py"))
        
    count_dir(repo_dir / "_AGENT_SNAPSHOT")

    # get git info
    import subprocess
    commit_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo_dir).decode().strip()
    branch = subprocess.check_output(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo_dir).decode().strip()

    manifest_content = f"""Total files: {total_files}
Total uncompressed size: {total_size} bytes
HEAD commit: {commit_head}
Branch: {branch}

Included main folders: ada_app, config, schemas, tests, workflows/production, workflows/legacy, docs, _AGENT_SNAPSHOT
Exclusions: .git, .venv, caches, heavy media (png, jpg, mp4...), models, >5MB files
"""
    with open(manifest_path, "w", encoding="utf-8") as f:
        f.write(manifest_content)

    # Now we zip
    with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Add main code and configs
        add_dir_to_zip(zipf, repo_dir / "ada_app", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "config", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "schemas", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "tests", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "workflows/production", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "workflows/legacy", repo_dir)
        add_dir_to_zip(zipf, repo_dir / "_AGENT_SNAPSHOT", repo_dir)
        
        # Add root files
        if (repo_dir / "ada.py").exists():
            zipf.write(repo_dir / "ada.py", "ada.py")
        
        # Add docs
        for md_file in repo_dir.glob("*.md"):
            if not is_excluded(str(md_file)):
                zipf.write(md_file, md_file.name)
        add_dir_to_zip(zipf, repo_dir / "docs", repo_dir)
    
    # append zip size to manifest and re-zip just that file
    zip_size = os.path.getsize(out_zip)
    with open(manifest_path, "a", encoding="utf-8") as f:
        f.write(f"Zip size: {zip_size} bytes\n")
        
    with zipfile.ZipFile(out_zip, 'a', zipfile.ZIP_DEFLATED) as zipf:
        zipf.write(manifest_path, "_AGENT_SNAPSHOT/SNAPSHOT_MANIFEST.txt")

if __name__ == "__main__":
    main()

