"""Shared short-timeout lock for interactive GPU operations."""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import filelock

from scripts.ada_paths import LOCKS_ROOT

GPU_LOCK_PATH = LOCKS_ROOT / "gpu_execution.lock"


@contextmanager
def gpu_execution_lock(timeout: float = 45) -> Iterator[None]:
    """Acquire the process-wide GPU lock, failing promptly when it is busy."""
    LOCKS_ROOT.mkdir(parents=True, exist_ok=True)
    lock = filelock.FileLock(str(GPU_LOCK_PATH))
    with lock.acquire(timeout=timeout):
        yield

