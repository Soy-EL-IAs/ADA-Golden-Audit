import json
from pathlib import Path
from typing import Any
from ada_app.atomic_io import atomic_write_text

def read_json(p: Path) -> Any:
    return json.loads(p.read_text(encoding="utf-8"))

def write_json(p: Path, v: Any) -> None:
    atomic_write_text(p, json.dumps(v, ensure_ascii=False, indent=2) + "\n")

def registered_character(name: str) -> dict[str, Any]:
    from scripts.ada_paths import CHARACTERS_ROOT
    path = CHARACTERS_ROOT / "catalog.json"
    if not path.exists():
        return {}
    registry = read_json(path)
    if not isinstance(registry, dict):
        return {}
    exact = registry.get(name)
    if isinstance(exact, dict):
        return exact
    folded = name.casefold()
    return next((value for key, value in registry.items() if key.casefold() == folded and isinstance(value, dict)), {})

def registered_character_contract(entry: dict[str, Any]) -> dict[str, Any] | None:
    from pathlib import Path
    from scripts.ada_paths import ADA_ROOT
    from scripts.json_schema_validator import validate_contract
    relative = entry.get("character_contract")
    if not isinstance(relative, str) or not relative.strip():
        return None
    path = Path(relative)
    if not path.is_absolute():
        path = ADA_ROOT / path
    if not path.is_file():
        return None
    value = read_json(path)
    if not isinstance(value, dict):
        return None
    return validate_contract("character_contract_v1", value)
