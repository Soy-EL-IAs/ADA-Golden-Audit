import json, time, threading, traceback, subprocess, logging
from pathlib import Path
from datetime import datetime
from typing import List

import sys
from scripts.ada_paths import ADA_ROOT, CHARACTERS_ROOT, LOCKS_ROOT, MISSION_RUNS_ROOT
sys.path.insert(0, str(ADA_ROOT / "scripts"))

from ada_app.mission import ProductionMission, MissionStore
from ada_app.utils import read_json, write_json
from ada_app.renderer_pipeline import run_renderer_pipeline
from ada_app.m3_filter import run_m3_analysis
from ada_app.m4_selection import select_top_candidates
from ada_app.m2_config import build_runtime_m2_config, load_m2_template

RUNS_DIR = MISSION_RUNS_ROOT
M2_SCRIPT = ADA_ROOT / "experimental" / "m1_creative_expansion_lab" / "run_m2.py"
M2_CONFIG_TEMPLATE = ADA_ROOT / "experimental" / "m1_creative_expansion_lab" / "m2_config.json"
CHARACTERS_CONFIG = CHARACTERS_ROOT / "catalog.json"
_MISSION_START_LOCK = threading.Lock()
logger = logging.getLogger(__name__)


def character_version(character: str) -> str:
    characters = read_json(CHARACTERS_CONFIG)
    entry = characters.get(character)
    if not isinstance(entry, dict):
        raise ValueError(f"Character is not registered: {character}")
    version = entry.get("version") or entry.get("universe")
    if not isinstance(version, str) or not version.strip():
        raise ValueError(f"Registered character has no version or universe: {character}")
    return version.strip()


def m2_failure_detail(run_dir: Path, completed: subprocess.CompletedProcess) -> dict:
    """Return the durable M2 error, including child-process diagnostics."""
    failure_path = run_dir / "failure.json"
    failure = {}
    if failure_path.is_file():
        try:
            failure = json.loads(failure_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            failure = {}
    return {
        "stage": "GENERATING_CONCEPTS",
        "run_id": run_dir.name,
        "exit_code": completed.returncode,
        "error_type": failure.get("error_type", "M2ProcessError"),
        "message": failure.get("error") or completed.stderr.strip() or "M2 exited without an error artifact.",
        "stderr": completed.stderr.strip(),
        "stdout": completed.stdout.strip(),
    }


def m2_missing_manifest_detail(run_dir: Path, completed: subprocess.CompletedProcess) -> dict:
    """Describe a successful child exit that did not publish its expected manifest."""
    manifest_path = run_dir / "manifest.json"
    return {
        "stage": "GENERATING_CONCEPTS",
        "run_id": run_dir.name,
        "exit_code": completed.returncode,
        "error_type": "M2ManifestMissing",
        "message": f"Explicit M2 run did not complete: {run_dir}",
        "expected_manifest": str(manifest_path),
        "stderr": completed.stderr.strip(),
        "stdout": completed.stdout.strip(),
    }


def _refresh_library_index(mission: ProductionMission) -> str | None:
    """Rebuild the Library without masking the mission's primary outcome."""
    try:
        from ada_app.asset_library import AssetLibrary
        AssetLibrary().build_index()
        return None
    except Exception as exc:
        logger.exception("Mission runner failure")
        mission.failure_details = list(getattr(mission, "failure_details", [])) + [{
            "stage": "LIBRARY_INDEX",
            "error_type": type(exc).__name__,
            "message": str(exc),
        }]
        return f"Library index update failed: {exc}"


def _reconcile_candidate_totals(mission: ProductionMission) -> None:
    """Rebuild counters from durable candidate files without double counting."""
    candidates: list[dict] = []
    for run_id in getattr(mission, "source_runs", []):
        path = RUNS_DIR / run_id / "pilot_candidates.json"
        if not path.is_file():
            continue
        value = read_json(path)
        if isinstance(value, list):
            candidates.extend(item for item in value if isinstance(item, dict))
    mission.selected_candidates = len(candidates)
    mission.approved_assets = sum(item.get("pipeline_state") == "APPROVED" for item in candidates)
    mission.rejected_quality = sum(item.get("pipeline_state") == "REJECTED_QUALITY" for item in candidates)
    mission.retry_exhausted = sum(item.get("pipeline_state") == "RETRY_EXHAUSTED" for item in candidates)
    mission.failed_runtime = sum(item.get("pipeline_state") in {"FAILED_RUNTIME", "SETUP_FAILURE", "CONTRACT_FAILURE", "REVIEW_FAILED"} for item in candidates)


def _recover_last_renderer_run(mission_id: str, store: MissionStore, mission: ProductionMission) -> bool:
    """Resume durable candidates from the latest run before generating anew."""
    if not getattr(mission, "source_runs", []):
        return False
    run_dir = RUNS_DIR / mission.source_runs[-1]
    candidates_path = run_dir / "pilot_candidates.json"
    if not candidates_path.is_file():
        return False
    try:
        candidates = read_json(candidates_path)
        if not isinstance(candidates, list):
            raise ValueError("pilot_candidates.json root must be an array")
    except Exception as exc:
        mission.failure_details = list(getattr(mission, "failure_details", [])) + [{
            "stage": "MISSION_RECOVERY",
            "error_type": type(exc).__name__,
            "message": f"Could not reuse {candidates_path}: {exc}",
        }]
        return False

    recoverable_states = {"PENDING", "RENDERED_PENDING_REVIEW", "REVIEW_FAILED", "FAILED_RUNTIME"}
    recoverable = [item for item in candidates if isinstance(item, dict) and item.get("pipeline_state") in recoverable_states]
    _reconcile_candidate_totals(mission)
    if not recoverable or mission.is_target_met:
        return False

    store.update(
        mission,
        status="PRODUCING",
        approved_assets=mission.approved_assets,
        selected_candidates=mission.selected_candidates,
        active_candidates=len(recoverable),
        current_stage_detail=f"Recovering {len(recoverable)} candidates from {run_dir.name}...",
    )
    renderer_choice = getattr(
        mission,
        "renderer_choice",
        "miaomiao" if bool(getattr(mission, "generate_miaomiao_alternative", False)) else "lustify",
    )
    run_renderer_pipeline(
        run_dir,
        recoverable,
        target_approvals=max(0, mission.requested_assets - mission.approved_assets),
        renderer_choice=renderer_choice,
        render_intent=getattr(mission, "render_intent", "semi_realistic"),
        continue_on_error=True,
        should_cancel=lambda: bool((store.load(mission_id) or mission).cancelled),
    )
    _reconcile_candidate_totals(mission)
    mission.active_candidates = 0
    store.update(
        mission,
        approved_assets=mission.approved_assets,
        rejected_quality=mission.rejected_quality,
        retry_exhausted=mission.retry_exhausted,
        failed_runtime=mission.failed_runtime,
        selected_candidates=mission.selected_candidates,
        active_candidates=0,
        current_stage_detail=f"Recovered {run_dir.name}: {mission.approved_assets}/{mission.requested_assets} approved",
    )
    return True


def run_stock_mission(mission: ProductionMission, store: MissionStore) -> None:
    """Run Stock directly from Character Contract to renderer; no M1/M2/M3/M4."""
    run_id = f"m2_stock_{mission.mission_id}_{datetime.now().strftime('%H%M%S%f')}"
    run_dir = RUNS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    started_at = datetime.now().isoformat()
    manifest = {
        "run_id": run_id,
        "started_at": started_at,
        "status": "RUNNING",
        "character": mission.character,
        "creation_mode": "stock",
        "stock_policy_version": "stock_v1",
        "creative_expansion_model": "none_stock_direct",
    }
    write_json(run_dir / "manifest.json", manifest)
    write_json(run_dir / "character_profile.json", {"requested_character": mission.character})
    target_accepted = mission.requested_assets
    max_attempts = target_accepted * 3  # Configurable limit
    attempted = 0
    accepted = 0
    rejected = 0
    
    candidates_file = run_dir / "pilot_candidates.json"
    
    mission.source_runs.append(run_id)
    mission.current_round = 1
    store.update(
        mission,
        status="PRODUCING",
        source_runs=list(mission.source_runs),
        current_round=mission.current_round,
        current_stage_detail=f"Producing Stock image(s) [0/{target_accepted}]...",
    )
    
    while accepted < target_accepted and attempted < max_attempts:
        concept_id = f"stock_{(attempted + 1):03d}"
        candidate = {
            "concept_id": concept_id,
            "pipeline_state": "PENDING",
            "character": mission.character,
            "source_mission_id": mission.mission_id,
            "pipeline_id": getattr(mission, "pipeline_id", "ada_mission_direct_v1"),
            "creation_mode": "stock",
            "stock_policy_version": "stock_v1",
            "renderer_routing": getattr(mission, "renderer_routing", {}),
            "original_proposal": {},
            "generation_mode": "stock",
        }
        
        if candidates_file.exists():
            durable_candidates = read_json(candidates_file)
        else:
            durable_candidates = []
            
        durable_candidates.append(candidate)
        write_json(candidates_file, durable_candidates)
        
        run_renderer_pipeline(
            run_dir, [candidate], target_approvals=1,
            renderer_choice=mission.renderer_choice, render_intent=mission.render_intent,
            creation_mode="stock", outfit_override=getattr(mission, "outfit_override", None),
            renderer_routing=getattr(mission, "renderer_routing", {}), continue_on_error=True,
            should_cancel=lambda: bool((store.load(mission.mission_id) or mission).cancelled),
        )

        latest = store.load(mission.mission_id)
        if latest is not None and latest.cancelled:
            manifest.update({"status": "CANCELLED", "completed_at": datetime.now().isoformat()})
            write_json(run_dir / "manifest.json", manifest)
            store.update(
                latest,
                status="CANCELLED",
                completed_at=datetime.now().isoformat(),
                current_stage_detail="Stock mission cancelled after the current candidate.",
            )
            return
        
        # Re-read candidate state and reconcile counters from durable truth
        refreshed_candidates = read_json(candidates_file)
        attempted = len(refreshed_candidates)
        accepted = sum(1 for c in refreshed_candidates if c.get("pipeline_state") == "APPROVED")
        rejected = sum(1 for c in refreshed_candidates if c.get("pipeline_state") not in {"APPROVED", "PENDING"})
            
        store.update(mission, current_stage_detail=f"Producing Stock image(s) [{accepted}/{target_accepted}]... (Attempt {attempted})")

    final_candidates = read_json(run_dir / "pilot_candidates.json")
    mission.selected_candidates = attempted
    mission.approved_assets = accepted
    mission.rejected_quality = sum(1 for item in final_candidates if item.get("pipeline_state") in {"REVIEW_FAILED", "REJECTED_QUALITY"})
    mission.failed_runtime = sum(1 for item in final_candidates if item.get("pipeline_state") in {"FAILED_RUNTIME", "CONTRACT_FAILURE", "SETUP_FAILURE"})
    mission.active_candidates = 0
    
    final_status = "COMPLETE" if accepted >= target_accepted else "PARTIAL" if accepted > 0 else "FAILED"
    manifest.update({
        "status": final_status, 
        "completed_at": datetime.now().isoformat(), 
        "final_assets_count": accepted,
        "requested": target_accepted,
        "attempted": attempted,
        "accepted": accepted,
        "rejected": rejected
    })
    write_json(run_dir / "manifest.json", manifest)
    try:
        from ada_app.asset_library import AssetLibrary
        from ada_app.character_capabilities import save_character_hero
        library = AssetLibrary()
        library.build_index()
        if mission.approved_assets:
            stock_assets = [
                asset for asset in library.get_assets(mission_id=mission.mission_id)
                if asset.get("creation_mode") == "stock"
                and asset.get("is_visible_library_asset") is True
                and asset.get("is_final_selection")
            ]
            if stock_assets:
                hero = max(stock_assets, key=lambda asset: asset.get("generated_at") or asset.get("created_at") or "")
                save_character_hero(mission.character, hero["asset_id"])
    except Exception:
        logger.exception("Mission runner failure")
    store.update(
        mission, status=final_status, completed_at=datetime.now().isoformat(),
        selected_candidates=mission.selected_candidates,
        approved_assets=mission.approved_assets,
        rejected_quality=mission.rejected_quality,
        failed_runtime=mission.failed_runtime,
        active_candidates=mission.active_candidates,
        current_stage_detail=f"Stock {final_status}: {mission.approved_assets}/{mission.requested_assets} approved",
    )

def run_mission(mission_id: str):
    store = MissionStore()
    mission = store.load(mission_id)
    if not mission:
        return

    if getattr(mission, "pipeline_id", "ada_mission_direct_v1") != "ada_mission_direct_v1":
        store.update(mission, status="FAILED", error_message=f"Unsupported pipeline: {getattr(mission, 'pipeline_id')}", completed_at=datetime.now().isoformat())
        return

    try:
        try:
            import filelock
        except ImportError as exc:
            raise RuntimeError(
                "filelock no est\u00e1 instalado; ejecute "
                "'python -m pip install -r requirements.txt'."
            ) from exc

        LOCKS_ROOT.mkdir(parents=True, exist_ok=True)
        lock = filelock.FileLock(str(LOCKS_ROOT / "gpu_execution.lock"))

        store.update(mission, status="WAITING_FOR_GPU", current_stage_detail="Waiting for GPU lock...")
        with lock.acquire(timeout=86400):
            mission.started_at = mission.started_at or datetime.now().isoformat()
            store.update(
                mission,
                status="RUNNING",
                started_at=mission.started_at,
                current_stage_detail="Acquired GPU lock, starting...",
            )
            _run_mission_internal(mission_id, store, mission)
    except Exception as e:
        logger.exception("Mission runner failure")
        store.update(mission, status="FAILED", error_message=str(e), completed_at=datetime.now().isoformat())

def _run_mission_internal(mission_id: str, store: MissionStore, mission: ProductionMission):
    try:
        if getattr(mission, "creation_mode", "scene") == "stock":
            run_stock_mission(mission, store)
            return
        _recover_last_renderer_run(mission_id, store, mission)
        latest = store.load(mission_id)
        if latest is not None and latest.cancelled:
            store.update(latest, status="CANCELLED", completed_at=datetime.now().isoformat())
            return
        remaining_needed = mission.requested_assets - mission.approved_assets
        next_round = max(1, len(getattr(mission, "source_runs", [])) + 1)

        for round_num in range(next_round, mission.max_rounds + 1):
            if mission.cancelled:
                store.update(mission, status="CANCELLED", completed_at=datetime.now().isoformat())
                return
            
            if remaining_needed <= 0:
                break
                
            mission.current_round = round_num
            
            # --- PHASE 1: Generate Concepts ---
            store.update(mission, status="GENERATING_CONCEPTS",
                        current_round=mission.current_round,
                        current_stage_detail=f"Round {round_num}: Generating concepts...")
            
            if round_num == 1:
                concept_count = mission.initial_concepts
                candidate_count = mission.initial_candidates
            else:
                concept_count = max(12, remaining_needed * 3)
                candidate_count = remaining_needed + max(2, remaining_needed // 2)
            
            # Bind both M2 input and output to this exact run. The versioned
            # template is immutable and runtime fields are always overwritten.
            generated_run_id = (
                f"m2_{mission_id}_r{round_num:02d}_"
                f"{datetime.now().strftime('%H%M%S%f')}"
            )
            generated_run = RUNS_DIR / generated_run_id
            generated_run.mkdir(parents=True, exist_ok=False)
            config = build_runtime_m2_config(
                load_m2_template(M2_CONFIG_TEMPLATE),
                requested_count=concept_count,
                character=mission.character,
                version=character_version(mission.character),
                what_happens=getattr(mission, "what_happens", ""),
                where=getattr(mission, "where", ""),
                generation_context={
                "mode": getattr(mission, "generation_mode", "direct"),
                "source_asset_id": getattr(mission, "source_asset_id", ""),
                "source_generation_id": getattr(mission, "source_generation_id", ""),
                "alternative_mode": getattr(mission, "alternative_mode", ""),
                "alternative_instruction": getattr(mission, "alternative_instruction", ""),
                "source_context": getattr(mission, "source_context", {}),
                },
                creative_intent=getattr(mission, "creative_intent", {}),
            )
            run_config_path = generated_run / "m2_config.json"
            write_json(run_config_path, config)
            
            # Auto-load the creative model required for M2 using existing infrastructure
            try:
                from lmstudio_controller import LMStudioController
                controller = LMStudioController()
                controller.activate_role("premise_agent")
            except Exception as e:
                logger.exception("Mission runner failure")
                store.update(mission, status="FAILED", error_message=f"Failed to auto-load 9B model: {e}", completed_at=datetime.now().isoformat())
                return
            
            # Bind this subprocess to one exact run directory. Never discover its
            # result by timestamp because concurrent missions could cross-link.
            try:
                completed = subprocess.run(
                    ["python", str(M2_SCRIPT), "--run-id", generated_run_id, "--config", str(run_config_path)],
                    cwd=str(ADA_ROOT), capture_output=True, text=True, timeout=900,
                )
            except subprocess.TimeoutExpired as exc:
                store.update(
                    mission, status="FAILED",
                    error_message="M2 timed out after 900 seconds",
                    failure_details=[{"stage": "M2", "error_type": "TimeoutExpired", "message": str(exc)}],
                    completed_at=datetime.now().isoformat(),
                )
                return
            if completed.returncode:
                detail = m2_failure_detail(generated_run, completed)
                mission.failure_details = list(getattr(mission, "failure_details", [])) + [detail]
                store.update(
                    mission,
                    status="FAILED",
                    error_message=f"M2 {detail['error_type']}: {detail['message']}",
                    failure_details=mission.failure_details,
                    completed_at=datetime.now().isoformat(),
                )
                return
            if not (generated_run / "manifest.json").is_file():
                detail = m2_missing_manifest_detail(generated_run, completed)
                mission.failure_details = list(getattr(mission, "failure_details", [])) + [detail]
                store.update(
                    mission,
                    status="FAILED",
                    error_message=detail["message"],
                    failure_details=mission.failure_details,
                    completed_at=datetime.now().isoformat(),
                )
                return

            mission.source_runs.append(generated_run.name)
            
            # Read and count concepts
            records = read_json(generated_run / "proposal_records.json")
            all_records = records.get("records", [])
            mission.generated_concepts += len(all_records)
            store.update(
                mission,
                source_runs=list(mission.source_runs),
                generated_concepts=mission.generated_concepts,
                current_stage_detail=f"Round {round_num}: {len(all_records)} concepts generated. Running M3/M4...",
            )
            
            # Reload mission in case cancelled
            mission = store.load(mission_id)
            if mission.cancelled:
                store.update(mission, status="CANCELLED", completed_at=datetime.now().isoformat())
                return
            
            # --- PHASE 2: M3 + M4 ---
            m3_analysis = run_m3_analysis(all_records)
            write_json(generated_run / "m3_analysis.json", m3_analysis)
            
            candidates = select_top_candidates(all_records, m3_analysis, top_n=candidate_count)
            
            # Add mission_id to each candidate
            for c in candidates:
                c["source_mission_id"] = mission_id
                c["pipeline_id"] = getattr(mission, "pipeline_id", "ada_mission_direct_v1")
                c["source_asset_id"] = getattr(mission, "source_asset_id", "")
                c["source_generation_id"] = getattr(mission, "source_generation_id", "")
                c["generation_mode"] = getattr(mission, "generation_mode", "direct")
                c["alternative_mode"] = getattr(mission, "alternative_mode", "")
                c["alternative_instruction"] = getattr(mission, "alternative_instruction", "")
                c["source_context"] = getattr(mission, "source_context", {})
                c["creative_intent"] = getattr(mission, "creative_intent", {})
            
            write_json(generated_run / "pilot_candidates.json", candidates)
            mission.selected_candidates += len(candidates)
            
            # --- PHASE 3: Production ---
            store.update(mission, status="PRODUCING",
                        selected_candidates=mission.selected_candidates,
                        active_candidates=len(candidates),
                        current_stage_detail=f"Round {round_num}: Producing {len(candidates)} candidates...")
            
            # Run pilot pipeline synchronously within mission thread
            remaining_needed = mission.requested_assets - mission.approved_assets
            renderer_choice = getattr(
                mission,
                "renderer_choice",
                "miaomiao" if bool(getattr(mission, "generate_miaomiao_alternative", False)) else "lustify",
            )
            run_renderer_pipeline(
                generated_run,
                candidates,
                target_approvals=remaining_needed,
                renderer_choice=renderer_choice,
                render_intent=getattr(mission, "render_intent", "semi_realistic"),
                continue_on_error=True,
                should_cancel=lambda: bool((store.load(mission_id) or mission).cancelled),
            )
            
            # --- PHASE 4: Count results ---
            final_candidates = read_json(generated_run / "pilot_candidates.json")
            round_approved = sum(1 for c in final_candidates if c.get("pipeline_state") == "APPROVED")
            round_rejected = sum(1 for c in final_candidates if c.get("pipeline_state") == "REJECTED_QUALITY")
            round_exhausted = sum(1 for c in final_candidates if c.get("pipeline_state") == "RETRY_EXHAUSTED")
            failed_states = {"FAILED_RUNTIME", "SETUP_FAILURE", "CONTRACT_FAILURE", "REVIEW_FAILED"}
            round_failed = sum(1 for c in final_candidates if c.get("pipeline_state") in failed_states)
            round_failure_details = [
                detail for c in final_candidates
                if c.get("pipeline_state") in failed_states
                for detail in [c.get("failure_details")]
                if isinstance(detail, dict)
            ]
            
            _reconcile_candidate_totals(mission)
            mission.failure_details = list(getattr(mission, "failure_details", [])) + round_failure_details
            mission.active_candidates = 0
            
            remaining_needed = mission.requested_assets - mission.approved_assets
            
            store.update(
                mission,
                approved_assets=mission.approved_assets,
                rejected_quality=mission.rejected_quality,
                retry_exhausted=mission.retry_exhausted,
                failed_runtime=mission.failed_runtime,
                failure_details=mission.failure_details,
                active_candidates=mission.active_candidates,
                current_stage_detail=f"Round {round_num} complete: {round_approved} approved. Total: {mission.approved_assets}/{mission.requested_assets}",
            )

            latest = store.load(mission_id)
            if latest is not None and latest.cancelled:
                store.update(
                    latest,
                    status="CANCELLED",
                    completed_at=datetime.now().isoformat(),
                    current_stage_detail="Mission cancelled after the current candidate.",
                )
                return
            
            # Check if target met
            if mission.is_target_met:
                break
        
        # --- FINAL ---
        if mission.is_target_met:
            final_status = "COMPLETE"
        elif mission.approved_assets > 0:
            final_status = "PARTIAL"
        else:
            final_status = "FAILED"
        
        # Build before exposing a terminal mission. The Library action can then
        # deterministically query this mission's freshly indexed assets.
        index_error = _refresh_library_index(mission)
        if index_error and final_status == "COMPLETE":
            final_status = "PARTIAL"
        store.update(
            mission,
            status=final_status,
            error_message=index_error or mission.error_message,
            failure_details=mission.failure_details,
            completed_at=datetime.now().isoformat(),
            current_stage_detail=f"Mission {final_status}: {mission.approved_assets}/{mission.requested_assets} approved",
        )
        
    except Exception as e:
        logger.exception("Mission runner failure")
        index_error = _refresh_library_index(mission)
        store.update(
            mission,
            status="FAILED",
            error_message=str(e),
            failure_details=mission.failure_details,
            completed_at=datetime.now().isoformat(),
            current_stage_detail=(
                f"Mission FAILED: {e}"
                + (f" ({index_error})" if index_error else "")
            ),
        )

def is_mission_thread_alive(mission_id: str) -> bool:
    """Process-local liveness for full missions and candidate recovery workers."""
    mission_name = f"mission-{mission_id}"
    retry_prefix = f"retry-{mission_id}-"
    return any(
        thread.is_alive()
        and (thread.name == mission_name or thread.name.startswith(retry_prefix))
        for thread in threading.enumerate()
    )


def is_gpu_execution_busy() -> bool:
    """Conservatively detect work owned by another process."""
    try:
        from filelock import FileLock, Timeout
        LOCKS_ROOT.mkdir(parents=True, exist_ok=True)
        lock = FileLock(str(LOCKS_ROOT / "gpu_execution.lock"))
        with lock.acquire(timeout=0):
            return False
    except Timeout:
        return True


def start_mission_background(mission_id: str) -> bool:
    with _MISSION_START_LOCK:
        if is_mission_thread_alive(mission_id):
            return False
        thread = threading.Thread(
            target=run_mission,
            args=(mission_id,),
            name=f"mission-{mission_id}",
            daemon=True,
        )
        try:
            store = MissionStore()
            mission = store.load(mission_id)
            if mission is not None:
                store.update(mission, execution_thread_name=thread.name)
        except Exception:
            logger.exception("Could not persist mission thread marker")
        thread.start()
        return True
