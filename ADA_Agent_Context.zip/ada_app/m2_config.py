"""Immutable M2 defaults and per-run runtime configuration."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


def load_m2_template(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("M2 config template root must be an object")
    return value


def build_runtime_m2_config(
    template: dict[str, Any],
    *,
    requested_count: int,
    character: str | None = None,
    version: str | None = None,
    what_happens: str = "",
    where: str = "",
    generation_context: dict[str, Any] | None = None,
    creative_intent: dict[str, Any] | None = None,
) -> dict[str, Any]:
    config = deepcopy(template)
    config["requested_count"] = requested_count
    if character is not None:
        config["character"] = character
    if version is not None:
        config["version"] = version
    config["what_happens"] = what_happens or ""
    config["where"] = where or ""
    config["generation_context"] = deepcopy(generation_context) if isinstance(generation_context, dict) else {
        "mode": "direct",
        "source_asset_id": "",
        "source_generation_id": "",
        "alternative_mode": "",
        "alternative_instruction": "",
        "source_context": {},
    }
    config["creative_intent"] = deepcopy(creative_intent) if isinstance(creative_intent, dict) else {}
    return config
