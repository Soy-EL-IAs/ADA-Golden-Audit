"""Small, Windows-safe helpers for adjacent atomic file publication."""

from __future__ import annotations

import os
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


_STALE_TEMP_SECONDS = 60 * 60


def _cleanup_stale_temporaries(destination: Path) -> None:
    cutoff = time.time() - _STALE_TEMP_SECONDS
    for candidate in destination.parent.glob(f"{destination.name}.*.tmp"):
        try:
            if candidate.is_file() and candidate.stat().st_mtime < cutoff:
                candidate.unlink()
        except OSError:
            pass


@contextmanager
def adjacent_temporary_path(destination: Path) -> Iterator[Path]:
    """Yield a unique closed temporary file beside *destination*."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    _cleanup_stale_temporaries(destination)
    descriptor, temporary_name = tempfile.mkstemp(
        dir=destination.parent,
        prefix=f"{destination.name}.",
        suffix=".tmp",
    )
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        yield temporary
    finally:
        temporary.unlink(missing_ok=True)


def atomic_write_text(destination: Path, content: str, *, encoding: str = "utf-8") -> None:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    _cleanup_stale_temporaries(destination)
    descriptor, temporary_name = tempfile.mkstemp(
        dir=destination.parent,
        prefix=f"{destination.name}.",
        suffix=".tmp",
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding=encoding, newline="\n") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, destination)
    except Exception:
        try:
            os.close(descriptor)
        except OSError:
            pass
        raise
    finally:
        temporary.unlink(missing_ok=True)


def durable_write_text_new(destination: Path, content: str, *, encoding: str = "utf-8") -> None:
    """Create a new immutable text artifact and force its bytes to disk."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding=encoding, newline="\n") as handle:
        handle.write(content)
        handle.flush()
        os.fsync(handle.fileno())


def fsync_file(path: Path) -> None:
    """Force bytes already written to a file before it is atomically named."""
    # Windows requires a writable descriptor for _commit/os.fsync.
    with Path(path).open("r+b") as handle:
        os.fsync(handle.fileno())
