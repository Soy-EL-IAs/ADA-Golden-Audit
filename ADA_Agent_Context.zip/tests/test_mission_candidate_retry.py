from __future__ import annotations

import asyncio
import contextlib
import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import main, mission_runner, renderer_pipeline
from ada_app.mission import ProductionMission


ROOT = Path(__file__).resolve().parents[1]


class _Store:
    def __init__(self, mission: ProductionMission):
        self.mission = mission

    def load(self, _mission_id: str):
        return self.mission

    def update(self, mission: ProductionMission, **changes):
        for key, value in changes.items():
            setattr(mission, key, value)
        return mission


class _ImmediateThread:
    def __init__(self, *, target, name, daemon):
        self.target = target
        self.name = name
        self.daemon = daemon

    def start(self):
        self.target()


class MissionCandidateRetryTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"candidate-retry-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_retry_holds_gpu_lock_preserves_stock_configuration_and_clears_old_error(self) -> None:
        run_id = "stock-run"
        run_dir = self.temporary / run_id
        run_dir.mkdir()
        candidates_path = run_dir / "pilot_candidates.json"
        candidates_path.write_text(json.dumps([{
            "concept_id": "candidate-1",
            "pipeline_state": "FAILED_RUNTIME",
            "failure_details": {"message": "old failure"},
        }]), encoding="utf-8")
        (run_dir / "character_profile.json").write_text("{}", encoding="utf-8")

        mission = ProductionMission(
            mission_id="mission-retry",
            character="Test Character",
            requested_assets=1,
            creation_mode="stock",
            outfit_override="formal red dress",
            renderer_routing={"route": "identity-safe"},
        )
        mission.status = "FAILED"
        mission.source_runs = [run_id]
        mission.error_message = "old mission error"
        mission.completed_at = "2025-01-01T00:00:00"
        store = _Store(mission)
        captured = {}

        def render(_run_dir, _candidates, **kwargs):
            captured.update(kwargs)
            durable = json.loads(candidates_path.read_text(encoding="utf-8"))
            durable[0]["pipeline_state"] = "APPROVED"
            candidates_path.write_text(json.dumps(durable), encoding="utf-8")

        with patch("ada_app.mission.MissionStore", return_value=store), \
                patch.object(main, "RUNS_DIR", self.temporary), \
                patch.object(mission_runner, "RUNS_DIR", self.temporary), \
                patch.object(mission_runner, "is_mission_thread_alive", return_value=False), \
                patch.object(mission_runner, "is_gpu_execution_busy", return_value=False), \
                patch.object(mission_runner, "_refresh_library_index", return_value=None), \
                patch.object(renderer_pipeline, "run_renderer_pipeline", side_effect=render), \
                patch.object(main, "gpu_execution_lock", return_value=contextlib.nullcontext()) as gpu_lock, \
                patch.object(main.threading, "Thread", _ImmediateThread):
            response = asyncio.run(main.retry_mission_candidate(mission.mission_id, "candidate-1"))

        self.assertEqual(response["status"], "queued")
        gpu_lock.assert_called_once_with(timeout=45)
        self.assertEqual(captured["creation_mode"], "stock")
        self.assertEqual(captured["outfit_override"], "formal red dress")
        self.assertEqual(captured["renderer_routing"], {"route": "identity-safe"})
        self.assertEqual(mission.status, "COMPLETE")
        self.assertEqual(mission.error_message, "")
        self.assertEqual(mission.active_candidates, 0)
        self.assertNotEqual(mission.completed_at, "2025-01-01T00:00:00")


if __name__ == "__main__":
    unittest.main()
