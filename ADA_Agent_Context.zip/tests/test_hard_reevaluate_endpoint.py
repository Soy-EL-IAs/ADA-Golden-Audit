from __future__ import annotations

import unittest
from unittest.mock import MagicMock, patch

import filelock

from ada_app import main


class _Request:
    def __init__(self, value):
        self.value = value

    async def json(self):
        return self.value


class _BusyLock:
    def acquire(self, timeout):
        raise filelock.Timeout("gpu_execution.lock")


class HardReevaluateEndpointTests(unittest.IsolatedAsyncioTestCase):
    async def test_gpu_contention_is_skipped_without_durable_failure(self) -> None:
        assets = [
            {"asset_id": f"asset-{index}", "full_image_path": f"image-{index}.png"}
            for index in range(3)
        ]
        library = MagicMock()
        library.get_assets.return_value = assets

        with patch.object(main, "AssetLibrary", return_value=library), \
                patch("filelock.FileLock", return_value=_BusyLock()):
            response = await main.hard_reevaluate_library_images(
                _Request({"asset_ids": [item["asset_id"] for item in assets]})
            )

        self.assertEqual(response["evaluated_count"], 0)
        self.assertEqual(
            response["skipped"],
            [{"asset_id": item["asset_id"], "reason": "gpu_lock_timeout"} for item in assets],
        )
        library.save_hard_rating.assert_not_called()

    async def test_batch_size_is_bounded_before_work_starts(self) -> None:
        response = await main.hard_reevaluate_library_images(
            _Request({"asset_ids": [f"asset-{index}" for index in range(21)]})
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn(b"hard_reevaluation_batch_too_large", response.body)

    async def test_evaluation_failure_is_persisted_with_its_real_error(self) -> None:
        asset = {"asset_id": "asset-1", "full_image_path": "missing.png"}
        library = MagicMock()
        library.get_assets.return_value = [asset]
        lock = MagicMock()
        lock.acquire.return_value.__enter__.return_value = None

        with patch.object(main, "AssetLibrary", return_value=library), \
                patch("filelock.FileLock", return_value=lock), \
                patch("scripts.hard_re_evaluator.evaluate_image", side_effect=RuntimeError("review exploded")):
            response = await main.hard_reevaluate_library_images(
                _Request({"asset_ids": [asset["asset_id"]]})
            )

        self.assertEqual(response["evaluated_count"], 1)
        failure = response["results"][asset["asset_id"]]
        self.assertTrue(failure["evaluation_failed"])
        self.assertEqual(failure["error"], "review exploded")
        library.save_hard_rating.assert_called_once_with(asset["asset_id"], failure, failed=True)


if __name__ == "__main__":
    unittest.main()
