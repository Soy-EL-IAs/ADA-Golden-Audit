from __future__ import annotations

import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import atomic_io


ROOT = Path(__file__).resolve().parents[1]


class AtomicIoFsyncTests(unittest.TestCase):
    def test_fsync_happens_once_before_replace(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests" / f"fsync-{uuid.uuid4().hex}"
        parent.mkdir(parents=True)
        self.addCleanup(shutil.rmtree, parent, True)
        destination = parent / "state.json"
        events = []
        real_replace = atomic_io.os.replace

        def record_fsync(_descriptor):
            events.append("fsync")

        def record_replace(source, target):
            events.append("replace")
            return real_replace(source, target)

        with patch.object(atomic_io.os, "fsync", side_effect=record_fsync) as fsync, \
                patch.object(atomic_io.os, "replace", side_effect=record_replace):
            atomic_io.atomic_write_text(destination, "{\"ok\": true}\n")

        self.assertEqual(events, ["fsync", "replace"])
        fsync.assert_called_once()
        self.assertEqual(destination.read_text(encoding="utf-8"), "{\"ok\": true}\n")


if __name__ == "__main__":
    unittest.main()
