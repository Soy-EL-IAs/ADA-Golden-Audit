from __future__ import annotations

import shutil
import unittest
import uuid
import warnings
from pathlib import Path
from unittest.mock import patch

from ada_app import asset_library
from ada_app.asset_library import AssetLibrary, AssetReviewCorruptError


ROOT = Path(__file__).resolve().parents[1]


class AssetReviewBackupTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"asset-review-backup-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.review_path = self.temporary / "asset_review.json"

    @staticmethod
    def _library() -> AssetLibrary:
        library = AssetLibrary.__new__(AssetLibrary)
        library.index = [{"asset_id": "asset-1", "render_outputs": [], "stage_images": {}}]
        library.reviews = {}
        return library

    def test_corrupt_disk_bytes_are_backed_up_only_once_per_process(self) -> None:
        original = b'{"asset-1": {"rating": 7'
        self.review_path.write_bytes(original)
        library = self._library()

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_REVIEWS_BACKUP_DONE", False):
            with self.assertRaises(AssetReviewCorruptError):
                library.save_hard_rating("asset-1", {"evaluation_id": "hard-1"})
            backups = list((self.temporary / "asset_review.backups").glob("asset_review-*.json"))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_bytes(), original)

            # The corrupt original was quarantined. A subsequent explicit write
            # can recreate the review file without duplicating the session backup.
            library.save_hard_rating("asset-1", {"evaluation_id": "hard-2"})
            self.assertEqual(
                len(list((self.temporary / "asset_review.backups").glob("asset_review-*.json"))),
                1,
            )

    def test_new_process_session_creates_another_backup(self) -> None:
        self.review_path.write_text("{}\n", encoding="utf-8")
        library = self._library()
        backup_dir = self.temporary / "asset_review.backups"

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_REVIEWS_BACKUP_DONE", False):
            library.save_hard_rating("asset-1", {"evaluation_id": "hard-1"})
            asset_library._REVIEWS_BACKUP_DONE = False
            library.save_hard_rating("asset-1", {"evaluation_id": "hard-2"})

        self.assertEqual(len(list(backup_dir.glob("asset_review-*.json"))), 2)

    def test_rotation_keeps_twenty_latest_backups(self) -> None:
        self.review_path.write_text("{}\n", encoding="utf-8")
        original = self.review_path.read_bytes()
        backup_dir = self.temporary / "asset_review.backups"
        backup_dir.mkdir()
        for index in range(25):
            (backup_dir / f"asset_review-20000101T000000{index:06d}Z.json").write_text(
                str(index), encoding="utf-8"
            )

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_REVIEWS_BACKUP_DONE", False):
            asset_library._backup_reviews_once()

        backups = sorted(backup_dir.glob("asset_review-*.json"))
        self.assertEqual(len(backups), 20)
        self.assertTrue(any(path.read_bytes() == original for path in backups))

    def test_backup_failure_warns_without_blocking_write(self) -> None:
        self.review_path.write_text("{}\n", encoding="utf-8")
        library = self._library()

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_REVIEWS_BACKUP_DONE", False), \
                patch.object(asset_library.shutil, "copy2", side_effect=OSError("disk full")), \
                warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            library.save_hard_rating("asset-1", {"evaluation_id": "hard-1"})

        self.assertTrue(any("Could not back up" in str(item.message) for item in caught))
        self.assertIn(b'"hard_rating"', self.review_path.read_bytes())

    def test_all_review_writers_enter_through_backup_helper(self) -> None:
        self.review_path.write_text("{}\n", encoding="utf-8")
        library = self._library()

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_backup_reviews_once") as backup:
            library.save_review("asset-1", rating=8)
            library.set_library_status(["asset-1"], "REJECTED")
            library.save_hard_rating("asset-1", {"evaluation_id": "hard-1"})

        self.assertEqual(backup.call_count, 3)


if __name__ == "__main__":
    unittest.main()
