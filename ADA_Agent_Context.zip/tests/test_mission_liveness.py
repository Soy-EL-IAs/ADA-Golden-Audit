from __future__ import annotations

import shutil
import threading
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import mission as mission_module
from ada_app.mission import MissionStore, ProductionMission
from ada_app.mission_runner import is_mission_thread_alive


ROOT = Path(__file__).resolve().parents[1]


class MissionLivenessTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"mission-live-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_live_interrupted_mission_cannot_delete_but_dead_one_can(self) -> None:
        stop = threading.Event()
        mission = ProductionMission(mission_id=f"mission-live-{uuid.uuid4().hex}")
        mission.status = "PRODUCING"

        with patch.object(mission_module, "MISSIONS_DIR", self.temporary):
            store = MissionStore()
            store.save(mission)
            thread = threading.Thread(
                target=lambda: stop.wait(5),
                name=f"mission-{mission.mission_id}",
            )
            thread.start()
            try:
                self.assertTrue(is_mission_thread_alive(mission.mission_id))
                with self.assertRaises(ValueError):
                    store.delete(mission.mission_id, mission_alive=True)
            finally:
                stop.set()
                thread.join()

            self.assertFalse(is_mission_thread_alive(mission.mission_id))
            deleted = store.delete(mission.mission_id, mission_alive=False)
            self.assertEqual(deleted.status, "PRODUCING")
            self.assertFalse(store._path(mission.mission_id).exists())

    def test_update_rejects_unknown_status(self) -> None:
        mission = ProductionMission(mission_id=f"mission-status-{uuid.uuid4().hex}")
        with patch.object(mission_module, "MISSIONS_DIR", self.temporary):
            store = MissionStore()
            store.save(mission)
            with self.assertRaises(ValueError):
                store.update(mission, status="TYPO_STATUS")

    def test_candidate_retry_thread_counts_as_live_mission_work(self) -> None:
        stop = threading.Event()
        mission_id = f"mission-retry-live-{uuid.uuid4().hex}"
        thread = threading.Thread(
            target=lambda: stop.wait(5),
            name=f"retry-{mission_id}-candidate-1",
        )
        thread.start()
        try:
            self.assertTrue(is_mission_thread_alive(mission_id))
        finally:
            stop.set()
            thread.join()


if __name__ == "__main__":
    unittest.main()
