from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import managed_assets
from ada_app.managed_assets import adopt_library_record, library_record_filename
from scripts.migrate_library_record_names import migrate


ROOT = Path(__file__).resolve().parents[1]


class ManagedRecordIdentityTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"managed-record-identity-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_normalization_collision_produces_distinct_record_files(self) -> None:
        source = self.temporary / "source.png"
        source.write_bytes(b"same-image")
        assets_root = self.temporary / "assets"
        records_root = self.temporary / "records"
        ids = ["run_c01::lustify", "run_c01_lustify"]

        with patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", records_root):
            for asset_id in ids:
                adopt_library_record({
                    "asset_id": asset_id,
                    "full_image_path": str(source),
                    "thumbnail_path": str(source),
                })

        paths = sorted(records_root.glob("*.json"))
        self.assertEqual(len(paths), 2)
        self.assertNotEqual(paths[0].name, paths[1].name)
        self.assertEqual(
            {json.loads(path.read_text(encoding="utf-8"))["asset_id"] for path in paths},
            set(ids),
        )

    def test_legacy_name_migration_is_idempotent(self) -> None:
        records_root = self.temporary / "records"
        records_root.mkdir()
        asset_id = "run_c01::lustify"
        legacy = records_root / "run_c01_lustify.json"
        legacy.write_text(json.dumps({"asset_id": asset_id}) + "\n", encoding="utf-8")

        first = migrate(records_root)
        second = migrate(records_root)

        self.assertEqual(first["renamed"], 1)
        self.assertEqual(second["renamed"], 0)
        destination = records_root / library_record_filename(asset_id)
        self.assertTrue(destination.is_file())
        self.assertEqual(json.loads(destination.read_text(encoding="utf-8"))["asset_id"], asset_id)


if __name__ == "__main__":
    unittest.main()
