from __future__ import annotations

import json
import shutil
import threading
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import asset_library, atomic_io
from ada_app.asset_library import AssetLibrary


ROOT = Path(__file__).resolve().parents[1]


class AssetReviewAtomicityTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"asset-review-atomicity-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.review_path = self.temporary / "asset_review.json"

    @staticmethod
    def _library(asset_ids: list[str], reviews: dict | None = None) -> AssetLibrary:
        library = AssetLibrary.__new__(AssetLibrary)
        library.index = [
            {"asset_id": asset_id, "render_outputs": [], "stage_images": {}}
            for asset_id in asset_ids
        ]
        library.reviews = dict(reviews or {})
        return library

    def test_original_remains_intact_until_atomic_replace(self) -> None:
        previous = {"existing": {"rating": 4}}
        self.review_path.write_text(json.dumps(previous) + "\n", encoding="utf-8")
        library = self._library(["asset-1"], previous)
        original_replace = atomic_io.os.replace
        observed: list[dict] = []

        def inspect_before_replace(source, target):
            if Path(target) == self.review_path:
                observed.append(json.loads(self.review_path.read_text(encoding="utf-8")))
            return original_replace(source, target)

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_backup_reviews_once"), \
                patch.object(atomic_io.os, "replace", inspect_before_replace):
            library.save_review("asset-1", rating=8)

        self.assertEqual(observed, [previous])
        persisted = json.loads(self.review_path.read_text(encoding="utf-8"))
        self.assertEqual(persisted["asset-1"]["rating"], 8)
        self.assertFalse(list(self.temporary.glob("asset_review.json.*.tmp")))

    def test_twenty_concurrent_reviews_are_all_persisted(self) -> None:
        asset_ids = [f"asset-{index}" for index in range(20)]
        self.review_path.write_text("{}\n", encoding="utf-8")
        library = self._library(asset_ids)
        errors: list[Exception] = []

        def save(asset_id: str) -> None:
            try:
                library.save_review(asset_id, rating=8)
            except Exception as exc:  # pragma: no cover - asserted below
                errors.append(exc)

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_backup_reviews_once"):
            threads = [threading.Thread(target=save, args=(asset_id,)) for asset_id in asset_ids]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()

        self.assertEqual(errors, [])
        persisted = json.loads(self.review_path.read_text(encoding="utf-8"))
        self.assertEqual(set(persisted), set(asset_ids))


if __name__ == "__main__":
    unittest.main()
