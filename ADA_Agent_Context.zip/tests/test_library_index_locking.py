from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from filelock import FileLock

from ada_app import asset_library, managed_assets
from ada_app.asset_library import AssetLibrary


ROOT = Path(__file__).resolve().parents[1]


class LibraryIndexLockingTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"index-locking-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.index_path = self.temporary / "library" / "index.json"
        self.explicit_path = self.temporary / "library" / "explicit.json"
        self.review_path = self.temporary / "library" / "reviews.json"
        self.records_root = self.temporary / "library" / "records"
        self.assets_root = self.temporary / "library" / "assets"
        self.index_path.parent.mkdir(parents=True)
        self.review_path.write_text("{}\n", encoding="utf-8")

    def _patches(self):
        return patch.multiple(
            asset_library,
            LIBRARY_DIR=self.index_path.parent,
            INDEX_PATH=self.index_path,
            EXPLICIT_IMAGES_PATH=self.explicit_path,
            REVIEW_PATH=self.review_path,
            LIBRARY_RECORDS_ROOT=self.records_root,
            LOCKS_ROOT=self.temporary / "locks",
            _INDEX_BUILD_LOCK=FileLock(str(self.temporary / "locks" / "library_index.lock")),
        )

    def test_loading_filters_legacy_without_touching_index_file(self) -> None:
        original = [{
            "asset_id": "legacy",
            "record_type": "library_image_v2",
            "concept_snapshot": "Legacy Image Pipeline Result",
        }]
        self.index_path.write_text(json.dumps(original) + "\n", encoding="utf-8")
        before_bytes = self.index_path.read_bytes()
        before_mtime = self.index_path.stat().st_mtime_ns

        with self._patches():
            library = AssetLibrary()

        self.assertEqual(library.index, [])
        self.assertEqual(self.index_path.read_bytes(), before_bytes)
        self.assertEqual(self.index_path.stat().st_mtime_ns, before_mtime)

    def test_reinterpretation_rereads_fresh_index_before_publishing(self) -> None:
        self.index_path.write_text("[]\n", encoding="utf-8")
        output = self.temporary / "reinterpret.png"
        output.write_bytes(b"reinterpretation")
        derived = {"asset_id": "derived::lustify", "record_type": "library_image_v2"}
        record = {
            "status": "COMPLETE",
            "request_id": "reinterpret-1",
            "renderer": "lustify",
            "output_asset": str(output),
            "target_character": "2B",
            "render_receipt": {"output_asset": str(output), "preset": "test"},
        }

        with self._patches(), \
                patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", self.assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", self.records_root):
            stale = AssetLibrary()
            AssetLibrary._write_index_records([derived])
            stale.register_reinterpretation(record)

        published = json.loads(self.index_path.read_text(encoding="utf-8"))
        self.assertEqual(
            {item["asset_id"] for item in published},
            {"derived::lustify", "reinterpret-1::lustify"},
        )


if __name__ == "__main__":
    unittest.main()
