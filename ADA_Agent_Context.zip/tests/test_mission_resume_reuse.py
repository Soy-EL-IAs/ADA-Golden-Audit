from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import mission_runner
from ada_app.mission import ProductionMission


ROOT = Path(__file__).resolve().parents[1]


class _Store:
    def __init__(self, mission):
        self.mission = mission
        self.updates = []

    def load(self, _mission_id):
        return self.mission

    def update(self, mission, **kwargs):
        for key, value in kwargs.items():
            setattr(mission, key, value)
        self.updates.append(kwargs)
        return mission


class MissionResumeReuseTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"resume-reuse-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_resume_reuses_last_run_before_starting_new_m2(self) -> None:
        run_id = "m2_existing_round_01"
        run_dir = self.temporary / run_id
        run_dir.mkdir()
        candidates_path = run_dir / "pilot_candidates.json"
        candidates_path.write_text(json.dumps([{
            "concept_id": "candidate-1",
            "pipeline_state": "RENDERED_PENDING_REVIEW",
            "render_outputs": [{"renderer": "lustify", "receipt": {"output_asset": "existing.png"}}],
        }]) + "\n", encoding="utf-8")
        mission = ProductionMission(
            mission_id="mission-resume",
            character="2B",
            requested_assets=1,
            max_rounds=2,
        )
        mission.status = "RECOVERING"
        mission.current_round = 1
        mission.source_runs = [run_id]
        store = _Store(mission)

        def recover(_run_dir, _candidates, **_kwargs):
            durable = json.loads(candidates_path.read_text(encoding="utf-8"))
            durable[0]["pipeline_state"] = "APPROVED"
            candidates_path.write_text(json.dumps(durable) + "\n", encoding="utf-8")

        with patch.object(mission_runner, "RUNS_DIR", self.temporary), \
                patch.object(mission_runner, "run_renderer_pipeline", side_effect=recover) as renderer, \
                patch.object(mission_runner.subprocess, "run") as m2, \
                patch.object(mission_runner, "_refresh_library_index", return_value=None):
            mission_runner._run_mission_internal(mission.mission_id, store, mission)

        renderer.assert_called_once()
        m2.assert_not_called()
        self.assertEqual(mission.source_runs, [run_id])
        self.assertEqual(mission.approved_assets, 1)
        self.assertEqual(mission.status, "COMPLETE")


if __name__ == "__main__":
    unittest.main()
