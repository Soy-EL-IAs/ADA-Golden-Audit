from __future__ import annotations

import json
import shutil
import unittest
import uuid
import warnings
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from ada_app import asset_library, managed_assets
from ada_app.asset_library import AssetLibrary


ROOT = Path(__file__).resolve().parents[1]


class ManagedRecordRebuildTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"managed-record-rebuild-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.assets_root = self.temporary / "library" / "assets"
        self.records_root = self.temporary / "library" / "records"
        self.index_path = self.temporary / "library" / "index.json"
        self.explicit_path = self.temporary / "library" / "explicit.json"
        self.characters_path = self.temporary / "characters.json"
        self.characters_path.write_text("{}\n", encoding="utf-8")

    def _candidate_run(self, original: Path) -> tuple[Path, SimpleNamespace, str]:
        run_id = "m2_managed_rebuild"
        concept_id = "candidate-1"
        asset_id = f"{run_id}_{concept_id}::lustify"
        run_dir = self.temporary / run_id
        run_dir.mkdir()
        candidate = {
            "concept_id": concept_id,
            "pipeline_state": "APPROVED",
            "character": "2B",
            "render_outputs": [{
                "renderer": "lustify",
                "receipt": {"output_asset": str(original)},
                "review": {"verdict": "PASS", "agent_rating": 8},
            }],
            "automatic_final_renderer_decision": {
                "selected_renderer": "lustify",
                "selected_image": str(original),
            },
        }
        (run_dir / "pilot_candidates.json").write_text(
            json.dumps([candidate], indent=2) + "\n", encoding="utf-8"
        )
        run = SimpleNamespace(
            run_id=run_id,
            run_type="Pilot",
            artifact_root=str(run_dir),
            character="2B",
            created_at="2026-08-26T00:00:00",
            source_model="test",
        )
        return run_dir, run, asset_id

    def _build(self, run: SimpleNamespace) -> list[dict]:
        library = AssetLibrary.__new__(AssetLibrary)
        library.reviews = {}
        library.index = []
        with patch.object(asset_library, "LIBRARY_RECORDS_ROOT", self.records_root), \
                patch.object(asset_library, "INDEX_PATH", self.index_path), \
                patch.object(asset_library, "EXPLICIT_IMAGES_PATH", self.explicit_path), \
                patch.object(asset_library, "CHARACTERS_PATH", self.characters_path), \
                patch.object(asset_library.RunIndex, "get_all_runs", return_value=[run]), \
                patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", self.assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", self.records_root):
            return library.build_index(verify_managed_hash=True)

    def test_rebuild_uses_managed_record_when_original_is_gone(self) -> None:
        original = self.temporary / "comfy-output.png"
        original.write_bytes(b"durable-image")
        _run_dir, run, asset_id = self._candidate_run(original)
        with patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", self.assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", self.records_root):
            record = managed_assets.adopt_library_record({
                "asset_id": asset_id,
                "full_image_path": str(original),
                "thumbnail_path": str(original),
                "source_run_id": run.run_id,
                "record_type": "library_image_v2",
            })
        original.unlink()

        rebuilt = self._build(run)

        self.assertEqual([item["asset_id"] for item in rebuilt], [asset_id])
        self.assertEqual(rebuilt[0]["full_image_path"], record["full_image_path"])
        self.assertTrue(Path(rebuilt[0]["full_image_path"]).is_file())

    def test_rebuild_excludes_record_whose_managed_blob_is_missing(self) -> None:
        original = self.temporary / "comfy-output.png"
        original.write_bytes(b"durable-image")
        _run_dir, run, asset_id = self._candidate_run(original)
        with patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", self.assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", self.records_root):
            record = managed_assets.adopt_library_record({
                "asset_id": asset_id,
                "full_image_path": str(original),
                "thumbnail_path": str(original),
                "source_run_id": run.run_id,
                "record_type": "library_image_v2",
            })
        original.unlink()
        Path(record["full_image_path"]).unlink()

        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            rebuilt = self._build(run)

        self.assertEqual(rebuilt, [])


if __name__ == "__main__":
    unittest.main()
