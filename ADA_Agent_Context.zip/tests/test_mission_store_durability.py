from __future__ import annotations

import asyncio
import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import main, mission as mission_module
from ada_app.mission import MissionCorruptError, MissionStore, ProductionMission


ROOT = Path(__file__).resolve().parents[1]


class MissionStoreDurabilityTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"mission-store-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.missions_dir = self.temporary / "missions"
        self.missions_dir.mkdir()
        self.locks_dir = self.temporary / "locks"
        self.paths = (
            patch.object(mission_module, "MISSIONS_DIR", self.missions_dir),
            patch.object(mission_module, "LOCKS_ROOT", self.locks_dir),
        )
        for item in self.paths:
            item.start()
            self.addCleanup(item.stop)

    def test_stale_updates_merge_only_received_keys(self) -> None:
        store_one = MissionStore()
        store_two = MissionStore()
        mission = ProductionMission(character="2B")
        store_one.save(mission)
        first_copy = store_one.load(mission.mission_id)
        stale_second_copy = store_two.load(mission.mission_id)

        store_one.update(first_copy, cancelled=True)
        store_two.update(stale_second_copy, status="PRODUCING")

        persisted = store_one.load(mission.mission_id)
        self.assertTrue(persisted.cancelled)
        self.assertEqual(persisted.status, "PRODUCING")

    def test_load_quarantines_three_byte_mission_and_raises(self) -> None:
        store = MissionStore()
        mission_id = "mission_corrupt_load"
        source = self.missions_dir / f"{mission_id}.json"
        source.write_bytes(b"{x}")

        with self.assertRaises(MissionCorruptError) as raised:
            store.load(mission_id)

        self.assertFalse(source.exists())
        self.assertIsNotNone(raised.exception.corrupt_path)
        self.assertEqual(raised.exception.corrupt_path.read_bytes(), b"{x}")

    def test_list_all_includes_corrupt_mission_instead_of_omitting_it(self) -> None:
        store = MissionStore()
        mission_id = "mission_corrupt_list"
        (self.missions_dir / f"{mission_id}.json").write_bytes(b"bad")

        listed = store.list_all()

        self.assertEqual(len(listed), 1)
        self.assertEqual(listed[0].mission_id, mission_id)
        self.assertEqual(listed[0].status, "CORRUPT")
        self.assertIn("MissionCorruptError", listed[0].failure_details[0]["error_type"])

    def test_get_mission_maps_corruption_to_http_409(self) -> None:
        mission_id = "mission_corrupt_api"
        (self.missions_dir / f"{mission_id}.json").write_bytes(b"bad")

        response = asyncio.run(main.get_mission(mission_id))

        self.assertEqual(response.status_code, 409)
        body = json.loads(response.body)
        self.assertEqual(body["error"], "mission_corrupt")
        self.assertIn(".corrupt-", body["corrupt_path"])

    def test_save_uses_unique_temporary_and_leaves_no_residue(self) -> None:
        store = MissionStore()
        mission = ProductionMission(character="2B")
        store.save(mission)
        store.save(mission)
        self.assertTrue((self.missions_dir / f"{mission.mission_id}.json").is_file())
        self.assertFalse(list(self.missions_dir.glob("*.tmp")))


if __name__ == "__main__":
    unittest.main()
