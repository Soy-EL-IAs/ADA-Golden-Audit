import unittest
import json
from pathlib import Path
from ada_app.character_capabilities import character_capability_status, renderer_request_allowed

ROOT = Path(__file__).resolve().parents[1]

class CharacterCapabilitiesBaselineTests(unittest.TestCase):
    def setUp(self):
        self.catalog_path = ROOT / "data" / "characters" / "catalog.json"
        self.catalog = {}
        if self.catalog_path.exists():
            with open(self.catalog_path, 'r', encoding='utf-8') as f:
                self.catalog = json.load(f)

    def test_ghislaine_is_unverified(self):
        char = self.catalog.get("Ghislaine Dedoldia")
        self.assertIsNotNone(char, "Ghislaine must exist")
        caps = char.get("renderer_capabilities", {})
        
        self.assertEqual(caps.get("lustify", {}).get("identity_recognition"), "unverified")
        self.assertEqual(caps.get("miaomiao", {}).get("identity_recognition"), "unverified")
        self.assertNotIn("fallback_policy", caps.get("lustify", {}))
        
        allowed, reason = renderer_request_allowed(char, "miaomiao")
        self.assertTrue(allowed)
        
        status = character_capability_status(char)
        self.assertEqual(status["status"], "unknown")
        
        from ada_app.character_capabilities import resolve_stock_renderer
        stock_route = resolve_stock_renderer(char)
        self.assertEqual(stock_route["route"], "unverified_primary_fallback")

    def test_yoruichi_is_unverified(self):
        char = self.catalog.get("Shihouin Yoruichi")
        self.assertIsNotNone(char, "Yoruichi must exist")
        caps = char.get("renderer_capabilities", {})
        
        self.assertEqual(caps.get("lustify", {}).get("identity_recognition"), "unverified")
        self.assertEqual(caps.get("miaomiao", {}).get("identity_recognition"), "unverified")
        
        allowed, reason = renderer_request_allowed(char, "lustify")
        self.assertTrue(allowed)
        
        status = character_capability_status(char)
        self.assertEqual(status["status"], "unknown")

    def test_other_characters_are_unverified(self):
        for name, char in self.catalog.items():
            if name not in ["Ghislaine Dedoldia", "Shihouin Yoruichi"]:
                caps = char.get("renderer_capabilities", {})
                if caps:
                    self.assertNotEqual(caps.get("lustify", {}).get("identity_recognition"), "confirmed")
                    self.assertNotEqual(caps.get("miaomiao", {}).get("identity_recognition"), "confirmed")

    def test_references_are_available(self):
        char = self.catalog.get("Ghislaine Dedoldia")
        self.assertIsNotNone(char)
        manifest_path = ROOT / char.get("refs_manifest", "missing.json")
        self.assertTrue(manifest_path.exists(), "Reference manifest must exist")
        
        char2 = self.catalog.get("Shihouin Yoruichi")
        self.assertIsNotNone(char2)
        manifest_path2 = ROOT / char2.get("refs_manifest", "missing.json")
        self.assertTrue(manifest_path2.exists(), "Reference manifest must exist")

if __name__ == '__main__':
    unittest.main()
