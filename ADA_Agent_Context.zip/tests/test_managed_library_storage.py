from __future__ import annotations

import hashlib
import shutil
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch

from ada_app import managed_assets


ROOT = Path(__file__).resolve().parents[1]


class ManagedLibraryStorageTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"managed-library-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_adoption_owns_and_deduplicates_pixels_with_original_provenance(self) -> None:
        source = self.temporary / "raw.png"
        source.write_bytes(b"representative-image-bytes")
        assets = self.temporary / "library" / "assets"
        records = self.temporary / "library" / "records"
        with patch.multiple(
            managed_assets,
            ADA_ROOT=self.temporary,
            LIBRARY_ASSETS_ROOT=assets,
            LIBRARY_RECORDS_ROOT=records,
        ):
            first = managed_assets.adopt_library_record({
                "asset_id": "asset::one", "character": "2B",
                "full_image_path": str(source), "thumbnail_path": str(source),
            })
            second = managed_assets.adopt_library_record({
                "asset_id": "asset::two", "character": "2B",
                "full_image_path": str(source), "thumbnail_path": str(source),
            })

        self.assertEqual(first["full_image_path"], second["full_image_path"])
        self.assertEqual(len(list((assets / "sha256").rglob("*.png"))), 1)
        self.assertEqual(len(list(records.glob("*.json"))), 2)
        self.assertEqual(first["storage_provenance"]["original_source_path"], str(source.resolve()))
        self.assertEqual(
            first["storage_provenance"]["sha256"],
            hashlib.sha256(source.read_bytes()).hexdigest(),
        )

    def test_concurrent_adoption_of_same_blob_uses_unique_temporaries(self) -> None:
        source = self.temporary / "shared.png"
        source.write_bytes(b"shared-concurrent-image")
        assets = self.temporary / "library" / "assets"
        records = self.temporary / "library" / "records"

        def adopt(index: int) -> dict:
            return managed_assets.adopt_library_record({
                "asset_id": f"asset::{index}",
                "full_image_path": str(source),
                "thumbnail_path": str(source),
            })

        with patch.multiple(
            managed_assets,
            ADA_ROOT=self.temporary,
            LIBRARY_ASSETS_ROOT=assets,
            LIBRARY_RECORDS_ROOT=records,
        ):
            with ThreadPoolExecutor(max_workers=2) as executor:
                adopted = list(executor.map(adopt, range(2)))

        self.assertEqual(adopted[0]["full_image_path"], adopted[1]["full_image_path"])
        blob = Path(adopted[0]["full_image_path"])
        self.assertEqual(blob.read_bytes(), source.read_bytes())
        self.assertFalse(list(blob.parent.glob(f"{blob.name}.*.tmp")))


if __name__ == "__main__":
    unittest.main()
