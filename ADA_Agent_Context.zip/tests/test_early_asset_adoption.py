from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import managed_assets, renderer_pipeline


ROOT = Path(__file__).resolve().parents[1]


class _Controller:
    def handoff_comfy_to_lm(self, _url):
        return None

    def activate_role(self, _role):
        return None

    def role(self, _role):
        return type("Role", (), {"model": "test-reviewer"})()

    def unload_all(self):
        return None

    def wait_for_vram_release(self):
        return None


class _FailingReleaseController(_Controller):
    def wait_for_vram_release(self):
        raise TimeoutError("test model remained loaded")


class EarlyAssetAdoptionTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"early-adoption-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def _execute_pass(self, controller_type=_Controller) -> tuple[dict, Path, Path]:
        run_dir = self.temporary / "m2_early_adoption"
        run_dir.mkdir()
        image = self.temporary / "comfy-output.png"
        image.write_bytes(b"approved-pixels")
        output = {
            "renderer": "lustify",
            "review_stage": "lustify",
            "preset": "test-preset",
            "role": "requested_output",
            "receipt": {"output_asset": str(image), "receipt_id": "receipt-1"},
            "stage_render_plan": {},
            "prompt_artifact": {},
            "review": {},
            "review_observation": {},
        }
        candidate = {
            "concept_id": "candidate-1",
            "character": "2B",
            "pipeline_state": "PENDING",
            "render_outputs": [output],
        }
        (run_dir / "pilot_candidates.json").write_text(
            json.dumps([candidate], indent=2) + "\n", encoding="utf-8"
        )
        assets_root = self.temporary / "library" / "assets"
        records_root = self.temporary / "library" / "records"

        with patch.object(renderer_pipeline, "registered_character", return_value={}), \
                patch.object(renderer_pipeline, "registered_character_contract", return_value={"contract_id": "c1"}), \
                patch.object(renderer_pipeline, "build_resolved_render_spec", return_value={}), \
                patch.object(renderer_pipeline, "build_resolved_render_spec_v3", return_value={"spec_id": "s1"}), \
                patch.object(renderer_pipeline, "character_capability_status", return_value={"status": "green", "reason": ""}), \
                patch.object(renderer_pipeline, "configured_renderers", return_value=[("test-preset", {"renderer": "lustify"})]), \
                patch.object(renderer_pipeline, "review_stage_image", return_value={"verdict": "PASS"}), \
                patch.object(renderer_pipeline, "build_review_observation", return_value={}), \
                patch.object(renderer_pipeline, "validate_contract"), \
                patch.object(renderer_pipeline, "submit") as submit, \
                patch.object(renderer_pipeline, "LMStudioController", controller_type), \
                patch.object(managed_assets, "LIBRARY_ASSETS_ROOT", assets_root), \
                patch.object(managed_assets, "LIBRARY_RECORDS_ROOT", records_root):
            renderer_pipeline.execute_renderer_candidate(run_dir, candidate, {"requested_character": "2B"})
            submit.assert_not_called()

        durable = json.loads((run_dir / "pilot_candidates.json").read_text(encoding="utf-8"))[0]
        return durable, image, records_root

    def test_pass_adopts_pixels_before_candidate_is_approved(self) -> None:
        durable, image, records_root = self._execute_pass()
        receipt = durable["render_outputs"][0]["receipt"]
        self.assertEqual(durable["pipeline_state"], "APPROVED")
        self.assertEqual(receipt["output_asset"], str(image))
        managed = Path(receipt["managed_output_asset"])
        self.assertTrue(managed.is_file())
        self.assertEqual(managed.read_bytes(), image.read_bytes())
        self.assertEqual(len(list(records_root.glob("*.json"))), 1)

    def test_release_timeout_does_not_replace_a_real_pass(self) -> None:
        durable, _image, _records_root = self._execute_pass(_FailingReleaseController)

        self.assertEqual(durable["pipeline_state"], "APPROVED")
        self.assertEqual(
            durable["vram_release_warning"],
            "TimeoutError: test model remained loaded",
        )


if __name__ == "__main__":
    unittest.main()
