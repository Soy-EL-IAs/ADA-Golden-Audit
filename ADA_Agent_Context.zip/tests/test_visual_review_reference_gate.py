from __future__ import annotations

import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from scripts.ada_paths import TMP_ROOT
from scripts.specialist_visual_reviewer import (
    VisualReviewSetupError,
    VisualReviewTransportError,
    require_canonical_reference_count,
    review_stage_image,
)


ROOT = Path(__file__).resolve().parents[1]


class VisualReviewReferenceGateTests(unittest.TestCase):
    def setUp(self) -> None:
        TMP_ROOT.mkdir(parents=True, exist_ok=True)
        self.temporary = TMP_ROOT / f"visual-review-reference-gate-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.image = self.temporary / "candidate.png"
        self.image.write_bytes(b"candidate")

    @staticmethod
    def _registered_spec() -> dict:
        return {
            "schema_version": "resolved_render_spec_v3",
            "character_contract_id": "character:registered:default",
            "character": {
                "display_name": "Registered Character",
                "canonical_tag": "registered_character",
                "must_preserve": ["Registered Character"],
            },
            "expected_visibility": ["Registered Character"],
            "expected_subject_count": 1,
            "validation_requirements": [],
            "render_intent": "semi_realistic",
        }

    def test_registered_character_without_contract_or_references_fails_before_transport(self) -> None:
        with self.assertRaisesRegex(VisualReviewSetupError, "Canonical character references"):
            review_stage_image(
                self.image,
                identifier="candidate-1",
                stage="lustify",
                premise_spec=self._registered_spec(),
                character_contract=None,
                model="unused",
            )

    def test_consumer_rejects_review_without_canonical_reference_count(self) -> None:
        with self.assertRaises(VisualReviewSetupError):
            require_canonical_reference_count({"canonical_reference_count": 0})
        grounded = {"canonical_reference_count": 1}
        self.assertIs(require_canonical_reference_count(grounded), grounded)

    def test_blind_pass_failure_stops_before_context_confrontation(self) -> None:
        with patch(
            "scripts.specialist_visual_reviewer.canonical_reference_paths",
            return_value=[self.image],
        ), patch(
            "scripts.specialist_visual_reviewer._request",
            side_effect=RuntimeError("blind transport unavailable"),
        ) as request:
            with self.assertRaisesRegex(VisualReviewTransportError, "Blind visual observation failed"):
                review_stage_image(
                    self.image,
                    identifier="candidate-1",
                    stage="lustify",
                    premise_spec=self._registered_spec(),
                    character_contract={"display_name": "Registered Character"},
                    model="unused",
                    base_url="http://127.0.0.1:1234",
                )
        self.assertEqual(request.call_count, 2)

    def test_all_legacy_review_call_sites_pass_the_character_contract(self) -> None:
        pilot_source = (ROOT / "ada_app" / "pilot_runner.py").read_text(encoding="utf-8")
        full_source = (ROOT / "scripts" / "run_full_pipeline.py").read_text(encoding="utf-8")
        self.assertEqual(pilot_source.count("character_contract=character_contract"), 2)
        self.assertEqual(full_source.count("character_contract=self.character_contract"), 2)


if __name__ == "__main__":
    unittest.main()
