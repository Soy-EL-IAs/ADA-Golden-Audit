from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import mission_runner, renderer_pipeline
from ada_app.mission import ProductionMission


ROOT = Path(__file__).resolve().parents[1]


class RendererControlFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"renderer-flow-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        (self.temporary / "character_profile.json").write_text("{}\n", encoding="utf-8")

    def test_cancel_before_first_candidate_executes_nothing(self) -> None:
        candidates = [{"concept_id": f"c-{index}", "pipeline_state": "PENDING"} for index in range(3)]
        with patch.object(renderer_pipeline, "execute_renderer_candidate") as execute:
            renderer_pipeline.run_renderer_pipeline(
                self.temporary,
                candidates,
                should_cancel=lambda: True,
            )
        execute.assert_not_called()

    def test_one_candidate_failure_does_not_abort_scene_batch(self) -> None:
        candidates = [{"concept_id": f"c-{index}", "pipeline_state": "PENDING"} for index in range(3)]
        candidates_path = self.temporary / "pilot_candidates.json"
        candidates_path.write_text(json.dumps(candidates) + "\n", encoding="utf-8")
        calls = []

        def execute(_run_dir, candidate, _profile, **_kwargs):
            calls.append(candidate["concept_id"])
            durable = json.loads(candidates_path.read_text(encoding="utf-8"))
            current = next(item for item in durable if item["concept_id"] == candidate["concept_id"])
            if candidate["concept_id"] == "c-1":
                current["pipeline_state"] = "REVIEW_FAILED"
                candidates_path.write_text(json.dumps(durable) + "\n", encoding="utf-8")
                raise RuntimeError("review unavailable")
            current["pipeline_state"] = "APPROVED"
            candidates_path.write_text(json.dumps(durable) + "\n", encoding="utf-8")

        with patch.object(renderer_pipeline, "execute_renderer_candidate", side_effect=execute):
            renderer_pipeline.run_renderer_pipeline(
                self.temporary,
                candidates,
                continue_on_error=True,
            )

        self.assertEqual(calls, ["c-0", "c-1", "c-2"])
        mission = ProductionMission(mission_id="mission-flow", requested_assets=3)
        mission.source_runs = [self.temporary.name]
        with patch.object(mission_runner, "RUNS_DIR", self.temporary.parent):
            mission_runner._reconcile_candidate_totals(mission)
        self.assertEqual(mission.approved_assets, 2)
        self.assertEqual(mission.failed_runtime, 1)
        self.assertEqual(mission.selected_candidates, 3)


if __name__ == "__main__":
    unittest.main()
