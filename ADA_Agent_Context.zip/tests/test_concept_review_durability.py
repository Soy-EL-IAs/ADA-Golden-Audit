from __future__ import annotations

import asyncio
import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import main


ROOT = Path(__file__).resolve().parents[1]


class _Request:
    def __init__(self, decision: str):
        self.decision = decision

    async def json(self):
        return {"decision": self.decision}


class ConceptReviewDurabilityTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"concept-review-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.run_dir = self.temporary / "run-1"
        self.run_dir.mkdir()

    async def test_concurrent_concept_reviews_preserve_both_decisions(self) -> None:
        with patch.object(main, "RUNS_DIR", self.temporary):
            responses = await asyncio.gather(
                main.review_concept("run-1", "concept-a", _Request("approve")),
                main.review_concept("run-1", "concept-b", _Request("reject")),
            )

        self.assertEqual(responses, [{"status": "success"}, {"status": "success"}])
        reviews = json.loads((self.run_dir / "human_review.json").read_text(encoding="utf-8"))
        self.assertEqual(reviews["concept-a"]["decision"], "approve")
        self.assertEqual(reviews["concept-b"]["decision"], "reject")

    async def test_corrupt_review_is_quarantined_and_not_overwritten(self) -> None:
        review_file = self.run_dir / "human_review.json"
        corrupt_bytes = b'{"concept-a": {"decision": "approve"}'
        review_file.write_bytes(corrupt_bytes)

        with patch.object(main, "RUNS_DIR", self.temporary):
            response = await main.review_concept(
                "run-1", "concept-b", _Request("reject")
            )

        self.assertEqual(response.status_code, 409)
        quarantined = list(self.run_dir.glob("human_review.json.corrupt-*"))
        self.assertEqual(len(quarantined), 1)
        self.assertEqual(quarantined[0].read_bytes(), corrupt_bytes)
        self.assertFalse(review_file.exists())


if __name__ == "__main__":
    unittest.main()
