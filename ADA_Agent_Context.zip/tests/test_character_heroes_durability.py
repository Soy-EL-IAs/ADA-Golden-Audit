from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import character_capabilities
from ada_app.character_capabilities import (
    CharacterHeroesCorruptError,
    load_character_heroes,
    save_character_hero,
)


ROOT = Path(__file__).resolve().parents[1]


class CharacterHeroesDurabilityTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"heroes-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.heroes_path = self.temporary / "heroes.json"

    def test_save_rereads_and_preserves_existing_heroes(self) -> None:
        original = {"A": "asset-a", "B": "asset-b", "C": "asset-c"}
        self.heroes_path.write_text(json.dumps(original) + "\n", encoding="utf-8")

        with patch.object(character_capabilities, "HEROES_PATH", self.heroes_path):
            save_character_hero("D", "asset-d")

        self.assertEqual(
            json.loads(self.heroes_path.read_text(encoding="utf-8")),
            {**original, "D": "asset-d"},
        )

    def test_corrupt_heroes_are_quarantined_not_replaced(self) -> None:
        original = b'{"A": "asset-a"'
        self.heroes_path.write_bytes(original)

        with patch.object(character_capabilities, "HEROES_PATH", self.heroes_path):
            with self.assertRaises(CharacterHeroesCorruptError):
                save_character_hero("D", "asset-d")

        quarantined = list(self.temporary.glob("heroes.json.corrupt-*"))
        self.assertEqual(len(quarantined), 1)
        self.assertEqual(quarantined[0].read_bytes(), original)
        self.assertFalse(self.heroes_path.exists())


if __name__ == "__main__":
    unittest.main()
