from __future__ import annotations

import json
import shutil
import unittest
import uuid
import warnings
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from ada_app import asset_library, main, pilot_runner
from ada_app.asset_library import AssetLibrary
from ada_app.run_index import M2CreativeAdapter


ROOT = Path(__file__).resolve().parents[1]


class AtomicRunStorageTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"atomic-run-storage-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def _assert_atomic_writer(self, writer) -> None:
        destination = self.temporary / f"payload-{uuid.uuid4().hex}.json"
        previous = {"state": "previous"}
        destination.write_text(json.dumps(previous) + "\n", encoding="utf-8")
        original_replace = pilot_runner.os.replace
        observed: list[dict] = []

        def inspect_replace(source, target):
            if Path(target) == destination:
                observed.append(json.loads(destination.read_text(encoding="utf-8")))
            return original_replace(source, target)

        module = pilot_runner if writer is pilot_runner.write_json else main
        with patch.object(module.os, "replace", side_effect=inspect_replace):
            writer(destination, {"state": "new"})

        self.assertEqual(observed, [previous])
        self.assertEqual(json.loads(destination.read_text(encoding="utf-8")), {"state": "new"})
        self.assertFalse(list(self.temporary.glob(f"{destination.name}.*.tmp")))

    def test_pilot_and_api_json_writers_replace_atomically(self) -> None:
        self._assert_atomic_writer(pilot_runner.write_json)
        self._assert_atomic_writer(main.write_json)

    def test_corrupt_candidates_preserve_existing_live_assets_for_run(self) -> None:
        run_dir = self.temporary / "m2_degraded"
        run_dir.mkdir()
        (run_dir / "pilot_candidates.json").write_bytes(b'{"truncated"')
        image = self.temporary / "approved.png"
        image.write_bytes(b"image")
        previous = {
            "asset_id": "asset-existing",
            "source_run_id": "m2_degraded",
            "full_image_path": str(image),
            "thumbnail_path": str(image),
        }
        library = AssetLibrary.__new__(AssetLibrary)
        library.reviews = {}
        library.index = [previous]
        run = SimpleNamespace(run_id="m2_degraded", run_type="Pilot", artifact_root=str(run_dir))
        index_path = self.temporary / "index.json"

        with patch.object(asset_library, "INDEX_PATH", index_path), \
                patch.object(asset_library, "LIBRARY_RECORDS_ROOT", self.temporary / "records"), \
                patch.object(asset_library, "EXPLICIT_IMAGES_PATH", self.temporary / "explicit.json"), \
                patch.object(asset_library, "CHARACTERS_PATH", self.temporary / "characters.json"), \
                patch.object(asset_library.RunIndex, "get_all_runs", return_value=[run]), \
                warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = library.build_index()

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["asset_id"], "asset-existing")
        self.assertEqual(result[0]["library_index_status"], "DEGRADED_SOURCE")
        self.assertTrue(any("m2_degraded" in str(item.message) for item in caught))

    def test_corrupt_manifest_is_visible_as_degraded_run(self) -> None:
        run_dir = self.temporary / "m2_corrupt_manifest"
        run_dir.mkdir()
        (run_dir / "manifest.json").write_bytes(b"bad")
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            runs = M2CreativeAdapter(self.temporary).get_runs()

        self.assertEqual(len(runs), 1)
        self.assertEqual(runs[0].status, "DEGRADED")
        self.assertIn("Unreadable manifest", runs[0].error_state)

    def test_mission_index_failure_is_not_silently_reported_complete(self) -> None:
        source = (ROOT / "ada_app" / "mission_runner.py").read_text(encoding="utf-8")
        self.assertNotIn("except: pass\n        store.update", source)
        self.assertIn('final_status = "PARTIAL"', source)
        self.assertIn('"stage": "LIBRARY_INDEX"', source)


if __name__ == "__main__":
    unittest.main()
