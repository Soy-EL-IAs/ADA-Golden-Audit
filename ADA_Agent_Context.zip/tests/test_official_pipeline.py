import unittest
import json
from pathlib import Path
import re
from unittest.mock import patch, MagicMock

import sys
sys.path.insert(0, str(Path(__file__).parents[1]))

from ada_app.mission import ProductionMission, MissionStore
from ada_app.mission_runner import run_mission

ROOT = Path(__file__).parents[1]

class OfficialPipelineTests(unittest.TestCase):
    def setUp(self):
        self.store = MissionStore()
        
    def test_mission_persists_pipeline_id(self):
        mission = ProductionMission(character="2B", requested_assets=2, creation_mode="scene")
        self.store.save(mission)
        
        loaded = self.store.load(mission.mission_id)
        self.assertEqual(getattr(loaded, "pipeline_id", ""), "ada_mission_direct_v1")
        
        mission_stock = ProductionMission(character="2B", requested_assets=2, creation_mode="stock")
        self.store.save(mission_stock)
        
        loaded_stock = self.store.load(mission_stock.mission_id)
        self.assertEqual(getattr(loaded_stock, "pipeline_id", ""), "ada_mission_direct_v1")

    def test_resume_preserves_pipeline(self):
        mission = ProductionMission(character="2B", requested_assets=2)
        mission.pipeline_id = "ada_mission_direct_v1"
        self.store.save(mission)
        
        self.store.update(mission, status="RUNNING")
        loaded = self.store.load(mission.mission_id)
        self.assertEqual(getattr(loaded, "pipeline_id", ""), "ada_mission_direct_v1")

    @patch("ada_app.mission_runner.is_gpu_execution_busy", return_value=False)
    def test_unknown_pipeline_fails_early(self, mock_busy):
        mission = ProductionMission(character="2B", requested_assets=2)
        mission.pipeline_id = "unknown_pipeline_x"
        self.store.save(mission)
        
        # It should fail directly in run_mission before any rendering
        run_mission(mission.mission_id)
        
        loaded = self.store.load(mission.mission_id)
        self.assertEqual(loaded.status, "FAILED")
        self.assertIn("Unsupported pipeline", loaded.error_message)

    def test_ui_does_not_call_pilot_endpoints(self):
        app_js = (ROOT / "ada_app" / "static" / "app.js").read_text(encoding="utf-8")
        self.assertNotIn("/api/pilot/generate", app_js)
        self.assertNotIn("/api/pilot/resume", app_js)

    def test_no_productive_module_imports_pilot_runner(self):
        mission_runner = (ROOT / "ada_app" / "mission_runner.py").read_text(encoding="utf-8")
        self.assertNotIn("from ada_app.pilot_runner", mission_runner)
        self.assertNotIn("import ada_app.pilot_runner", mission_runner)
        
        renderer_pipeline = (ROOT / "ada_app" / "renderer_pipeline.py").read_text(encoding="utf-8")
        self.assertNotIn("from ada_app.pilot_runner", renderer_pipeline)
        self.assertNotIn("import ada_app.pilot_runner", renderer_pipeline)

    def test_no_productive_module_imports_specialist_orchestrator(self):
        import glob
        for py_file in ROOT.glob("ada_app/*.py"):
            content = py_file.read_text(encoding="utf-8")
            if py_file.name not in ["pilot_runner.py"]:
                self.assertNotIn("SpecialistOrchestrator", content)

    def test_config_contains_single_active_profile(self):
        profiles = json.loads((ROOT / "config" / "production_profiles.json").read_text(encoding="utf-8"))
        self.assertEqual(profiles.get("active_profile"), "ada_mission_direct_v1")
        
        active_count = 0
        for p in profiles["profiles"].values():
            if p.get("status") == "production":
                active_count += 1
        
        self.assertEqual(active_count, 1)
        
    def test_no_active_references_to_benchmarks(self):
        pipeline = json.loads((ROOT / "config" / "pipeline.json").read_text(encoding="utf-8"))
        for p in pipeline.get("renderers", {}).get("presets", {}).values():
            self.assertNotIn("benchmark_evidence", p)

if __name__ == "__main__":
    unittest.main()
