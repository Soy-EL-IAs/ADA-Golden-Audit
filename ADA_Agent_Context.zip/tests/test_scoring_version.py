from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import asset_library
from ada_app.asset_library import (
    AssetLibrary,
    CURRENT_SCORING_VERSION,
    LEGACY_SCORING_VERSION,
    prepare_hard_rating_comparison,
)
from scripts.migrate_asset_review_scoring_version import migrate


ROOT = Path(__file__).resolve().parents[1]


class ScoringVersionTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"scoring-version-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.review_path = self.temporary / "asset_review.json"

    def test_mismatched_scoring_versions_never_produce_numeric_delta(self) -> None:
        mismatch = prepare_hard_rating_comparison(
            {"final_score": 72},
            original_score=85,
            original_scoring_version=LEGACY_SCORING_VERSION,
        )
        self.assertIsNone(mismatch["delta"])
        self.assertEqual(mismatch["delta_unavailable_reason"], "scoring_version_mismatch")

        comparable = prepare_hard_rating_comparison(
            {"final_score": 72},
            original_score=85,
            original_scoring_version=CURRENT_SCORING_VERSION,
        )
        self.assertEqual(comparable["delta"], -13)
        self.assertNotIn("delta_unavailable_reason", comparable)

    def test_new_review_and_hard_history_are_stamped(self) -> None:
        self.review_path.write_text("{}\n", encoding="utf-8")
        library = AssetLibrary.__new__(AssetLibrary)
        library.index = [{"asset_id": "asset-1", "render_outputs": [], "stage_images": {}}]
        library.reviews = {}

        with patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "_backup_reviews_once"):
            review = library.save_review("asset-1", rating=8)
            review = library.save_hard_rating("asset-1", {"final_score": 80})

        self.assertEqual(review["scoring_version"], CURRENT_SCORING_VERSION)
        self.assertEqual(review["hard_rating"]["scoring_version"], CURRENT_SCORING_VERSION)
        self.assertEqual(review["hard_rating_history"][0]["scoring_version"], CURRENT_SCORING_VERSION)

    def test_migration_is_idempotent_and_preserves_entry_count(self) -> None:
        source = {
            "asset-1": {
                "status": "APPROVED",
                "hard_rating": {"final_score": 81},
                "hard_rating_history": [{"final_score": 79}],
            },
            "asset-2": "Favorite",
        }
        self.review_path.write_text(json.dumps(source, indent=2) + "\n", encoding="utf-8")
        backup_dir = self.temporary / "asset_review.backups"
        backup_dir.mkdir()
        (backup_dir / "asset_review-20260826T000000000000Z.json").write_bytes(
            self.review_path.read_bytes()
        )

        first = migrate(self.review_path)
        migrated_bytes = self.review_path.read_bytes()
        migrated = json.loads(migrated_bytes)
        second = migrate(self.review_path)

        self.assertTrue(first["changed"])
        self.assertFalse(second["changed"])
        self.assertEqual(self.review_path.read_bytes(), migrated_bytes)
        self.assertEqual(len(migrated), len(source))
        self.assertTrue(all(
            review["scoring_version"] == LEGACY_SCORING_VERSION
            for review in migrated.values()
        ))
        self.assertEqual(
            migrated["asset-1"]["hard_rating_history"][0]["scoring_version"],
            LEGACY_SCORING_VERSION,
        )

    def test_migration_refuses_to_run_without_a1_backup(self) -> None:
        original = b'{"asset-1": {}}\n'
        self.review_path.write_bytes(original)
        with self.assertRaisesRegex(RuntimeError, "A1 backup required"):
            migrate(self.review_path)
        self.assertEqual(self.review_path.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
