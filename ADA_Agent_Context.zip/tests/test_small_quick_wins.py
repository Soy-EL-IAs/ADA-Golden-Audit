from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from ada_app.m4_selection import select_top_candidates
from scripts import hard_re_evaluator


ROOT = Path(__file__).resolve().parents[1]


class SmallQuickWinsTests(unittest.TestCase):
    def test_dataset_selection_persists_viral_score(self) -> None:
        record = {
            "concept_id": "c1",
            "proposal": {
                "primary_hook": {"clarity": 9, "intensity": 8},
                "context_hook": {"clarity": 7, "intensity": 6},
            },
        }
        analysis = {
            "concepts": {
                "c1": {
                    "quality": {"score": 8},
                    "diversity": {"score": 7},
                    "recommendation": "KEEP",
                }
            }
        }

        selected = select_top_candidates([record], analysis, top_n=1)

        self.assertEqual(len(selected), 1)
        self.assertIsInstance(selected[0]["viral_score"], (int, float))

    def test_hard_review_records_effective_model(self) -> None:
        response = {
            "model": "visual-review-model",
            "choices": [{"message": {"content": '{"final_score": 88}'}}],
        }
        with patch.object(hard_re_evaluator, "_request", return_value=response), \
                patch.object(hard_re_evaluator, "image_data_url", return_value="data:image/png;base64,AA=="):
            result = hard_re_evaluator.evaluate_image(Path("unused.png"))

        self.assertEqual(result["model"], "visual-review-model")

    def test_frontend_exposes_live_counts_m3_and_hard_history(self) -> None:
        app_js = (ROOT / "ada_app" / "static" / "app.js").read_text(encoding="utf-8")
        library_js = (ROOT / "ada_app" / "static" / "renderer_library.js").read_text(encoding="utf-8")
        self.assertIn("data-mission-approved", app_js)
        self.assertIn("<th>Quality</th><th>Diversity</th>", app_js)
        self.assertIn("Hard Re-Evaluation history", library_js)


if __name__ == "__main__":
    unittest.main()
