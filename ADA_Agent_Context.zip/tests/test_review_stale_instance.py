from __future__ import annotations

import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import asset_library
from ada_app.asset_library import AssetLibrary


ROOT = Path(__file__).resolve().parents[1]


class ReviewStaleInstanceTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"review-stale-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)

    def test_stale_hard_rating_does_not_erase_new_human_rating(self) -> None:
        review_path = self.temporary / "asset_review.json"
        index_path = self.temporary / "index.json"
        explicit_path = self.temporary / "explicit.json"
        review_path.write_text("{}\n", encoding="utf-8")
        index_path.write_text(json.dumps([
            {"asset_id": "x", "record_type": "library_image_v2", "render_outputs": [], "stage_images": {}},
            {"asset_id": "y", "record_type": "library_image_v2", "render_outputs": [], "stage_images": {}},
        ]) + "\n", encoding="utf-8")

        with patch.object(asset_library, "REVIEW_PATH", review_path), \
                patch.object(asset_library, "INDEX_PATH", index_path), \
                patch.object(asset_library, "EXPLICIT_IMAGES_PATH", explicit_path), \
                patch.object(asset_library, "_backup_reviews_once"):
            stale = AssetLibrary()
            fresh = AssetLibrary()
            fresh.save_review("x", rating=8)
            stale.save_hard_rating("y", {"final_score": 81})

        persisted = json.loads(review_path.read_text(encoding="utf-8"))
        self.assertEqual(persisted["x"]["rating"], 8)
        self.assertEqual(persisted["y"]["hard_rating"]["final_score"], 81)


if __name__ == "__main__":
    unittest.main()
