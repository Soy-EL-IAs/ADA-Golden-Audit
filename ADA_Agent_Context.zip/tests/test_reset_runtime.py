"""Tests for safe runtime reset logic."""
from __future__ import annotations

import json
import shutil
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, MagicMock

import filelock

from scripts import ada_paths
from scripts.reset_runtime import build_reset_plan, execute_reset, run_reset_command, get_protected_roots, verify_postconditions

class DummyArgs:
    def __init__(self, execute=False, confirm="", host="127.0.0.1", port=8000):
        self.execute = execute
        self.confirm = confirm
        self.host = host
        self.port = port

class ResetRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = TemporaryDirectory()
        self.sandbox = Path(self.temp_dir.name).resolve()
        
        self.patchers = [
            patch("scripts.ada_paths.DATA_ROOT", self.sandbox / "data"),
            patch("scripts.ada_paths.MISSIONS_ROOT", self.sandbox / "data" / "missions"),
            patch("scripts.ada_paths.MISSION_RUNS_ROOT", self.sandbox / "data" / "runs" / "missions"),
            patch("scripts.ada_paths.RENDERER_RUNS_ROOT", self.sandbox / "data" / "runs" / "renderer"),
            patch("scripts.ada_paths.STOCK_RUNS_ROOT", self.sandbox / "data" / "runs" / "stock"),
            patch("scripts.ada_paths.REVIEW_RUNS_ROOT", self.sandbox / "data" / "runs" / "reviews"),
            patch("scripts.ada_paths.LIBRARY_ROOT", self.sandbox / "data" / "library"),
            patch("scripts.ada_paths.LIBRARY_ASSETS_ROOT", self.sandbox / "data" / "library" / "assets"),
            patch("scripts.ada_paths.LIBRARY_RECORDS_ROOT", self.sandbox / "data" / "library" / "records"),
            patch("scripts.ada_paths.INDEXES_ROOT", self.sandbox / "data" / "indexes"),
            patch("scripts.ada_paths.TMP_ROOT", self.sandbox / "data" / "tmp"),
            patch("scripts.ada_paths.LOCKS_ROOT", self.sandbox / "data" / "tmp" / "locks"),
            patch("scripts.ada_paths.LOGS_ROOT", self.sandbox / "data" / "logs"),
            patch("scripts.ada_paths.CHARACTERS_ROOT", self.sandbox / "data" / "characters"),
            patch("scripts.ada_paths.REFERENCES_ROOT", self.sandbox / "data" / "references"),
            patch("scripts.reset_runtime.check_ada_server", return_value=False),
            patch("scripts.reset_runtime.check_comfy_queue", return_value=False),
            patch("scripts.reset_runtime.check_active_missions", return_value=False),
        ]
        for p in self.patchers:
            p.start()
            
        ada_paths.MISSIONS_ROOT.mkdir(parents=True)
        (ada_paths.MISSIONS_ROOT / "mission_1.json").write_text("{}", encoding="utf-8")
        (ada_paths.MISSIONS_ROOT / "README.md").write_text("Hello", encoding="utf-8")
        
        ada_paths.LIBRARY_ROOT.mkdir(parents=True)
        (ada_paths.LIBRARY_ROOT / "index.json").write_text("something", encoding="utf-8")
        (ada_paths.LIBRARY_ROOT / "migration_manifest.json").write_text("old", encoding="utf-8")
        
        ada_paths.CHARACTERS_ROOT.mkdir(parents=True)
        (ada_paths.CHARACTERS_ROOT / "heroes.json").write_text("heroes", encoding="utf-8")
        (ada_paths.CHARACTERS_ROOT / "catalog.json").write_text("keep this", encoding="utf-8")
        
        ada_paths.REFERENCES_ROOT.mkdir(parents=True)
        (ada_paths.REFERENCES_ROOT / "ref.png").write_text("png", encoding="utf-8")

        ada_paths.LOCKS_ROOT.mkdir(parents=True)
        ada_paths.LOGS_ROOT.mkdir(parents=True)
        (ada_paths.LOGS_ROOT / "old.log").write_text("log data", encoding="utf-8")
        
        (ada_paths.DATA_ROOT / "reset_receipts").mkdir(parents=True)

    def tearDown(self):
        for p in self.patchers:
            p.stop()
        self.temp_dir.cleanup()

    def test_dry_run_does_not_modify_files(self):
        args = DummyArgs(execute=False)
        with patch("builtins.print"):
            run_reset_command(args)
        self.assertTrue((ada_paths.MISSIONS_ROOT / "mission_1.json").exists())

    def test_invalid_confirm_does_not_modify_files(self):
        args = DummyArgs(execute=True, confirm="WRONG")
        with patch("builtins.print"):
            run_reset_command(args)
        self.assertTrue((ada_paths.MISSIONS_ROOT / "mission_1.json").exists())

    def test_unsafe_path_outside_data_root_rejected(self):
        outside_path = self.sandbox / "outside"
        with patch("scripts.ada_paths.MISSIONS_ROOT", outside_path):
            plan = build_reset_plan(DummyArgs())
            self.assertTrue(any("is not safe to delete" in err for err in plan["errors"]))

    def test_active_mission_blocks_execution(self):
        with patch("scripts.reset_runtime.check_active_missions", return_value=True):
            plan = build_reset_plan(DummyArgs())
            self.assertTrue(any("MissionStore reports active" in err for err in plan["errors"]))

    def test_comfy_queue_busy_blocks_execution(self):
        with patch("scripts.reset_runtime.check_comfy_queue", return_value=True):
            plan = build_reset_plan(DummyArgs())
            self.assertTrue(any("ComfyUI queue has active" in err for err in plan["errors"]))

    def test_ada_server_active_blocks_execution(self):
        with patch("scripts.reset_runtime.check_ada_server", return_value=True):
            plan = build_reset_plan(DummyArgs(host="127.0.0.1", port=8000))
            self.assertTrue(any("ADA server is active" in err for err in plan["errors"]))

    def test_logs_cleared(self):
        plan = build_reset_plan(DummyArgs())
        execute_reset(plan)
        self.assertFalse((ada_paths.LOGS_ROOT / "old.log").exists())
        self.assertTrue(ada_paths.LOGS_ROOT.exists())

    def test_deletion_error_yields_failure(self):
        plan = build_reset_plan(DummyArgs())
        with patch("pathlib.Path.unlink", side_effect=OSError("Permission denied")):
            receipt = execute_reset(plan)
            self.assertEqual(receipt["result"], "failed")

    def test_symlink_escape_not_traversed(self):
        outside_dir = self.sandbox / "outside"
        outside_dir.mkdir()
        (outside_dir / "secret.txt").write_text("secret")
        
        symlink_path = ada_paths.MISSIONS_ROOT / "symlink_dir"
        try:
            import os
            os.symlink(str(outside_dir), str(symlink_path), target_is_directory=True)
        except OSError:
            return

        plan = build_reset_plan(DummyArgs())
        execute_reset(plan)
        self.assertFalse(symlink_path.exists() and symlink_path.is_symlink())
        self.assertTrue((outside_dir / "secret.txt").exists())

    def test_gpu_lock_held_throughout(self):
        lock_path = ada_paths.LOCKS_ROOT / "gpu_execution.lock"
        ada_paths.LOCKS_ROOT.mkdir(parents=True, exist_ok=True)
        lock = filelock.FileLock(str(lock_path))
        with lock.acquire():
            args = DummyArgs(execute=True, confirm="RESET-ADA-RUNTIME")
            with patch("builtins.print"):
                exit_code = run_reset_command(args)
                self.assertEqual(exit_code, 1) 
                
    # NEW TESTS REQUIRED
    
    def test_reset_does_not_eliminate_acquired_gpu_lock(self):
        gpu_lock_path = ada_paths.LOCKS_ROOT / "gpu_execution.lock"
        ada_paths.LOCKS_ROOT.mkdir(parents=True, exist_ok=True)
        gpu_lock_path.write_text("", encoding="utf-8")
        
        args = DummyArgs(execute=True, confirm="RESET-ADA-RUNTIME")
        plan = build_reset_plan(args)
        
        paths = [str(p) for p in plan["to_delete"]]
        self.assertNotIn(str(gpu_lock_path), paths)

    def test_plan_built_within_lock_section(self):
        args = DummyArgs(execute=True, confirm="RESET-ADA-RUNTIME")
        with patch("scripts.reset_runtime.build_reset_plan") as mock_build:
            mock_build.return_value = {"errors": [], "to_delete": [], "directories_to_clean": [], "files_to_recreate": {}, "bytes_freed":0, "dirs_count":0, "files_count":0}
            with patch("builtins.print"):
                run_reset_command(args)
            self.assertTrue(mock_build.called)

    def test_plan_does_not_contain_duplicates(self):
        plan = build_reset_plan(DummyArgs())
        paths = [str(p) for p in plan["to_delete"]]
        self.assertEqual(len(paths), len(set(paths)))

    def test_missionstore_exception_blocks_execution(self):
        with patch("scripts.reset_runtime.check_active_missions", side_effect=Exception("Database down")):
            plan = build_reset_plan(DummyArgs())
            self.assertTrue(any("failed to check missions" in err for err in plan["errors"]))

    def test_port_8000_blocks_even_if_alternative_port_passed(self):
        def mock_check_server(host, port):
            return port == 8000
            
        with patch("scripts.reset_runtime.check_ada_server", side_effect=mock_check_server):
            args = DummyArgs(execute=True, confirm="RESET-ADA-RUNTIME", port=9999)
            plan = build_reset_plan(args)
            self.assertTrue(any("ADA server is active on 127.0.0.1:8000" in err for err in plan["errors"]))

    def test_unfulfilled_postcondition_yields_failure(self):
        plan = build_reset_plan(DummyArgs(execute=True))
        
        original_verify = verify_postconditions
        def mock_verify():
            ada_paths.MISSIONS_ROOT.mkdir(parents=True, exist_ok=True)
            (ada_paths.MISSIONS_ROOT / "illegal.json").write_text("{}")
            return original_verify()
            
        with patch("scripts.reset_runtime.verify_postconditions", side_effect=mock_verify):
            receipt = execute_reset(plan)
            self.assertEqual(receipt["result"], "failed")
            self.assertTrue(any("Mission file left behind: illegal.json" in e for e in receipt["errors"]))

    def test_empty_library_reconstruction_keeps_zero_assets(self):
        plan = build_reset_plan(DummyArgs())
        execute_reset(plan)
        
        ada_paths.LEGACY_ROOT.mkdir(parents=True, exist_ok=True)
        fake_legacy = ada_paths.LEGACY_ROOT / "fake_legacy.json"
        fake_legacy.write_text("{}")
        self.addCleanup(lambda: fake_legacy.unlink(missing_ok=True))
        
        import ada_app.asset_library as al
        
        with patch("ada_app.asset_library.LIBRARY_ROOT", ada_paths.LIBRARY_ROOT), \
             patch("ada_app.asset_library.LIBRARY_ASSETS_ROOT", ada_paths.LIBRARY_ASSETS_ROOT), \
             patch("ada_app.asset_library.LIBRARY_RECORDS_ROOT", ada_paths.LIBRARY_RECORDS_ROOT), \
             patch("ada_app.asset_library.CHARACTERS_PATH", ada_paths.CHARACTERS_ROOT / "catalog.json"), \
             patch("ada_app.asset_library.INDEX_PATH", ada_paths.LIBRARY_ROOT / "index.json"), \
             patch("ada_app.asset_library.EXPLICIT_IMAGES_PATH", ada_paths.LIBRARY_ROOT / "explicit_images.json"), \
             patch("ada_app.asset_library.REVIEW_PATH", ada_paths.LIBRARY_ROOT / "asset_review.json"), \
             patch("ada_app.asset_library.LOCKS_ROOT", ada_paths.LOCKS_ROOT), \
             patch("ada_app.asset_library.MISSION_RUNS_ROOT", ada_paths.MISSION_RUNS_ROOT), \
             patch("ada_app.asset_library.STOCK_RUNS_ROOT", ada_paths.STOCK_RUNS_ROOT), \
             patch("ada_app.asset_library.RENDERER_RUNS_ROOT", ada_paths.RENDERER_RUNS_ROOT), \
             patch("ada_app.run_index.MISSION_RUNS_ROOT", ada_paths.MISSION_RUNS_ROOT):
            
            lib = al.AssetLibrary()
            lib.index = None
            self.assertEqual(len(lib.get_assets()), 0)

    def test_characters_references_and_readme_remain_intact(self):
        plan = build_reset_plan(DummyArgs(execute=True))
        execute_reset(plan)
        self.assertTrue((ada_paths.CHARACTERS_ROOT / "catalog.json").exists())
        self.assertTrue((ada_paths.REFERENCES_ROOT / "ref.png").exists())
        self.assertTrue((ada_paths.MISSIONS_ROOT / "README.md").exists())

if __name__ == "__main__":
    unittest.main()
