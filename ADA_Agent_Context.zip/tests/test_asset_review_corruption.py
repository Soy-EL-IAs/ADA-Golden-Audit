from __future__ import annotations

import asyncio
import json
import shutil
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import asset_library, main
from ada_app.asset_library import AssetLibrary, AssetReviewCorruptError


ROOT = Path(__file__).resolve().parents[1]


class AssetReviewCorruptionTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"asset-review-corruption-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.review_path = self.temporary / "asset_review.json"
        self.index_path = self.temporary / "index.json"

    def _construct_library(self) -> AssetLibrary:
        with patch.object(asset_library, "LIBRARY_DIR", self.temporary), \
                patch.object(asset_library, "REVIEW_PATH", self.review_path), \
                patch.object(asset_library, "INDEX_PATH", self.index_path), \
                patch.object(asset_library, "EXPLICIT_IMAGES_PATH", self.temporary / "explicit_images.json"):
            return AssetLibrary()

    def test_missing_review_file_is_a_valid_empty_library(self) -> None:
        library = self._construct_library()
        self.assertEqual(library.reviews, {})
        self.assertFalse(self.review_path.exists())

    def test_truncated_review_file_is_preserved_and_raises(self) -> None:
        corrupt_bytes = b'{"a": {"stat'
        self.review_path.write_bytes(corrupt_bytes)

        with self.assertRaises(AssetReviewCorruptError) as raised:
            self._construct_library()

        self.assertFalse(self.review_path.exists())
        self.assertIsNotNone(raised.exception.backup_path)
        self.assertEqual(raised.exception.backup_path.read_bytes(), corrupt_bytes)
        self.assertIn(str(self.review_path), str(raised.exception))

    def test_parseable_non_object_review_file_is_preserved_and_raises(self) -> None:
        self.review_path.write_text("[]\n", encoding="utf-8")

        with self.assertRaises(AssetReviewCorruptError) as raised:
            self._construct_library()

        self.assertEqual(json.loads(raised.exception.backup_path.read_text(encoding="utf-8")), [])

    def test_library_endpoint_returns_503_with_preserved_path(self) -> None:
        corrupt = AssetReviewCorruptError(
            self.review_path,
            self.temporary / "asset_review.json.corrupt-test",
            ValueError("truncated"),
        )
        with patch.object(main, "AssetLibrary", side_effect=corrupt):
            response = asyncio.run(main.get_library_assets())

        self.assertEqual(response.status_code, 503)
        body = json.loads(response.body)
        self.assertEqual(body["error"], "asset_review_corrupt")
        self.assertEqual(body["backup_path"], str(corrupt.backup_path))


if __name__ == "__main__":
    unittest.main()
