from __future__ import annotations

import json
import shutil
import sys
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from ada_app import mission_runner
from ada_app.mission import MissionStore, ProductionMission


ROOT = Path(__file__).resolve().parents[1]


class MissionFilelockTests(unittest.TestCase):
    def test_missing_filelock_marks_mission_failed(self) -> None:
        test_root = ROOT / "data" / "tmp" / "tests" / f"ada-filelock-{uuid.uuid4().hex}"
        missions_dir = test_root / "missions"
        self.addCleanup(shutil.rmtree, test_root, True)

        mission = ProductionMission(character="2B", requested_assets=1)
        with patch("ada_app.mission.MISSIONS_DIR", missions_dir):
            MissionStore().save(mission)

        with patch("ada_app.mission.MISSIONS_DIR", missions_dir), \
                patch.dict(sys.modules, {"filelock": None}), \
                patch.object(mission_runner.traceback, "print_exc"):
            mission_runner.run_mission(mission.mission_id)

        persisted = json.loads((missions_dir / f"{mission.mission_id}.json").read_text(encoding="utf-8"))
        self.assertEqual(persisted["status"], "FAILED")
        self.assertIn("filelock", persisted["error_message"])
        self.assertIsNotNone(persisted["completed_at"])


if __name__ == "__main__":
    unittest.main()
