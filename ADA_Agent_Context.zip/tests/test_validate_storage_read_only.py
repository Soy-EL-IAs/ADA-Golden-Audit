from __future__ import annotations

import io
import json
import shutil
import unittest
import uuid
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

from scripts import validate_storage


ROOT = Path(__file__).resolve().parents[1]


class ValidateStorageReadOnlyTests(unittest.TestCase):
    def setUp(self) -> None:
        parent = ROOT / "data" / "tmp" / "tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.temporary = parent / f"validate-storage-{uuid.uuid4().hex}"
        self.temporary.mkdir()
        self.addCleanup(shutil.rmtree, self.temporary, True)
        self.library = self.temporary / "library"
        self.characters = self.temporary / "characters"
        self.missions = self.temporary / "missions"
        self.references = self.temporary / "references"
        for path in (self.library, self.characters, self.missions, self.references):
            path.mkdir()
        (self.characters / "catalog.json").write_text("{}\n", encoding="utf-8")

    def _patch_paths(self):
        return patch.multiple(
            validate_storage,
            LIBRARY_ROOT=self.library,
            LIBRARY_RECORDS_ROOT=self.library / "records",
            LIBRARY_ASSETS_ROOT=self.library / "assets",
            CHARACTERS_ROOT=self.characters,
            MISSIONS_ROOT=self.missions,
            REFERENCES_ROOT=self.references,
            ADA_ROOT=self.temporary,
        )

    def test_missing_index_returns_distinct_code_without_creating_it(self) -> None:
        before = sorted(str(path.relative_to(self.temporary)) for path in self.temporary.rglob("*"))
        output = io.StringIO()
        with self._patch_paths(), redirect_stdout(output):
            code = validate_storage.main()
        after = sorted(str(path.relative_to(self.temporary)) for path in self.temporary.rglob("*"))

        self.assertEqual(code, 2)
        self.assertEqual(json.loads(output.getvalue())["status"], "missing_index")
        self.assertEqual(before, after)
        self.assertFalse((self.library / "index.json").exists())

    def test_validator_source_never_constructs_asset_library(self) -> None:
        source = (ROOT / "scripts" / "validate_storage.py").read_text(encoding="utf-8")
        self.assertNotIn("AssetLibrary()", source)
        self.assertIn("LIBRARY_RECORDS_ROOT.glob", source)


if __name__ == "__main__":
    unittest.main()
