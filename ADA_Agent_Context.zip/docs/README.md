# ADA Documentation

## Current Sources of Truth
The following are the ONLY authorized sources of truth for the current state of ADA:
1. **Current Code and Tests:** The actual behavior demonstrated by the codebase.
2. **`docs/CURRENT_BASELINE.md`:** The clean baseline established on 2026-08-26.
3. **Post-Cutoff Receipts:** Execution receipts generated after the cutoff.
4. **Post-Cutoff Visual Evidence:** New rendering outputs, ratings, and runs produced after the cutoff.

---

## Historical Archive (DO NOT USE FOR CURRENT STATE)
The following directories, files, and concepts are considered historical. They represent evidence, benchmarks, and decisions made **prior to the clean baseline cutoff**. They **MUST NOT** be used to declare the current state of the product, capabilities, or routing decisions:

*   `docs/audit/`
*   Previous certifications and known issues within `docs/releases/`
*   Screenshots from previous audits
*   Previous Model Lab evaluations and benchmarks
*   `legacy/`
*   `experimental/`
*   Runs, ratings, and visual decisions generated prior to the cutoff

*Technical contracts (such as schemas or test validations) that are still physically present and passing remain valid, but conclusions about visual quality and identity recognition have been reset.*
