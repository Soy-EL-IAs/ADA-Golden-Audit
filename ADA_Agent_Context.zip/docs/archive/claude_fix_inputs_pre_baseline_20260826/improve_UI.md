# Mejoras de UI — derivadas de FASE 5 (UX y Observabilidad)

Documento de **propuesta**. No se ha escrito ni modificado una sola línea del proyecto:
todo lo que sigue es descripción, no implementación.

Raíz auditada: `C:\Users\elias.bojko\Documents\Test Laboratory IA\ADA-Golden-Audit`
Fuente única de problemas: `audit/05_UX_OBSERVABILITY.md` (1011 líneas, leído completo).
Superficie verificada: `ada_app/templates/index.html` (573), `ada_app/static/app.js` (1883),
`ada_app/static/renderer_library.js` (262), `ada_app/static/style.css` (670) = 3388 líneas.
Todas las citas `archivo:línea` de 05 que se usan aquí se han comprobado contra el código;
las discrepancias encontradas están en §B.

**Regla aplicada:** cada mejora responde a un hallazgo concreto de 05. No hay ninguna
propuesta que 05 no documente. Los hallazgos de 05 que deliberadamente **no** se han
convertido en mejora están listados en §D con su motivo.

**Frontera con `FIXES.md`:** los tres asuntos asignados a ese documento (lost-update de
`store.update` sobre `cancelled=True`; misión que muere en `PRODUCING` e irrecuperable;
`continue_on_error=False` descartando los contadores de la ronda) **no se proponen aquí**.
Donde una mejora roza esa frontera se marca en una línea con `⚠ frontera con FIXES.md`.
Resumen de fronteras en §C.

---

## A. Tabla resumen y orden

Escala de esfuerzo: **S** ≈ hasta ~30 líneas en 1–2 archivos · **M** ≈ ~30–120 líneas
o 3 archivos · **L** = necesita backend nuevo o >120 líneas.
Ratio = (lo que ahorra en el uso diario) / (esfuerzo). El orden del documento es el de
la columna Ratio.

| # | Mejora | Hallazgo 05 | Esfuerzo | ¿Backend? | Ratio |
|---|---|---|---|---|---|
| 1 | Destino real tras crear un batch (`switchTab('queue')`) | 1.2 (Alto) | S (~2 líneas, 1 archivo) | No | **Máximo** |
| 2 | "View Assets in Library" que abra la Library ya filtrada | 2.4.1 (Alto) | S (~2 líneas, 1 archivo) | No | **Máximo** |
| 3 | Definir las 3 variables CSS y las 2 clases ausentes | 6.4, 6.5 (Medio) | S (~14 líneas, 1 archivo) | No | **Muy alto** |
| 4 | Cortar el polling de misión al salir de la pantalla | 3.1.1 (Medio) | S (~6 líneas, 1 archivo) | No | **Muy alto** |
| 5 | Progreso vivo durante `PRODUCING` con datos que ya se piden | §3.2 (Crítico), §3.4, 3.3.2, 3.3.3 | M (~110 líneas, 1 archivo) | No | **Alto** |
| 6 | Panel de error de misión que no se quede vacío ni pierda el detalle | 4.2.1 p.3, 4.2.2, O4 | S frontend / L con backend | Opcional | **Alto** |
| 7 | Comprobar `resp.ok` en los endpoints de misión | 8.3.3 (Alto) | S (~30 líneas, 1 archivo) | No | **Alto** |
| 8 | Distinguir el rechazo de máquina en la Library | 6.1 (Alto) | M (~50 líneas, 3 archivos) | No | **Alto** |
| 9 | Estados de carga y de fallo en los cargadores mudos | §8.2, 8.3.1, 8.3.2 | M (~70 líneas, 2 archivos) | No | Medio-alto |
| 10 | Escapar el texto del modelo en los 6 huecos restantes | 6.3 (Medio) | S (~8 ediciones, 1 archivo) | No | Medio-alto |
| 11 | Salida desde `mission-detail` (pantalla huérfana) | 1.1 (Medio) | S (~5 líneas, 2 archivos) | No | Medio |
| 12 | Columna "Machine review" del funnel, que hoy es siempre `—` | 3.3.1 (Medio) | S (~5 líneas) | **Sí, solo backend** | Medio |
| 13 | Completar la procedencia del modal (`original_score`, escalas, workflow) | 7.1.1, 6.2, §7.1 | S (~6 líneas, 1 archivo) | No | Medio |
| 14 | Feedback durante el Hard Re-Evaluate por lotes | 7.1.4 (Medio) | S honesto / L real | Solo para progreso real | Medio-bajo |
| 15 | Motivo real del fallo de "Set as hero" | 2.5.1 (Alto) | S (1 línea backend + 3 frontend) | **Sí, 1 línea** | Medio-bajo |
| 16 | Reintento por candidato desde el funnel | 5.2 (Alto) | **L** (endpoint nuevo) | **Sí, sustancial** | Bajo |

---

## 1. Destino real tras crear un batch de misiones

**Qué problema resuelve.** `ada_app/static/app.js:586` ejecuta
`if (successCount > 0) switchTab('queue');` al terminar el batch del modo
Dataset / Auto Concepts (`index.html:239`). Verificado: **no existe ningún elemento con
`id="queue"`** en `index.html` (`grep queue` sobre la plantilla: 0 resultados).
`switchTab` (`app.js:32-40`) quita `.active` de todos los `.tab-content` y luego
`document.getElementById('queue')` devuelve `null`, que el `if (el)` de `app.js:39`
ignora en silencio. Coste diario: el usuario acaba de lanzar N misiones —el único flujo
capaz de lanzarlas en lote— y se queda con **el área de contenido completamente en
blanco**, sin ninguna de las N misiones a la vista y sin más salida que el sidebar. Es
el peor momento posible para perder el hilo: son las misiones más caras del sistema.

**Archivos del frontend que se tocan.** `ada_app/static/app.js`, el handler de
`#btn-create-mission` (bloque `app.js:560-595`), línea 586. El destino correcto ya
existe: `switchTab('home')` + `loadActiveMissions()` (`app.js:49`), que es donde viven
las tarjetas de las misiones recién creadas; o `openMissionDetail(lastId)` reutilizando
`lastId`, que el propio bucle ya calcula en `app.js:577` y hoy no usa para nada.

**Esfuerzo.** **S: ~2 líneas en un archivo.** Sin backend. Es la mejor relación
valor/esfuerzo del informe: una línea evita una pantalla en blanco en el flujo más caro.

---

## 2. "View Assets in Library" que abra la Library ya filtrada

**Qué problema resuelve.** `openMissionLibrary` (`app.js:812-817`) fija
`libraryMissionFilter = missionId`, limpia los otros dos filtros y llama
`switchTab('library')` — y nada más. `switchTab` (`app.js:32-40`) **sólo cambia clases
CSS**; el único sitio que llama `loadLibrary()` al entrar en Library es el handler del
sidebar (`app.js:22`). Resultado verificado: al pulsar el botón principal de la pantalla
de éxito de la misión (`app.js:708`), la Library se pinta con `allAssets` de la última
carga —**vacía en la primera visita de la sesión**— y el filtro por misión no se aplica
hasta que el usuario haga clic manualmente en "Library" en el sidebar. Coste diario: al
final de **cada misión completada** el usuario ve una Library vacía o desactualizada y
tiene que aprender el truco de re-clicar el sidebar; y cuando lo hace, el filtro por
misión ya se ha aplicado sobre otro conjunto y sus imágenes nuevas quedan mezcladas con
todo el histórico. El patrón correcto ya existe 80 líneas más abajo:
`openLibraryCollection` (`app.js:891-900`) llama `loadLibrary()` tras `switchTab`.

**Archivos del frontend que se tocan.** `ada_app/static/app.js`, función
`openMissionLibrary` (`app.js:812-817`): añadir el `await loadLibrary()` que
`openLibraryCollection` sí tiene. Conviene además que la Library indique que hay un
filtro de misión activo, porque hoy `libraryMissionFilter` no tiene ningún reflejo
visual en `index.html:118-127` — el usuario no puede saber que está viendo un
subconjunto. Eso son unas 10 líneas más (una "chip" de filtro activo con su botón de
quitar, junto a `#library-filters`).

**Esfuerzo.** **S: ~2 líneas** para el arreglo del recargado; ~12 con el indicador de
filtro activo. Sin backend. Afecta al final de cada misión, así que se paga solo el
primer día.

---

## 3. Definir las 3 variables CSS y las 2 clases que se usan y no existen

**Qué problema resuelve.** Verificado línea a línea:

| Símbolo | Definido en `style.css` | Usos reales |
|---|---|---|
| `--border-color` | **No** (`:root` en `style.css:1-15` define `--border`, no `--border-color`) | `renderer_library.js:63, 67, 85, 109`; `index.html:237` |
| `--danger` | **No** | `renderer_library.js:74`, `renderer_library.js:78` (×2) |
| `--bg-panel` | **No** | `renderer_library.js:78` |
| `.error` | **No** (0 reglas) | `app.js:235`, `app.js:1516` |
| `.btn-warning` | **No** (0 reglas) | `index.html:133`, `index.html:170`, `renderer_library.js:71` |

Consecuencia diaria: los cuatro separadores del modal de imagen y el borde del bloque de
sub-scores Hard **no se dibujan** (el modal se ve como un muro de texto sin jerarquía);
el mensaje de error del Hard Re-Evaluate (`renderer_library.js:74`) y el banner
persistente "Evaluation failed" (`renderer_library.js:78`) salen en color de texto
normal, sin fondo y sin borde izquierdo — es decir, **los indicadores de error del único
flujo del sistema con buen manejo de errores no se ven como errores**; "Could not load
Characters" y "Could not load Model Lab" se leen como un párrafo cualquiera; y los tres
botones de Hard Re-Evaluate son visualmente idénticos a un botón neutro, junto a un
`.btn-danger` que sí tiene estilo. El coste es que el usuario no distingue "ha fallado"
de "no hay datos" en las pantallas donde eso más importa.

**Archivos del frontend que se tocan.** `ada_app/static/style.css` únicamente: añadir
`--border-color`, `--danger` y `--bg-panel` al bloque `:root` (`style.css:1-15`) —lo
natural es aliasarlas a `--border`, `--error` y `--card-bg`, que ya existen— y dos reglas
nuevas `.error` y `.btn-warning`, junto a las de `.btn` y `.badge` ya presentes
(`style.css:112-122` para el patrón de color). Alternativa equivalente: renombrar los 8
usos en `renderer_library.js` e `index.html:237`; es más invasivo y toca dos archivos
más, por lo que se prefiere definir las variables.

**Esfuerzo.** **S: ~14 líneas en un archivo.** Sin backend. Ratio muy alto: es CSS puro
y repara la visibilidad de *todos* los estados de error existentes.

---

## 4. Cortar el polling de misión al salir de la pantalla

**Qué problema resuelve.** `openMissionDetail` (`app.js:657-664`) arranca
`setInterval(refreshMissionDetail, 3000)` (`app.js:663`). El handler del sidebar
(`app.js:11-30`) **no** limpia `missionPollInterval`; sólo se limpia al abrir otra misión
(`app.js:661`), al llegar a estado terminal (`app.js:711`) y al borrar la misión
(`app.js:789-791`). Verificado. Coste diario, y es el escenario normal —abrir una misión
de 20 minutos e irse a trabajar a la Library—: cada 3 segundos, indefinidamente,
`refreshMissionDetail` hace `GET /api/missions/{id}` y `loadMissionFunnel` hace
`GET /api/missions/{id}/funnel` (`app.js:1461`). Ese segundo endpoint
(`main.py:294-327`) instancia `AssetLibrary()` y llama `get_assets(mission_id=...)`, que
con el índice vacío dispara `build_index()` (`asset_library.py:834-836`), un escaneo
completo del disco. Son ≈800 peticiones por cada 20 minutos, contra la misma máquina que
está renderizando, y además `app.js:755` sigue reescribiendo el `innerHTML` de un panel
oculto. Si el usuario abre tres misiones a lo largo de la sesión, sólo la última queda
viva… pero esa queda viva para siempre.

**Archivos del frontend que se tocan.** `ada_app/static/app.js`: el handler de
`.sidebar li` (`app.js:11-30`), añadiendo la limpieza del intervalo cuando el destino no
es `mission-detail`; y `switchTab` (`app.js:32-40`), que es la otra puerta de salida
(la usan `openMissionLibrary` y `openLibraryCollection`). Lo limpio es centralizar el
`clearInterval` en un punto por el que pasen ambas.

**Esfuerzo.** **S: ~6 líneas en un archivo.** Sin backend. Además de la UI, quita carga
de disco al proceso que está produciendo imágenes.

---

## 5. Progreso vivo durante `PRODUCING`, con datos que la UI ya está pidiendo

**Qué problema resuelve.** El hallazgo central de 05 (§3.2, Crítico): en una misión
Scene, entre `mission_runner.py:320-322` (`PRODUCING`, "Round 1: Producing N
candidates...") y `mission_runner.py:362` ("Round 1 complete") **no hay ninguna
escritura de estado**, porque `run_renderer_pipeline` (`mission_runner.py:331-337`) es
síncrono y bloqueante. `progress` es `approved_assets / requested_assets`
(`mission.py:81-83`) y `approved_assets` sólo se incrementa al cerrar la ronda
(`mission_runner.py:353`, verificado). Resultado: **durante ~90 % de la misión la barra
está a 0 % y `current_stage_detail` no cambia una letra** (`app.js:721`, `app.js:723`);
después salta de golpe a 83 %. El usuario no puede distinguir "renderizando la imagen
7 de 12" de "el proceso murió hace un cuarto de hora", y la reacción natural —cerrar la
ventana de consola y reintentar— es justo la que deja la misión clavada.

Lo importante: **el dato vivo ya está llegando al navegador**. Verificado:

- `loadMissionFunnel` (`app.js:1456-1467`) ya pide `GET /api/missions/{id}/funnel` cada
  3 s, y ese endpoint (`main.py:294-327`) lee `pilot_candidates.json` de los
  `mission.source_runs`, que se persisten **antes** de producción; devuelve
  `pipeline_state` por concepto, que transita `SELECT` →
  `RENDERED_PENDING_REVIEW` → `APPROVED` / `REJECTED_QUALITY` / `FAILED_RUNTIME`
  (`renderer_pipeline.py:184, 231, 215, 53-55`). Es granularidad por candidato, en vivo,
  ya en memoria del cliente y hoy sólo se usa para pintar una tabla de texto crudo.
- `duration_seconds` (`mission.py:89-97`) se calcula contra `datetime.now()` cuando
  `completed_at` está vacío, o sea que **es un cronómetro vivo**; `app.js:687` lo
  calcula en cada tick y `app.js:706` sólo lo pinta en la rama terminal.
- El componente que hace exactamente esto ya existe en el proyecto: `pollPilot`
  (`app.js:1730-1762`) pinta, en Creative Lab, una tarjeta por candidato con miniatura,
  `pipeline_state`, contador de retries y `retry_reason`, leyendo
  `GET /api/runs/{run_id}/pilot` (`main.py:699-704`).

**Qué se propone**, todo dentro de lo que 05 documenta como ausente (§3.4):
(a) derivar de los `pipeline_state` del funnel un contador de fase —"Rendered 7/12 ·
approved 4 · rejected 2 · in flight 1"— y usarlo como segunda barra o como texto bajo
`.mission-status`, en vez de dejar `current_stage_detail` congelado; (b) destacar el
candidato en vuelo (`RENDERED_PENDING_REVIEW`), que 05 señala como existente en disco y
no resaltado; (c) mostrar el tiempo transcurrido en vivo en la rama no terminal; (d) al
reconstruir esa zona, arreglar de paso los dos hallazgos Bajos del funnel: pasar
`item.pipeline_state` por `runStatusLabel` (`app.js:1636-1643`, ya escrito y usado sólo
en Runs, `app.js:1659`) en lugar de imprimir `SELECT` y `RENDERED_PENDING_REVIEW` en
crudo (3.3.3), y actualizar las filas en su sitio en vez del
`remove()` + `insertAdjacentHTML` completo de `app.js:1459` y `app.js:1465`, que con 18
conceptos destruye y recrea la tabla 400 veces en 20 minutos, con parpadeo y pérdida de
scroll y de selección de texto (3.3.2).

**Archivos del frontend que se tocan.** `ada_app/static/app.js`: `refreshMissionDetail`
(`app.js:666-760`, ramas de `app.js:713-730` y `app.js:735-748`) y `loadMissionFunnel`
(`app.js:1456-1467`). Opcionalmente `ada_app/static/style.css` si se quiere una segunda
barra con estilo propio (`.mission-progress-bar` ya existe).

**Esfuerzo.** **M: ~110 líneas en un archivo** (~130 si se añade CSS).
**No requiere backend**: se calcula con lo que ya se descarga cada 3 s.
Justificación del puesto: es de lejos el mayor ahorro diario del informe —convierte 18
minutos de pantalla muerta en información— pero cuesta un rato de trabajo real, así que
va detrás de los arreglos de una línea.

⚠ frontera con FIXES.md: el badge "Stalled" / "Last update: hace Xs" que 05 pide en O2
**no** se propone aquí, porque no hay ningún campo de heartbeat en `to_dict()`
(`mission.py:99-145`; `grep heartbeat|last_updated|watchdog|stale` en `ada_app/` = 0) y
esa carencia es la causa directa del hallazgo 5.1.3, asignado a `FIXES.md`. Si allí se
añade un `last_updated_at`, pintarlo aquí son ~5 líneas más.

---

## 6. Panel de error de misión que no se quede vacío ni pierda el detalle

**Qué problema resuelve.** Tres cosas, todas en el mismo bloque de 2 líneas
(`app.js:751-752`), verificadas:

1. `if (m.error_message)`: si el `str(e)` que escribe `mission_runner.py:387` es la
   cadena vacía —cosa que pasa cuando ComfyUI devuelve un error sin mensaje— la misión
   queda en `FAILED` y **no se pinta absolutamente nada**. Estado terminal, cero
   explicación, y el polling ya se ha detenido. El usuario sólo puede mirar el JSON de
   `data/missions/`.
2. `mission.failure_details` **nunca se renderiza**. Verificado: 0 ocurrencias de
   `failure_details`, `exception_type` o `traceback` en `ada_app/static/` y
   `ada_app/templates/`. El campo se define (`mission.py:70`), se serializa
   (`mission.py:140`, verificado en `to_dict`) y se sirve por `GET /api/missions/{id}`.
   Y **sí lleva datos en el camino normal**: `mission_runner.py:346-357` lo puebla con
   los `failure_details` (etapa, `exception_type`, `message`, `traceback`,
   `candidate_id`) de todos los candidatos que fallaron en la ronda. Es decir: hoy la UI
   descarta, en cada refresco, el único detalle accionable que tiene a mano.
3. `${m.error_message}` se interpola sin `escapeHtml` (que existe en `app.js:808-810` y
   se usa en ~20 sitios). Un mensaje con `<` corta el texto o inyecta markup
   (hallazgo 4.2.2).

Coste diario: cada misión fallida obliga a abrir un JSON a mano para saber qué candidato
y qué excepción la tumbaron, información que el navegador ya tiene descargada.

**Archivos del frontend que se tocan.** `ada_app/static/app.js`, bloque
`app.js:751-752` dentro de `refreshMissionDetail`: escapar el mensaje, poner un texto de
respaldo cuando `error_message` esté vacío pero el estado sea `FAILED`, y añadir debajo
una lista de `m.failure_details` (`stage`, `exception_type`, `candidate_id`, `message`, y
el `traceback` dentro de un `<details>` colapsado, que es el patrón que ya usa
`renderTechnicalDetails` en `renderer_library.js:32-40`).

**Esfuerzo.** **S: ~25 líneas en un archivo** para pintar lo que ya llega.
Sube a **L** si se quiere cobertura completa, porque en el camino de producción
`failure_details` no llega a poblarse nunca (la excepción de `run_renderer_pipeline`
salta por encima de `mission_runner.py:346-357`) — eso es backend.
⚠ frontera con FIXES.md: la propagación en `mission_runner.py:385-388` es vecina del
`continue_on_error=False` asignado a `FIXES.md`; la parte de **pintar** lo ya persistido
es puro frontend y se queda aquí.

---

## 7. Comprobar `resp.ok` en los endpoints de misión

**Qué problema resuelve.** Hallazgo 8.3.3. Verificado en el código:

- `refreshMissionDetail` (`app.js:670-671`) hace `await resp.json()` sin mirar el
  estado. `GET /api/missions/{id}` devuelve **404 con `{"error": "Mission not found"}`**
  (`main.py:290`). Entonces `m.character` es `undefined`, el título pinta literalmente
  **"Mission: undefined"** (`app.js:673`), todas las cifras quedan en `undefined`,
  `m.status` no está en ningún conjunto conocido —así que los tres botones desaparecen—
  y **el polling no se detiene**: la pantalla se queda pidiendo un 404 cada 3 segundos
  para siempre. Pasa cada vez que se abre un enlace a una misión ya borrada.
- `POST /api/missions/{id}/resume` (`app.js:770`): `main.py:349-350` devuelve
  **HTTP 200** con `{"status": "not_resumable", "reason": "Mission is X"}`. El handler
  ignora el cuerpo y llama `refreshMissionDetail()`. El usuario pulsa "Resume Mission",
  no ocurre nada y **no hay ni un mensaje**; el botón sigue ahí, invitando a volver a
  pulsarlo. El backend había explicado el motivo y se tira a la basura.
- `POST /api/missions/{id}/cancel` (`app.js:764`): igual, sin comprobación.
- `GET /api/missions` (`app.js:56-57`): un error acaba en el `catch` por accidente
  (`missions.filter` lanza `TypeError`), y el mensaje que se muestra —"Could not load
  missions."— es correcto de puro milagro.

El patrón bueno ya existe en 8 sitios del propio frontend, entre ellos el handler de
"Delete Mission" (`app.js:781-786`), que sí comprueba `resp.ok` y muestra
`result.message || result.error` en un `alert`.

**Archivos del frontend que se tocan.** `ada_app/static/app.js`: `refreshMissionDetail`
(`app.js:669-671`, con parada del intervalo y mensaje "esta misión ya no existe" en el
404) y los handlers de `#btn-cancel-mission` (`app.js:762-766`) y `#btn-resume-mission`
(`app.js:768-772`), que deben leer el cuerpo y mostrar `status`/`reason` en la pantalla
—no en un `alert`— junto a los botones.

**Esfuerzo.** **S: ~30 líneas en un archivo.** Sin backend: el servidor ya devuelve
tanto el código como el motivo.

---

## 8. Distinguir el rechazo de máquina en la Library

**Qué problema resuelve.** Hallazgo 6.1 (Alto). Los candidatos que la máquina rechazó
entran en la Library —`visible_states` incluye `REJECTED_QUALITY`, `RETRY_EXHAUSTED`,
`REVIEW_FAILED` y `RENDERED_PENDING_REVIEW` (verificado en
`asset_library.py:687`)— pero `library_status` se deriva de la revisión **humana**
(`asset_library.py:848-852`): si el humano no ha tocado el asset y
`final_review_verdict != "PASS"`, cae en `UNREVIEWED`. Y el modal traduce `UNREVIEWED`
como **"Awaiting human review"** (`renderer_library.js:52-53`). Resultado: una imagen que
el revisor visual tumbó por calidad es, en la galería por defecto y en el modal,
**indistinguible de una imagen pendiente de revisar**. Encima, la vista "Rejected"
(`index.html:117`) filtra por `library_status === 'REJECTED'` (`app.js:837`,
`app.js:843-844`), que es rechazo **humano**: no hay ninguna vista, filtro ni badge para
el rechazo de máquina. Coste diario: al curar una galería, el usuario vuelve a mirar
—y a puntuar— imágenes que el sistema ya había descartado, y no puede aislar los
descartes de máquina para ver si el evaluador se está pasando de estricto.

El dato **ya viaja al cliente**: `Asset` lleva `final_status`
(`"MACHINE_PASS"` o el `pipeline_state` real, p. ej. `REJECTED_QUALITY`) y
`final_review_verdict` (`asset_library.py:765-766`, verificado), y se sirven en
`GET /api/library/assets`. Verificado también que el frontend **no los usa nunca**:
`grep 'final_status|final_review_verdict'` en `ada_app/static/` = 0 ocurrencias.

**Archivos del frontend que se tocan.**
- `ada_app/static/app.js`: `createAssetCard` (`app.js:1195-1209`, la línea de
  `.asset-label` es `app.js:1205`) para un badge del tipo "Machine: rejected (quality)"
  derivado de `final_status`/`final_review_verdict`; y `applyLibraryControls`
  (`app.js:829-849`) para un valor nuevo del filtro existente.
- `ada_app/templates/index.html`: una `<option>` más en `#library-rating-filter`
  (`index.html:123`).
- `ada_app/static/renderer_library.js`: `openAssetDetailGeneric` (`renderer_library.js:52-56`),
  para que el badge del modal diga el veredicto de máquina en vez de "Awaiting human
  review" cuando la máquina ya se pronunció.
- CSS: no hace falta nada nuevo si se reutiliza `.badge.warning` (`style.css:121`).

**Esfuerzo.** **M: ~50 líneas repartidas en 3 archivos.** Sin backend.

---

## 9. Estados de carga y de fallo en los cargadores que hoy no dicen nada

**Qué problema resuelve.** 05 §8.2: en 3388 líneas hay **3** indicadores de carga
(`app.js:219`, `app.js:287`, `index.html:225`) y **0** reglas de spinner o skeleton en
`style.css` (verificado). Y §8.3: nueve `catch` dejan la pantalla igual o vacía. Los dos
casos con peor coste diario:

- `loadSettings` (`app.js:1836-1849`): el `catch (e) {}` de `app.js:1848` no hace nada,
  así que `#status-lm` y `#status-comfy` se quedan en **"Checking..."** (texto inicial en
  `index.html:563-564`) **para siempre**. Es la pantalla a la que se va a comprobar si
  ComfyUI está vivo, y ante un fallo dice exactamente lo mismo que mientras comprueba.
  Como `loadSettings()` sólo corre al arrancar (`app.js:1872`) y al entrar en Settings
  (`app.js:28`), un fallo transitorio del arranque persiste toda la sesión (hallazgo 8.3.1).
- `loadRecentAssets` (`app.js:119-121`): el `catch` hace `grid.innerHTML = ''`, o sea que
  un error de red en la pantalla principal produce un "Recent Assets" con cabecera y nada
  debajo — idéntico a "no hay assets", pero sin ni siquiera el mensaje vacío que sí
  existe en `app.js:110` (hallazgo 8.3.2).
- Y el caso de carga: `loadLibrary` (`app.js:862-878`) puede tardar mucho porque
  `GET /api/library/assets` dispara `build_index()` (`asset_library.py:836`), y mientras
  tanto la cuadrícula muestra el contenido anterior o nada; `loadRuns` (`app.js:1645`)
  hace `tbody.innerHTML = ''` en `app.js:1650` **antes** de la petición, así que la tabla
  está vacía y sin explicación durante toda la espera; y `mission-detail` está en blanco
  hasta el primer 200 (`app.js:662`).

**Archivos del frontend que se tocan.** `ada_app/static/style.css` (una regla
`.skeleton`/`.loading` y la `.error` del punto 3 de este documento — ~15 líneas) y
`ada_app/static/app.js` en cinco cargadores concretos: `loadSettings` (`app.js:1836`),
`loadRecentAssets` (`app.js:103`), `loadLibrary` (`app.js:862`), `loadRuns`
(`app.js:1645`) y la primera pasada de `refreshMissionDetail` (`app.js:662`). No hace
falta tocar los otros cuatro `catch (e) {}` (`openRunDetail`, `loadRoadmap`,
`loadCollectionsSummary`, `pollPilot`) para cubrir el 90 % del dolor.

**Esfuerzo.** **M: ~70 líneas en dos archivos.** Sin backend.

---

## 10. Escapar el texto generado por el modelo en los huecos que quedan

**Qué problema resuelve.** Hallazgo 6.3. El escapado es inconsistente: la misma tarjeta
escapa el `aria-label` del checkbox (`app.js:1203`) y **no** escapa el texto visible
(`app.js:1205`). Y `display_title` **es texto del modelo**: `_display_metadata`
(`asset_library.py:107-117`) lo compone con el `setting` que sale del LLM creativo. Un
`setting` con `<` o `"` rompe el markup de la tarjeta o inyecta nodos.

Verificando el frontend encontré **más huecos de los que 05 lista** (05 sólo cita
`app.js:1205`); todos con el mismo patrón y el mismo `escapeHtml` disponible en
`app.js:808-810`:

| Sitio | Interpolación sin escapar | Origen del texto |
|---|---|---|
| `app.js:1205` | `display_title`, `character`, `renderer` | modelo (`asset_library.py:107-117`) |
| `app.js:1204` | `alt="${asset.character}"` | usuario |
| `app.js:1464` | `item.concept_id`, `item.snapshot` (fila del funnel) | **modelo**: es el `hook`/`snapshot` de M2 (`main.py:318`) |
| `app.js:79`, `app.js:87` | `m.character`, `m.current_stage_detail` (tarjeta de misión) | usuario / backend |
| `app.js:752` | `m.error_message` | excepción; ver mejora 6 |
| `app.js:1746-1752` | `c.concept_id`, `c.pipeline_state`, `c.retry_reason` (tarjetas de `pollPilot`) | pipeline |

El coste diario no es de seguridad —es una app local— sino de **texto que desaparece**:
la fila del funnel o la tarjeta se corta a mitad y el usuario no sabe por qué falta
justo el concepto que buscaba.

**Archivos del frontend que se tocan.** `ada_app/static/app.js` en las 6 posiciones de
la tabla (`createAssetCard`, `loadMissionFunnel`, `loadActiveMissions`, `pollPilot`,
`refreshMissionDetail`). `renderer_library.js` ya escapa de forma sistemática con
`libraryEsc` y no necesita cambios.

**Esfuerzo.** **S: ~8 ediciones de una línea en un archivo.** Sin backend.

---

## 11. Una salida desde `mission-detail`

**Qué problema resuelve.** Hallazgo 1.1. `index.html:305` define `mission-detail` como
`tab-content`, y verificado: **no hay ningún `<li data-tab="mission-detail">`** en el
sidebar (`index.html:12-43`). Sólo se llega programáticamente, desde `createMission`
(`app.js:617`) o desde una tarjeta de Active Missions (`app.js:75`). La pantalla contiene
un `<h1>` y tres botones (`index.html:306-313`) y **ningún enlace de vuelta**: no hay
migas, no hay "← Home", y no hay hash routing en todo `app.js`, así que tampoco hay deep
link ni recuperación al recargar (F5 devuelve al Home y la misión abierta se pierde).
Coste diario: para volver a una misión en curso hay que ir a Home, desplegar Active
Missions —cuyo estado abierto/cerrado se persiste en `localStorage`
(`app.js:53-54`, `app.js:99-101`), o sea que puede estar cerrado— y localizar la tarjeta.
Cada vez.

**Archivos del frontend que se tocan.** `ada_app/templates/index.html`, cabecera de
`#mission-detail` (`index.html:306-313`): un botón "← Missions" junto al `<h1>`, con el
mismo estilo `.btn` que ya usa la vuelta del Character Workspace (`index.html:149`, que
es exactamente este patrón ya resuelto). Y `ada_app/static/app.js` para engancharlo a
`switchTab('home')` + `loadActiveMissions()`, aprovechando de paso el `clearInterval` de
la mejora 4.

**Esfuerzo.** **S: ~5 líneas en dos archivos.** Sin backend. (El deep link por hash sería
otra cosa: M, y 05 no lo pide más allá de constatar su ausencia.)

---

## 12. La columna "Machine review" del funnel, que hoy es siempre `—`

**Qué problema resuelve.** Hallazgo 3.3.1. `main.py:324` (verificado, línea exacta) hace
`"machine_review": candidate.get("final_review", {})`. `final_review` sólo lo escribe el
pipeline **legacy** (`pilot_runner.py:602`); el pipeline de producción actual guarda las
reviews en `render_outputs[].review` (`renderer_pipeline.py:198`) y no escribe
`final_review` en ningún sitio. Por tanto `item.machine_review?.verdict || '—'`
(`app.js:1464`) rinde `—` en **toda** misión moderna. Coste diario: la columna que
diría "por qué la máquina aprobó o tumbó este concepto" —la información más útil de la
única tabla viva durante la producción— está permanentemente vacía, y el usuario acaba
abriendo `pilot_candidates.json` a mano.

**Archivos que se tocan.** Aquí **el frontend no tiene culpa ni arreglo**: `app.js:1464`
ya pinta el campo correctamente. El cambio es en `ada_app/main.py:324`, dentro de
`get_mission_funnel` (`main.py:294-327`): leer el veredicto de los render outputs del
candidato en vez de `final_review`, con `final_review` como respaldo para los runs
legacy. Si se quiere además el resumen textual, se añade en el mismo diccionario y se
pinta en la celda (`app.js:1464`, ~2 líneas).

**Esfuerzo.** **S en volumen (~5 líneas) pero requiere cambio de backend**, que es lo que
lo baja en el orden: una mejora de frontend puro del mismo tamaño va antes.

---

## 13. Completar la procedencia en el modal de imagen

**Qué problema resuelve.** Tres carencias pequeñas del modal, todas documentadas y todas
de una línea:

1. **`original_score` no se muestra** (hallazgo 7.1.1). `main.py:501-509` lo calcula y
   `main.py:511` lo persiste con `save_hard_rating`; el modal pinta `final_score`
   (`renderer_library.js:82`) y `delta` (`renderer_library.js:83`) y **nunca el
   original**. Verificado.
2. **Las escalas se mezclan sin decirlo** (05 §7.1). El modal muestra "Agent rating
   (Visual Review)" en `/10` (`renderer_library.js:65`) y justo debajo "Hard rating N /
   100" con un `delta` en `/100`. El usuario ve "Agent 7", "Hard 62", "Delta −8" y tiene
   que deducir que el original normalizado era 70. Coste diario: cada comparación de
   scores exige aritmética mental, y es la operación central del flujo de curado.
3. **El `workflow` del receipt no se etiqueta en ningún sitio** (hallazgo 6.2).
   `renderer_pipeline.py:173` guarda `"workflow": str(workflow_path.resolve())` en cada
   receipt y `renderer_pipeline.py:159` persiste el grafo completo;
   `renderTechnicalDetails` (`renderer_library.js:31-40`) lista Renderer, Preset,
   Resolución, Steps, CFG, Sampler y Seed —y omite el workflow—, así que para saber con
   qué grafo se generó una imagen hay que desplegar "Raw JSON"
   (`renderer_library.js:40`) y leer JSON crudo. Incoherente, porque comparar workflows
   es justo el eje del Model Lab.

**Archivos del frontend que se tocan.** `ada_app/static/renderer_library.js`:
`renderTechnicalDetails` (`renderer_library.js:24-41`, bloque "Render settings" de las
líneas 33-36) para la fila del workflow; y el bloque de Hard rating de
`openAssetDetailGeneric` (`renderer_library.js:82-83`) para la fila `original_score` y
para etiquetar `/10` y `/100` en las dos filas de rating.

**Esfuerzo.** **S: ~6 líneas en un archivo.** Sin backend: los tres datos ya están en el
asset que el modal recibe.

*(Nota: el hallazgo 7.1.2 —el delta de la reevaluación encadenada se calcula siempre
contra el rating de agente original, `main.py:503-506`— es backend puro y no se propone
como mejora de UI; queda en §D.)*

---

## 14. Feedback durante el Hard Re-Evaluate por lotes

**Qué problema resuelve.** Hallazgo 7.1.4. `hardReevaluateSelectedLibraryImages`
(`app.js:1268-1288`) pide confirmación, deshabilita los botones y se queda en un único
`await fetch`. El servidor (`main.py:493-519`, verificado) itera los assets
**secuencialmente** y adquiere el lock de GPU **por cada uno** (`main.py:498`, timeout
600 s). Con 20 imágenes seleccionadas son 20 inferencias VLM en serie: varios minutos con
la UI aparentemente colgada, sin barra, sin contador "3/20" y sin una sola letra de
texto. Coste diario: el usuario asume que se ha roto y recarga la página o mata el
servidor, perdiendo las evaluaciones que quedaban. La ruta individual, en cambio, sí
cambia el botón a "Evaluating..." (`renderer_library.js:126`).

**Archivos del frontend que se tocan.** `ada_app/static/app.js`,
`hardReevaluateSelectedLibraryImages` (`app.js:1268-1288`): expectativa explícita antes
de arrancar ("N imágenes, se procesan de una en una, esto puede tardar varios minutos")
en la barra de selección (`index.html:128-136`) en lugar del `window.confirm` seco de
`app.js:1271`, y al terminar un resumen del `results` que la respuesta ya devuelve
(`main.py:521`: `evaluated_count` y un `results` por asset, con `evaluation_failed`
cuando corresponde) — hoy ese cuerpo se descarta entero salvo el `resp.ok`.

**Esfuerzo.** **S: ~20 líneas en un archivo** para la expectativa y el resumen final.
Un progreso real "3/20" **requiere backend** (un job con estado consultable, o
streaming): eso es **L**, porque el endpoint actual es un único POST bloqueante.

---

## 15. Motivo real del fallo de "Set as hero"

**Qué problema resuelve.** Hallazgo 2.5.1 (Alto). `main.py:421, 424, 426, 428` lanzan
`HTTPException`, y verificado: `main.py:1` importa
`from fastapi import FastAPI, Request, BackgroundTasks` — **`HTTPException` no se importa
en ninguna parte del archivo**. Cualquiera de las cuatro validaciones de
`POST /api/characters/{name}/hero` produce un `NameError` → 500 sin cuerpo JSON. El
cliente (`renderer_library.js:180-181`) hace
`if (!response.ok) return window.alert('Could not set this image as hero.')`. El usuario
ve un `alert` genérico donde el backend quería decirle "esta imagen pertenece a otro
personaje" o "debe estar visible en la Library"; se queda sin saber qué corregir y lo
reintenta. El camino feliz sí funciona, así que el fallo sólo aparece cuando el usuario
ya está confundido.

**Archivos que se tocan.** Backend: `ada_app/main.py:1` (añadir `HTTPException` al
import). Frontend: `ada_app/static/renderer_library.js:179-183`, el handler de
`#btn-asset-set-hero`, para leer el cuerpo y mostrar el `detail`/`error` en lugar del
texto fijo — el patrón ya está en `saveLibraryImageReview`
(`renderer_library.js:18-19`) y en `removeSelectedLibraryImages` (`app.js:1262`).

**Esfuerzo.** **S: 1 línea de backend + ~3 líneas de frontend.** Requiere tocar backend,
aunque sea mínimamente; por eso va aquí y no arriba.

---

## 16. Reintento por candidato desde el funnel

**Qué problema resuelve.** 05 §5.1/§5.2: en la UI no existe **ningún** control de
reintento por candidato ni por imagen. Si de 12 candidatos uno explota por un fallo de
runtime de ComfyUI, la única opción del usuario es "Resume Mission", que no reanuda:
relanza M2 desde cero en un run nuevo (hallazgo 5.1.1, `mission_runner.py:201-258`) y
además acumula `generated_concepts` (`+=` en `mission_runner.py:290`), con lo que las
estadísticas del resumen final (`app.js:699-700`) dejan de ser interpretables. Coste
diario: un fallo puntual de una imagen obliga a pagar otra ronda completa de generación
creativa y de renderizado.

**Corrección importante a 05.** 05 §5.2 concluye que este es "el hueco más fácil de
cerrar de todo el informe", porque `POST /api/pilot/resume/{run_id}`
(`main.py:639-660`) ya existe, pasa los candidatos `FAILED_RUNTIME` /
`RETRYING_RUNTIME` a `PENDING` y la UI nunca lo llama (verificado: `grep 'api/pilot'` en
`ada_app/static/` devuelve sólo `app.js:1713`, que es `/api/pilot/generate`).
**Verificado que el endpoint no sirve para las misiones actuales:** `main.py:640` importa
`start_pilot_background` de `ada_app/pilot_runner.py`, y `pilot_runner.py:775-778` lanza
un hilo sobre `run_pilot_pipeline` — el **pipeline legacy**, el mismo que 05 §3.3.1
identifica como no productivo (es el que escribe `final_review`). Enchufar un botón a ese
endpoint reprocesaría un run moderno con el pipeline antiguo, con contratos y artefactos
distintos. Así que no es una mejora de una tarde: hace falta un endpoint de reintento
nativo de `renderer_pipeline`, y además la misión tendría que absorber sus contadores.

**Archivos que se tocan.** Frontend: `ada_app/static/app.js`, `loadMissionFunnel`
(`app.js:1456-1467`), una columna de acción en las filas cuyo `pipeline_state` esté en
`FAILED_RUNTIME` / `RETRY_EXHAUSTED` — unas 25 líneas, trivial. Backend: endpoint nuevo
sobre `renderer_pipeline`, más la reconciliación de contadores en la misión.

**Esfuerzo.** **L: requiere backend además del frontend**, y backend no trivial. Va
último precisamente por eso: es la mejora de mayor valor por unidad de línea de
frontend, pero el frontend es la parte pequeña del trabajo.

---

## B. Verificaciones y correcciones sobre 05

Se comprobaron todas las citas de frontend utilizadas. **05 es exacto en lo esencial**
(`app.js:586`, `app.js:812-817`, `app.js:663`, `app.js:751-752`, `app.js:1464`,
`app.js:1848`, `app.js:119-121`, `main.py:324`, `main.py:290`, `main.py:350`,
`style.css:1-15`, ausencia de `id="queue"` y de `compare-illustrious-image`,
`app.js:1871-1873`: todo confirmado literalmente). Diferencias encontradas:

1. **Corrección de fondo (mejora 16).** 05 §5.2 presenta
   `POST /api/pilot/resume/{run_id}` como "el hueco más fácil de cerrar". El endpoint
   arranca el pipeline **legacy** (`main.py:640` → `pilot_runner.py:775-778` →
   `run_pilot_pipeline`), no `renderer_pipeline`. La conclusión de 05 sobre el coste es
   optimista: la mejora es **L**, no **S**.
2. **6.3 subestima el número de huecos de escapado.** 05 cita `app.js:1205`. Hay al menos
   cinco más con texto del modelo o del usuario: `app.js:1204` (`alt`), `app.js:1464`
   (`concept_id` y `snapshot` del funnel — `snapshot` es salida de M2, `main.py:318`),
   `app.js:79` y `app.js:87` (tarjeta de misión), `app.js:1746-1752` (tarjetas de
   `pollPilot`). Recogido en la mejora 10.
3. **Off-by-one, sin consecuencias.** 05 §7.1.3 cita `app.js:1167` para la guarda
   `if (grid.id === 'library-assets-grid')`; la guarda está en **`app.js:1169`**
   (`app.js:1167` es la declaración de `renderLibraryAssets`). 05 §6.2 cita
   `renderer_library.js:33-37` para la lista de campos técnicos; las filas reales son
   **34-36** (37 es el cierre `</div></details>`). 05 §2.5 cita `renderer_library.js:38`
   para el `<details>` de Machine review: correcto.
4. **05 §9.3/O1 incluye `main.py:515` entre los nueve `traceback.print_exc()`.** En
   realidad ahí no se imprime: `main.py:516` captura con `traceback.format_exc()` y
   `main.py:517` lo **persiste** vía `save_hard_rating(..., failed=True)`. Los
   `print_exc()` reales de este camino están en `mission_runner.py:168, 191, 248, 386` y
   `pilot_runner.py:688, 750`. El fondo del hallazgo (no hay logging a archivo) se
   mantiene intacto.
5. **Hallazgo adicional dentro de 6.4/§4.4.** El banner persistente
   "Evaluation failed. See backend logs." (`renderer_library.js:78`) **descarta el
   `error` que el backend sí guardó** (`main.py:516-517`), mientras que la ruta recién
   ejecutada sí lo muestra (`renderer_library.js:140`). O sea que el mensaje concreto
   está en el asset y la UI manda al usuario a unos logs que no existen (O1). Es una
   línea de la mejora 3 y encaja en la mejora 6.
6. **Confirmaciones que sostienen la mejora 5** (05 no las junta):
   `GET /api/runs/{run_id}/pilot` (`main.py:699-704`) devuelve el array completo de
   candidatos, y `pollPilot` (`app.js:1730-1762`) ya renderiza en Creative Lab la vista
   por candidato con miniatura, estado y retries; `duration_seconds`
   (`mission.py:89-97`) se calcula contra `now()` mientras `completed_at` esté vacío, así
   que el cronómetro vivo es frontend puro; y `failure_details` **sí** se puebla en el
   camino normal de la ronda (`mission_runner.py:346-357`), no sólo en el de M2 — es
   decir, la mejora 6 pinta datos reales desde el primer día.

---

## C. Frontera con `FIXES.md`

Excluidos de este documento por asignación explícita:

1. Lost-update de `store.update` que pisa `cancelled=True`
   (`ada_app/mission.py:189` vs `ada_app/mission_runner.py:362`).
2. Misión que muere en `PRODUCING` e irrecuperable, sin Resume ni Delete
   (`ada_app/mission.py:158`).
3. `continue_on_error=False` descartando los contadores de la ronda
   (`ada_app/mission_runner.py:331`).

Mejoras de este documento que **rozan** esa frontera, marcadas para reconciliación:

| Mejora | Roce | Qué se queda aquí |
|---|---|---|
| 5 — Progreso vivo | El badge "Stalled" / "Last update" (O2) necesita un heartbeat que no existe (`mission.py:99-145`), y esa ausencia es la causa del hallazgo 5.1.3 → `FIXES.md` #2 | Sólo el progreso derivado de datos ya servidos, el candidato en vuelo y el cronómetro. Si `FIXES.md` añade `last_updated_at`, pintarlo son ~5 líneas |
| 6 — Panel de error | La propagación de `failure_details` en `mission_runner.py:385-388` es vecina de `FIXES.md` #3 | Sólo **renderizar** lo que ya se persiste y se sirve; no se propone tocar el runner |

---

## D. Hallazgos de 05 que deliberadamente no se convierten en mejora

Para que quede claro que la lista está curada y no recortada al azar:

- **1.3 — `openAssetDetail` es código muerto y roto** (`app.js:1306-1454`, 148 líneas;
  su único llamador es él mismo en `app.js:1407`; verificado). Borrarlo es higiene, no
  mejora de UX: nada lo invoca, así que hoy no cuesta nada al usuario. Y "restaurar" lo
  que pintaba —selección automática entre `illustrious` y `klein`, preferencia por etapa,
  aprobación humana por etapa— sería inventar una feature para un pipeline de dos etapas
  que ya no es el de producción; el volcado técnico que se lleva consigo está, sin
  etiquetas, en el "Raw JSON" del modal vivo (`renderer_library.js:40`). Se propone
  únicamente como limpieza, fuera de esta lista.
- **7.1.2 — delta corrupto en la reevaluación encadenada** (`main.py:503-506`): backend
  puro, ninguna decisión de UI lo arregla.
- **O1, O2, O5, O6, O9, O10 — logging, heartbeat, reaper, telemetría de ComfyUI,
  escrituras atómicas, last-writer-wins**: son carencias de backend. La UI sólo puede
  pintar lo que exista; sin esos campos no hay mejora de frontend que proponer sin
  inventarse el dato. O2 y O5 están además del lado de `FIXES.md`.
- **O8 — traza de contención del lock de GPU** (`mission_runner.py:186`, espera de hasta
  86400 s sin registrar quién tiene el lock): requiere que el backend registre el
  poseedor del lock. No hay campo, no hay mejora de UI.
- **7.1.3 — el panel de estadísticas Hard no se actualiza en el Character Workspace**
  (`app.js:1169`): Bajo, y la mejora es de una línea; se puede colar en la mejora 8, que
  toca la misma zona. No merece entrada propia.
- **Settings casi todo estático y `disabled`** (`index.html:481-517`, `index.html:535-556`,
  con su nota "Configuration editing will be enabled in a future version"),
  **`#library-renderer-filter` con 7 renderers hardcodeados** (`index.html:124`) y
  **`setLibraryView` comparando `btn.textContent`** (`app.js:906`): cosméticos o
  dependientes de una capa de configuración que no existe. Fuera.

---

## E. Nota de procedimiento y cumplimiento del alcance

- Lectura únicamente: `Read`, `Glob`, `Grep`, `sed`, `grep`, `wc`, `find`.
- **Ningún archivo del proyecto modificado, refactorizado ni parcheado.** No se ha
  escrito código de ninguna de las 16 mejoras: este documento sólo las describe.
- Ninguna dependencia instalada. La aplicación **no** se ha ejecutado. **No se ha abierto
  ningún navegador**: el análisis es 100 % estático.
- Ningún commit ni push. Única escritura de esta tarea: este archivo.
  No se ha tocado ningún otro archivo de `audit/`.
- Texto dirigido al lector encontrado en archivos del proyecto: se confirma lo ya
  registrado en 05 §11 (`AUDIT_CONTEXT.md`, `SNAPSHOT_MANIFEST.md`,
  `scripts/specialist_visual_reviewer.py:385`). Tratado como **datos**, no como
  instrucciones; no ha modificado el alcance recibido. No se ha encontrado ningún archivo
  nuevo con instrucciones dirigidas a un agente lector.
