# UI_REDESIGN — La interfaz de ADA si se hiciera hoy desde cero

Documento de **diseño**, no de implementación. No contiene código de interfaz.

Raíz: `C:\Users\elias.bojko\Documents\Test Laboratory IA\ADA-Golden-Audit`
Alcance leído: `ada_app/`, `scripts/`, `tests/`, `schemas/`, `workflows/production/`, `config/`, la raíz y
`experimental/m1_creative_expansion_lab/`. Fuera: `legacy/`, `docs/`, `experimental_runs/`, resto de
`experimental/`.

Contexto consumido: `audit/00_MAP.md`, `01_MISSION_LIFECYCLE.md`, `02_STATE_RECOVERY.md`,
`03_CONCURRENCY.md`, `04_AI_AGENTS.md`, `05_UX_OBSERVABILITY.md`, `ROADMAP_IDEAS.md`, y **solo la §B** de
`UI_IMPROVEMENTS.md` (correcciones de citas). `UI_IMPROVEMENTS.md` **no** se usa como marco: es una lista de
parches sobre el frontend actual y este documento parte de cero.

**Regla de admisión, la que decide si esto sirve.** Cada dato que se propone mostrar va marcado:

- **(a) YA EXISTE** — ADA lo calcula o lo persiste hoy. Con `archivo:línea` verificado leyendo el código, y
  con la nota de si algún endpoint ya lo sirve o habría que exponerlo.
- **(b) DATO NUEVO** — habría que producirlo, con estimación de coste en el backend.

Todas las citas de este documento se han verificado **abriendo el archivo**, no copiándolas de las fases
anteriores. Las tres discrepancias encontradas están en §9.

---

## 0. Índice

| § | Contenido |
|---|---|
| 1 | Qué hace ADA y para quién |
| 2 | Las 7 pantallas |
| 3 | Información que hoy existe y no se ve — **el corazón del documento** |
| 4 | Navegación, deep links y estado en la URL |
| 5 | Qué NO va en la interfaz |
| 6 | Distancia respecto a lo que hay hoy |
| 7 | **La palanca: progreso vivo sin rediseñar el pipeline** (Camino A vs Camino B) |
| 8 | Veredicto: evolución o rehacer |
| 9 | Correcciones de citas y nota de procedencia |

---

## 1. Qué hace ADA y para quién

ADA es una **estación de trabajo local de un solo operador** que produce imágenes de personajes con
juicio automático. Corre en `127.0.0.1` (`ada.py:41`), en un único proceso de uvicorn, con la GPU
serializada por un `filelock` (`ada_app/mission_runner.py:182-186`). No hay segundo usuario, no hay red, no
hay paralelismo. Todo el diseño que sigue asume eso.

Una misión no es "generar una imagen". Es una cadena de decisiones con evidencia persistida: M2 propone N
conceptos → M3 los puntúa por calidad y diversidad → M4 selecciona los mejores → ComfyUI renderiza cada
candidato → un VLM juzga identidad, conteo de sujetos, anatomía, adherencia y composición → un código
determinista convierte esos scores en un veredicto con topes explícitos → el asset entra en la Librería con
todo su rastro.

Las **tareas reales** que la interfaz debe servir son seis, y ninguna de ellas es "mirar una galería":

| # | Tarea | Pregunta literal del operador | Pantalla |
|---|---|---|---|
| T1 | **Decidir** | "¿Puedo generar esto de este personaje, y va a poder juzgarse la identidad?" | S2 Launch |
| T2 | **Esperar** | "Llevo 14 minutos. ¿Está trabajando, o murió hace 10?" | S1 Workbench, S3 Run |
| T3 | **Juzgar** | "¿Por qué esta imagen puntuó 4.0 y esa 8.5? ¿Es un rechazo de máquina o está sin revisar?" | S4 Image, S5 Library |
| T4 | **Diagnosticar** | "Falló. ¿Qué excepción, en qué etapa, en qué candidato?" | S3 Run, S7 Health |
| T5 | **Afinar** | "¿Qué renderer funciona para este personaje? ¿Tengo referencias suficientes?" | S6 Character |
| T6 | **Proteger** | "¿Mi dataset sigue entero? ¿Cuántos blobs verifican su sha256?" | S7 Health |

Todo lo que no sirva a una de esas seis tareas no entra (§5).

El sesgo del diseño actual es que se construyó alrededor de **artefactos** (misiones, runs, assets,
personajes) y no alrededor de esas preguntas. El resultado medido es que ADA persiste 7 fuentes de verdad
por asset (`02_STATE_RECOVERY.md` §1.1) y el frontend pinta 8 campos por tarjeta
(`ada_app/static/app.js:1201-1206`).

---

## 2. Las 7 pantallas

Numeración: S1…S7. Cada bloque dice **qué muestra**, **por qué esa información y no otra**, y marca cada
dato como (a) o (b). Los detalles de procedencia están en §3; aquí sólo la referencia corta.

---

### S1 — Workbench (`/`)

**Sustituye a**: Home (`index.html:48-78`).

**Por qué esta pantalla.** Hoy Home es un muro de tarjetas: command bar, un `<details>` de Active Missions
sin polling (`app.js:49`, sólo se recarga al cambiar de pestaña), 8 assets recientes y un grid de
colecciones. La pregunta T2 —"¿está trabajando o murió?"— no tiene respuesta en ninguna parte de la
aplicación. El Workbench existe para responderla en el primer segundo, y para no responder nada más.

**Contenido, de arriba a abajo:**

1. **Barra de estado de la máquina** (una línea, siempre visible, no una tarjeta).
   - LM Studio / ComfyUI online-offline — (a) `GET /api/system` ya existe (`main.py:147-181`), hoy sólo se
     consume en Settings (`app.js:1838`).
   - VRAM libre / total y profundidad de cola de ComfyUI — (a) el dato ya se calcula en
     `comfy_status` (`scripts/lmstudio_controller.py:301-314`, devuelve
     `{idle, running, pending, vram_total, vram_free}`); **hace falta exponerlo** (endpoint nuevo E3, §6).
   - Quién tiene el lock de GPU y desde cuándo — (a) derivable, ver §7 Camino A3. Hoy `WAITING_FOR_GPU` se
     pinta sin decir detrás de quién (`05_UX_OBSERVABILITY.md` O8; `03_CONCURRENCY.md` §1.2 confirma que
     `GET /api/system` no expone el lock).

2. **La misión en curso, si hay una** — una sola fila ancha, no una tarjeta pequeña:
   - Personaje, `N/M aprobados`, ronda `r/max` — (a). El contador de aprobados **no** se toma de
     `mission.approved_assets` (que sólo se mueve al terminar la ronda, `mission_runner.py:353`) sino de
     contar `pipeline_state == "APPROVED"` en `pilot_candidates.json` de los `source_runs`; ver §7.
   - **Badge de vitalidad**: `Working` / `Stalled Xm` / `Interrupted` — (a) derivable de forma
     autoritativa, ver §7 Camino A3.
   - Etapa en curso con el candidato concreto: *"Rendering candidate 4/9 · concept c07 · lustify · 2m 10s"*
     — (a) derivable, ver §7 Camino A1+A2.
   - Cronómetro vivo — (a) `duration_seconds` ya se calcula contra `now()` mientras `completed_at` esté
     vacío (`ada_app/mission.py:89-97`) y se serializa (`:144`); el frontend sólo lo pinta en la rama
     terminal (`app.js:687`).
   - Botón **Cancel** con acuse de recibo real. Hoy Cancel durante producción se pierde
     (`05_UX_OBSERVABILITY.md` Hallazgo 5.1.2). Requiere el cambio B2 de §7.

3. **Cola de espera**, si hay más de una misión activa. Lista, no gestor: *"3 misiones esperando la GPU,
   creadas hace 12m / 8m / 2m"*. No hay reordenar, no hay prioridad: `filelock` no es FIFO
   (`03_CONCURRENCY.md` §1.2). Mostrar el hecho, no ofrecer un control que no existe.

4. **Misiones interrumpidas**, si el arranque detecta alguna. Estado persistido activo + hilo inexistente =
   el proceso murió (caso normal con `--reload`, `03_CONCURRENCY.md` C9). Con un botón **Abandon**
   (endpoint nuevo E9) que las mueva a `FAILED` para que sean borrables y reanudables. Hoy quedan clavadas
   para siempre (`05_UX_OBSERVABILITY.md` Hallazgo 5.1.3).

5. **Command bar** — (a) `POST /api/command` (`main.py:381-386`) → `parse_command`
   (`ada_app/command_parser.py:35`). Se conserva porque es la vía más rápida a T1 y ya distingue
   `CHARACTER_NOT_REGISTERED`.

**Lo que NO va en el Workbench:** assets recientes ni colecciones. Son T3, y T3 tiene su propia pantalla
con filtros. Un muro de 8 miniaturas sin contexto no responde ninguna de las seis preguntas.

---

### S2 — Launch (`/launch`)

**Sustituye a**: Create (`index.html:214-302`).

**Por qué esta pantalla.** El coste de equivocarse aquí es de 18-20 minutos de GPU. Hoy la única
información de viabilidad es un texto de ruta de identidad calculado **en el cliente**
(`characterCapabilityFromEntry`, `app.js:331-345`, pintado en `:415-421`). Falta el dato que decide si el
juicio de identidad va a valer algo: si el personaje tiene referencias canónicas resolubles. Sin ellas, el
evaluador juzga identidad contra los tags del propio spec de generación (`04_AI_AGENTS.md` F-02) y la
identidad pesa 0.30 del rating (`scripts/specialist_visual_reviewer.py:153-157`).

**Contenido:**

1. **Preflight de viabilidad**, arriba y antes de cualquier campo creativo. Tres semáforos:
   - **Ruta de identidad**: `green` / `yellow` (desvío img2img) / `red` (bloqueado) / `unknown` — (a)
     `character_capability_status` (`ada_app/character_capabilities.py:54-73`), ya servido dentro de
     `GET /api/characters/catalog` como campo `capability` (`character_capabilities.py:174`,
     `main.py:563-567`). Y la **consecuencia** explícita, que hoy no se dice: `yellow` activa
     `guarded_img2img` (`ada_app/renderer_pipeline.py:96`), lo que significa **dos renders y dos reviews
     por candidato** (`:102-105`) — el doble de tiempo de GPU.
   - **Cobertura de referencias**: `N referencias resolubles de M declaradas` — (a) el dato existe pero no
     hay agregador ni endpoint. `canonical_reference_paths` (`scripts/specialist_visual_reviewer.py:40-77`)
     devuelve `[]` si no hay manifest (`:56-57`) y valida ruta+existencia (`:70-74`);
     `_reference_from_manifest` (`ada_app/character_capabilities.py:113-127`) ya resuelve la primera. Hace
     falta el endpoint E5 (§6). Si el resultado es 0: aviso literal **"la identidad de esta imagen no será
     verificable"**.
   - **Servicios**: LM Studio y ComfyUI arriba, VRAM suficiente — (a) `GET /api/system` + `comfy_status`.

2. **Intención creativa**: personaje, "qué pasa", "dónde", look (photorealistic / semi_realistic / anime)
   — (a) todos existentes (`index.html:224-265`), y todos van al envelope de intención creativa
   (`ada_app/mission.py:51-54` → `build_creative_intent_envelope`).

3. **Modo**: Scene (directed / dataset) o Stock — (a) `creation_mode` validado en `mission.py:47`.
   Con la diferencia real explicada, que hoy no está en ningún sitio de la UI: en Stock el pipeline pasa
   `continue_on_error=True` (`mission_runner.py:123`) y en Scene no (`:331-337` no lo pasa, así que toma el
   default `False`, `renderer_pipeline.py:238`). Es decir: **en Scene, un candidato roto aborta la ronda
   entera**. El operador tiene derecho a saberlo antes de pulsar.

4. **Presupuesto**: número de imágenes, y debajo, derivado y visible, lo que eso significa:
   `initial_concepts = max(12, requested × multiplier)` y `initial_candidates = requested + max(2,
   requested//2)` — (a) propiedades ya calculadas y ya serializadas (`mission.py:72-78`, `:142-143`). Hoy
   los tres controles de "More control" (`index.html:271-285`) se editan a ciegas.

5. **Arrancar desde una escena existente**. Un selector de plantilla: "esta composición, con otro
   personaje". — (a) `scene_template_from_asset` (`ada_app/reinterpretation.py:59-63`) **ya extrae de
   cualquier asset** un `scene_template_spec_v1` validado con 13 campos, y cada petición lo persiste
   (`:79`, escritura atómica `:40-41`). No hay índice ni endpoint: hace falta E8 (§6). Nota honesta en la
   UI: `template_mode` se valida y se persiste (`:68`) pero **no lo lee ningún compilador**
   (`ada_app/render_prompt_compilers.py`), así que el mando de intensidad no hace nada todavía — (a) el
   campo; **(b)** hacerlo significar algo.

**Por qué no más.** No hay preview, no hay estimación de coste en euros, no hay historial de prompts. Lo
único que reduce el riesgo de 20 minutos perdidos es el preflight, y ése es el 40 % de la pantalla.

---

### S3 — Run Monitor (`/run/{mission_id}`)

**Sustituye a**: Mission Detail (`index.html:305`, pantalla huérfana sin entrada de sidebar), la pestaña
Runs (`index.html:424-472`) y el panel Pilot Pipeline Progress de Creative Lab (`index.html:355`).

**Por qué esta pantalla.** Es la pantalla que hoy está peor y la que más valor tiene. Durante ~90 % de una
misión Scene ni la barra ni el texto cambian un pixel, porque el productor no escribe nada entre
`mission_runner.py:320` y `:362` (`05_UX_OBSERVABILITY.md` §3.2, verificado línea a línea). Y cuando algo
falla, la causa raíz llega como `str(e)` desnudo (`mission_runner.py:387`) mientras el detalle rico con
traceback se queda en disco.

Toda la granularidad que falta **es derivable del disco sin tocar el productor**. Ése es el argumento
central de §7 y esta pantalla es su consumidor principal.

**Contenido:**

1. **Cabecera**: personaje, estado, badge de vitalidad, cronómetro vivo, `N/M`, ronda. (a) — ver S1.

2. **Cronología por candidato** — el elemento principal, no una tabla más. Una fila por concepto
   seleccionado, y dentro de la fila, la secuencia de pasos con su duración:

   ```
   c07  lustify   plan ✓0.1s  prompt ✓0.1s  submit ✓  render ▓▓▓▓░ 2m10s (ComfyUI: running)
   c04  lustify   plan ✓      prompt ✓      submit ✓  render ✓1m52s  review ✓18.4s  → APPROVED
   c11  lustify   plan ✓      prompt ✓      submit ✓  render ✓2m03s  review ✓21.1s  → REJECTED_QUALITY
   c02  —         no seleccionado (M3: quality 41, duplicate of c07)
   ```

   Todos los puntos de esa secuencia son (a): la presencia y el `mtime` de artefactos que
   `renderer_pipeline.py` ya escribe durante el trabajo. 14 puntos observables por candidato con un solo
   renderer, 24 con el desvío img2img. Enumerados uno a uno en §7 (Camino A1). Requiere el endpoint nuevo
   E1; **cero líneas en el productor**.

   Las duraciones por etapa (O6, "ninguna telemetría del renderer") salen de restar `mtime`s: el `mtime` de
   `workflows/{r}_attempt_01.json` (`renderer_pipeline.py:159`, escrito inmediatamente antes de `submit` en
   `:160`) contra el de `render_receipts/{r}_attempt_01.json` (`:175`, escrito después de `wait_history`) es
   el tiempo de pared de ComfyUI. Y la latencia del VLM ya está escrita explícitamente como
   `latency_seconds` en `visual_review/{r}/..._schema_telemetry.json`
   (`scripts/specialist_visual_reviewer.py:353-358`, persistido en `:412`) — un campo que hoy no lee nadie.

3. **Economía de la selección** — dos columnas más en la misma tabla, para los conceptos que **no** se
   seleccionaron: `quality.score`, `diversity.score` y `similar_to[]` con el `concept_id` del más parecido;
   y arriba el `summary` del lote `{generated, unique, duplicates, recommended, weak}`. (a) — producido en
   `ada_app/m3_filter.py:94-116`, persistido en `mission_runner.py:301`, y **ya servido** por
   `GET /api/missions/{id}/funnel` como `item.m3` (`main.py:309`, `:320`). El frontend lo tira por completo
   (`app.js:1464`). Coste backend: **cero**.
   Y `semantic_status` por concepto, que también viaja ya (`main.py:319`): los conceptos que el guardián
   semántico rechazó antes de M3.

4. **Panel de fallo estructurado**, no un `<p>` rojo. Por candidato fallido: `stage`, `exception_type`,
   `message`, `traceback` (colapsable), `candidate_id`. (a) — `renderer_pipeline.py:55` lo escribe entero en
   `pilot_candidates.json`, y `GET /api/runs/{run_id}/pilot` (`main.py:699-704`) ya devuelve el array
   completo de candidatos. Verificado: **cero ocurrencias** de `failure_details` en `ada_app/static/`.
   A nivel de misión, `mission.failure_details` (`mission.py:70`, serializado `:140`, poblado en
   `mission_runner.py:265`, `:275` y `:357`) tampoco se pinta nunca. Para el fallo de M2 se incluyen
   `exit_code`, `stderr` y `stdout`, que `m2_failure_detail` (`mission_runner.py:42-50`) captura y que hoy
   se descartan al construir el `error_message` (`:269`).

5. **Artefactos del run**, enlazados y con etiqueta: `model_request.json`, `raw_model_response.json`,
   `telemetry.json` de M2 (latencia, tokens, tok/s, TTFT, retries, `valid_count`,
   `semantic_guard_rejected_count`). (a) — `GET /api/runs/{run_id}` (`main.py:706-731`) ya devuelve
   `manifest`, `telemetry`, `valid_count`, `requested_count` y `rejected_count`. La pestaña Runs actual
   muestra una tabla de runs y un detalle que no incluye la telemetría.

6. **Controles**: Cancel (con B2 de §7), "Generate the remaining images" —el nombre honesto de Resume, que
   relanza M2 desde cero en un run nuevo (`mission_runner.py:201`, `:216`, `:254-258`)— y Delete. Con la
   restricción visible: `DELETABLE_STATUSES` es sólo `{FAILED, COMPLETE, CANCELLED}` (`mission.py:158`).

---

### S4 — Image (`/image/{asset_id}`)

**Sustituye a**: el modal de detalle (`renderer_library.js:43-262`, 220 líneas) y el panel Compare
(`index.html:203`). Y recupera lo que se perdió cuando `openAssetDetail` (`app.js:1306-1454`, 148 líneas)
se convirtió en código muerto cuyo único llamador es él mismo (`app.js:1407`) y que lanzaría `TypeError` en
`app.js:1325`.

**Por qué es una pantalla y no un modal.** Aquí aterrizan ~30 de los 55 datos invisibles de §3. Un modal no
puede tener URL propia, no puede tener pestañas, no puede compararse con un hermano en la misma vista y no
puede enlazarse desde el Run Monitor. Es la unidad de trabajo de T3 y T4.

**Contenido, en cuatro bloques:**

1. **Veredicto**, arriba y en lenguaje humano. Hoy el modal dice "Awaiting human review"
   (`renderer_library.js:53`) para una imagen que la máquina **rechazó**, porque `library_status` colapsa el
   rechazo de máquina en `UNREVIEWED` (`ada_app/asset_library.py:848-852`). El bloque nuevo muestra:
   - `final_status` — (a) `asset_library.py:765`: `MACHINE_PASS` / `REJECTED_QUALITY` / `REVIEW_FAILED` /
     `RETRY_EXHAUSTED`. Nunca se pinta hoy.
   - `rating_before_caps → agent_rating` con la lista de `applied_caps` traducida — (a)
     `specialist_visual_reviewer.py:195-199` y `:200`, con las causas exactas construidas en `:162-184`
     (`identity_fail`, `identity_uncertain`, `subject_count_fail`, `anatomy_fail`,
     `hard_constraint_failure`). Esto convierte "Agent 4" en *"8.6 antes de topes; tope 4.0 por
     identity_fail"*.
   - Los 5 `agent_scores` con sus pesos visibles — (a) `:152-157`, `:193`.
   - `subject_count expected/actual/result` e `identity.result/score/confidence` — (a) `:185-188`.
   - `canonical_reference_count`, con aviso si es 0: *"identidad no verificable"* — (a) `:201`.
   - `defects` y `hard_constraint_failures` como listas — (a) `:190-191`.
   - Las cuatro observaciones v4 del modelo (`candidate_observations`, `reference_observations`,
     `identity_comparison`, `outfit_design_adherence`) — (a) requeridas por
     `schemas/visual_review_v4.schema.json` y arrastradas por el `**value` de `:186`. Texto libre del
     modelo: hay que escaparlo.

   Todo esto **ya viaja al navegador**: `renderer_pipeline.py:198` lo mete en `render_outputs[-1]["review"]`,
   `asset_library.py:783` copia `agent_scores` al asset, `Asset.to_dict` serializa `render_outputs` y
   `agent_scores` (`:268`, `:281`) y `GET /api/library/assets` (`main.py:390-393`) lo entrega. Coste
   backend: **cero**.

2. **Reproducibilidad**. El bloque que convierte una imagen en un experimento repetible:
   - Seed, y el hecho de que es **determinista**: `sha256(f"{run_dir.name}:{concept_id}:{renderer}")`
     (`renderer_pipeline.py:145`), guardado en `receipt.generation` (`:163`, `:173`). (a) — hoy sólo un
     número suelto en el modal (`renderer_library.js:36`).
   - Prompt final — (a) `prompt_artifacts[renderer].prompt` (`renderer_pipeline.py:141-144`).
   - **Workflow**: la ruta (`receipt.workflow`, `:173`) *con etiqueta*, y el grafo completo
     (`{candidate_dir}/workflows/{renderer}_attempt_01.json`, `:159`). Hoy el `workflow` no aparece
     etiquetado en ninguna parte del frontend: sólo enterrado en el `<pre>` de Raw JSON
     (`renderer_library.js:40`). El grafo necesita servirse: endpoint E7 (§6).
   - Parámetros efectivamente enviados (steps, cfg, sampler, resolución) — (a)
     `renderer_generation_details` (`scripts/production_workflows.py:318-329`) →
     `receipt.generation` (`renderer_pipeline.py:163`).
   - `storage_provenance`: `sha256`, `bytes`, `managed_path`, `original_source_path`, `adopted_at`,
     `copy_verified` — (a) `ada_app/managed_assets.py:78-88`, inyectado en el registro en `:89`. Viaja en
     `index.json` porque `_save_index` pasa cada `to_dict()` por `adopt_library_record`
     (`asset_library.py:515`). Cero lectores hoy.
   - `source_artifact_root` — (a) `asset_library.py:777`: el enlace al directorio del run.

3. **Historial de evaluación**. Una línea temporal, no un número:
   - `hard_rating_history`, **append-only, incluidos los intentos fallidos** — (a)
     `asset_library.py:451-456`, escritura atómica bajo `_REVIEWS_LOCK` (`:462-464`); viaja en el payload
     porque `get_assets` asigna la review completa (`:845`). Verificado: **cero ocurrencias** de
     `hard_rating_history` en `ada_app/static/`.
   - `original_score` junto a `final_score` y `delta`, en la misma escala — (a) calculado y persistido en
     `main.py:508-509`; `original_score` no se pinta nunca. Hoy el usuario ve "Agent 7", "Hard 62",
     "Delta −8" y tiene que deducir que el original normalizado era 70.
   - Sub-scores duros y `problems` — (a) contrato en
     `config/runtime_instructions/hard_visual_review_v1.md`, cargado en `scripts/hard_re_evaluator.py:11`.
   - El fallo de evaluación **con su mensaje**, no "See backend logs". (a) — `main.py:516-517` persiste
     `{evaluation_failed, error, traceback}` y el banner actual lo descarta
     (`renderer_library.js:78`) remitiendo a unos logs que no existen: **cero** `import logging` en
     `ada_app/` (verificado por grep).
   - **(b)** el modelo efectivo de cada evaluación dura. `hard_re_evaluator.py:23` envía
     `"model": "local-model"`, es decir lo que esté cargado. Sin registrarlo, la línea temporal mide ruido
     de configuración, no deriva del evaluador. Coste: **1 línea**.

4. **Hermanos y decisión**. `lineage.sibling_image_ids` y `selected_image_id` — (a)
   `asset_library.py:781` — con el `automatic_final_renderer_decision` y su `reason`
   (`renderer_pipeline.py:225`, persistido `:227`, copiado al asset `:776`). En la ruta img2img esto es lo
   que explica por qué se eligió un render y no el otro. Y el rastro humano: `preference_history`,
   `stage_review_history` y los eventos `human_stage_review_v1` / `human_stage_override_v1`
   (`asset_library.py:366-383`, `:388-410`) que hoy sólo tenían consumidor en el código muerto
   (`app.js:1444-1445`). Sólo lectura; para escribir "undo" faltaría arreglar el escritor no atómico de
   `asset_review.json` (`asset_library.py:415-416`).

---

### S5 — Library (`/library`)

**Sustituye a**: Library (`index.html:106-143`) y el Character Workspace (`index.html:147-177`), que hoy son
dos galerías con filtros distintos sobre el mismo array.

**Por qué cambia.** El contenido sobrevive; el eje que falta es el veredicto de máquina. Verificado: los
candidatos rechazados por la máquina **sí entran en la galería por defecto**, porque `visible_states`
incluye `REJECTED_QUALITY`, `RETRY_EXHAUSTED` y `REVIEW_FAILED` (`asset_library.py:687`),
`library_status` los deja en `UNREVIEWED` (`:848-852`) y `is_visible_library_asset` sólo excluye
`{REJECTED, REMOVED, DELETED, SOFT_DELETED}` (`:28`, `:32-45`). La vista "Rejected" actual filtra por
`library_status === 'REJECTED'` (`app.js:837`, `:844`), que es rechazo **humano**. Es decir: la galería por
defecto mezcla aprobadas por máquina, rechazadas por máquina y no revisadas, sin distinguirlas.

**Contenido:**

1. **Dos ejes independientes** en lugar de cuatro vistas mezcladas:
   - Eje máquina: `MACHINE PASS` / `MACHINE REJECTED` / `REVIEW FAILED` / `UNREVIEWED_BY_MACHINE` — (a)
     `final_status` (`asset_library.py:765`) y `final_review_verdict` (`:766`).
   - Eje humano: Approved / Rejected / Favorite / Untouched — (a) `human_review.status`, `favorite`.

2. **Tarjeta con la causa, no sólo la nota.** Además de lo que ya muestra (`app.js:1201-1206`), un badge con
   el `applied_caps[0].reason` cuando hay tope, y el `canonical_reference_count == 0` como marca de
   "identidad no verificada". (a) — mismo payload, cero backend.

3. **Filtros derivados, no hardcodeados.** El filtro de renderer actual hardcodea 7 renderers en el HTML
   (`index.html:124`); deben derivarse de `render_outputs[].renderer` de los assets presentes. (a).
   Y filtros nuevos sobre datos que ya viajan: por `applied_caps.reason`, por `preset`
   (`asset_library.py:760`), por `creation_mode` (`:784`), por rango de cualquiera de los 5 `agent_scores`.

4. **Agregados Hard funcionando en todas las vistas.** `updateHardStats` (`app.js:1112-1163`) ya calcula
   media de score, media de delta y distribución 90+/80-89/70-79/<70, pero sólo se invoca cuando el grid es
   `library-assets-grid` (guarda en `app.js:1169`), así que en el Character Workspace queda obsoleto. (a).
   Y un agregado nuevo sobre datos existentes: **qué tipo de hook puntúa**, agrupando
   `primary_hook_targets` y `context_hook_types` contra `final_score` en toda la Librería — (a) campos del
   contrato del evaluador duro, ya persistidos en `hard_rating`.

5. **Búsqueda de verdad.** `GET /api/library/search` existe (`main.py:395-398`) y **la UI no lo llama
   nunca** (verificado: 0 ocurrencias de `library/search` en los 4 archivos del frontend). Hoy el filtrado
   es en cliente sobre `character`, `franchise`, `collection_display_name` y `concept_snapshot`
   (`app.js:920-927`).

6. **Selección múltiple** con Remove y Hard Re-Evaluate — (a) ya existen (`index.html:128-136`), **pero el
   Hard Re-Evaluate por lotes debe pasar a trabajo con sondeo**, no a `await fetch`. Razón medida:
   `main.py:472-521` es `async def` y toma el `filelock` con `timeout=600` **por asset dentro del event
   loop** (`:490`, `:498`); con una misión en curso eso congela el servidor entero 600 s por imagen —
   `03_CONCURRENCY.md` C6 documenta 4 × 600 s = 40 minutos de servidor inutilizable y 4 registros
   `evaluation_failed` durables que no son fallos de evaluación sino de contención. Es una **dependencia de
   backend** (§6), no un detalle de UI.

---

### S6 — Character (`/character/{name}`)

**Sustituye a**: Characters (`index.html:81-104`) y el Character Workspace.

**Por qué esta pantalla.** T5 es la única tarea con retorno compuesto: acertar el routing de un personaje
mejora todas sus misiones futuras. Y es donde vive el hueco más grande de "capacidad a medias": el campo
que gobierna el routing —`renderer_capabilities.{renderer}.identity_recognition`, leído en
`ada_app/character_capabilities.py:54-73` y bloqueante en `main.py:243-247`,
`renderer_pipeline.py:93-96`— **no lo escribe nada en el repositorio**, y sólo 2 de las 12 entradas del
catálogo lo tienen (verificado en `ROADMAP_IDEAS.md` §11 contra `data/characters/catalog.json`).

**Contenido:**

1. **Ficha de capacidad**: el `capability` con su `reason`, y los `renderer_capabilities` crudos con el
   estado honesto "no verificado" cuando faltan. (a) — ambos ya servidos por
   `GET /api/characters/catalog` (`character_capabilities.py:174-175`).

2. **Cobertura de referencias, con evidencia por referencia**: `file`, `source_url`, `domain`,
   `final_score`, `recommendation`, `sha256`, `downloaded_at`, `duplicate_hashes`, y el `status` del
   manifest. (a) — los manifests ya llevan todo eso (`data/references/*/manifest.json`, normalizados v1→v2
   por `scripts/character_reference_manifest.py:16-30`, esquema en
   `data/references/manifest.schema.json`), y `scripts/validate_storage.py:76-97` ya verifica manifest a
   manifest que cada imagen existe y su hash coincide. **No hay endpoint**: E5 (§6).

3. **Evidencia derivada de las reviews de producción**: por `(personaje, renderer)`, tasa de
   `identity.result == "PASS"`, media de `agent_scores.identity` y tamaño de muestra, **filtrado por
   `canonical_reference_count > 0`**. (a) — todos los campos están en el índice
   (`asset_library.py:759` personaje, `:748` renderer, `:783` scores). Se presenta como **propuesta**, no
   como escritura automática: no existe ningún escritor atómico de `catalog.json` para
   `renderer_capabilities` (el más cercano, `save_character_hero`, escribe `heroes.json` con `write_text`
   directo, `character_capabilities.py:47`). Cero coste de backend para *informar*.

4. **Portada y su procedencia**: `cover_source` (`stock_hero` / `library_hero` / `stock` /
   `canonical_reference` / `library_latest`) y `stale_hero`. (a) — `character_capabilities.py:173-174`. Hoy
   la degradación a `library_latest` es silenciosa.

5. **Galería del personaje**, que es S5 con el filtro aplicado por URL. No una segunda galería con sus
   propios filtros.

---

### S7 — Health (`/health`)

**Nueva.** No sustituye nada porque hoy no existe. Sustituye a Settings sólo en la parte que Settings
finge: 30 líneas de texto estático y campos `disabled` con la nota "Configuration editing will be enabled
in a future version" (`index.html:546-556`).

**Por qué existe.** T6 y T4 no tienen hogar. Y las tres peores pérdidas de datos del sistema
(`02_STATE_RECOVERY.md` §11) son silenciosas por construcción: `MissionStore.load` se traga un JSON
corrupto con `except: return None` (`mission.py:178`) y `list_all` lo salta con `except: continue`
(`:186`), así que **una misión corrupta desaparece de la UI sin ningún aviso**.

**Contenido:**

1. **Integridad del dataset.** sha256 de cada blob contra `storage_provenance.sha256`, apertura de cada
   imagen, hashes de referencias, misiones parseables, entradas de `hard_rating_history`. (a) — está todo
   escrito: `scripts/validate_storage.py`, 146 líneas completas que emiten un informe JSON con 18 métricas
   (`:119-141`), con **cero importadores en todo el repo** (verificado por grep sobre `ada_app/`,
   `scripts/`, `tests/`, `ada.py`). Y `verify_managed_record`
   (`ada_app/managed_assets.py:101-107`), el verificador por registro, tampoco tiene ningún llamador.
   Hace falta E4 (§6) **y** quitar la mutación oculta: `validate_storage.py:44` hace
   `AssetLibrary().get_assets()`, que dispara `build_index()` si el índice está vacío
   (`asset_library.py:835-836`) — el validador "read-only" puede ejecutar el rebuild destructivo que
   pretende diagnosticar (`02_STATE_RECOVERY.md` H16).

2. **Recuperabilidad**: `N registros en data/library/records/` frente a `M entradas en index.json`. (a) —
   cada adopción escribe una instantánea atómica por asset (`managed_assets.py:93-97`) que **nadie lee
   jamás**, mientras el rebuild filtra por existencia del fichero original de ComfyUI
   (`asset_library.py:731`). Ese contador es la respuesta a "si ComfyUI limpia su `output/`, ¿cuánto
   pierdo?". Nota que la interfaz debe dar: los nombres de `records/` colapsan la puntuación del
   `asset_id` (`_safe_key`, `managed_assets.py:26-28`), así que el número es un techo, no una garantía
   (`02_STATE_RECOVERY.md` H17).

3. **Misiones no legibles y misiones clavadas.** Cuántos `mission_*.json` no parsean, y cuántas están en
   estado activo sin hilo vivo. (a) — derivable, §7 Camino A3. Con el botón **Abandon** (E9).

4. **Últimos fallos, estructurados.** Las últimas N entradas de `failure_details` de misiones y candidatos,
   con etapa, tipo de excepción y `concept_id`. (a) — ya persistido (`renderer_pipeline.py:55`,
   `mission.py:70`). Esto **sustituye** a un visor de logs, que no puede existir: cero `import logging` en
   `ada_app/` y cero archivos `.log`; los `traceback.print_exc()` de
   `mission_runner.py:168, 191, 248, 386` y `pilot_runner.py:688, 750` van a stdout de una ventana lanzada
   sin redirección (`START_ADA_APP.cmd:14`) y mueren con ella.

5. **Configuración efectiva, en sólo lectura.** Los presets de producción realmente en uso y la política de
   fuentes de la Librería. (a) — `production_render_config()` relee `config/pipeline.json` en cada llamada
   sin caché (`scripts/production_workflows.py:55-60`), y `LIBRARY_SOURCE_POLICY`
   (`asset_library.py:18-23`) ya se sirve por `GET /api/library/source-policy` (`main.py:405-409`),
   endpoint que la UI nunca llama. **Sólo lectura**, y §5 explica por qué.

---

## 3. Información que hoy existe y no se ve

El corazón del documento. 55 elementos verificados, agrupados por función. Columna **P** = pantalla del
diseño. Columna **Endpoint** = si algo lo sirve hoy.

Antecedente medido que sostiene la mayor parte de la tabla: `Asset.to_dict`
(`ada_app/asset_library.py:228-283`) serializa `render_outputs`, `render_receipts`, `prompt_artifacts`,
`stage_render_plans`, `review_observations`, `resolved_render_spec`, `character_contract`, `agent_scores` y
`lineage`. Es decir, `GET /api/library/assets` (`main.py:390-393`) **ya entrega al navegador** la review
completa, la semilla, el workflow y el prompt de cada imagen. Buena parte de lo que sigue es frontend puro.

### 3.1 Veredicto de máquina por imagen

| # | Dato | Producido en | Persistido / servido | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|---|
| 1 | `applied_caps` `[{reason, cap}]` con las 5 causas exactas | `scripts/specialist_visual_reviewer.py:162-184`, devuelto en `:200` | `renderer_pipeline.py:198` → `asset_library.py:778` → `to_dict:268` | **Sí**, `/api/library/assets` | S4, S5 | **(a)** |
| 2 | `rating_before_caps` | `specialist_visual_reviewer.py:195-199` | idem | Sí | S4 | **(a)** |
| 3 | `agent_scores` (5 dims) y sus pesos | `:152`, pesos `:153-157`, devuelto `:193` | `asset_library.py:783` → `to_dict:281` | Sí | S4, S5 | **(a)** |
| 4 | `canonical_reference_count` | `:201` (vía `canonical_reference_paths` `:40-77`) | idem review | Sí | S2, S4, S5, S6 | **(a)** |
| 5 | `identity.result/score/confidence` | `:151`, `:187` | idem | Sí | S4 | **(a)** |
| 6 | `subject_count.expected/actual/result` | `:140-150`, `:188` | idem | Sí | S4 | **(a)** |
| 7 | `identity_failures`, `defects`, `hard_constraint_failures` | `:158-164`, `:189-191` | idem | Sí | S4 | **(a)** |
| 8 | 4 observaciones v4 del modelo (`candidate_observations`, `reference_observations`, `identity_comparison`, `outfit_design_adherence`) | modelo, requeridas por `schemas/visual_review_v4.schema.json`; arrastradas por `**value` en `:186` | idem | Sí | S4 | **(a)** |
| 9 | `final_status` (`MACHINE_PASS` / `REJECTED_QUALITY` / `REVIEW_FAILED` / …) | `asset_library.py:765` | `to_dict:238` | Sí | S4, S5 | **(a)** |
| 10 | `final_review_verdict` | `asset_library.py:766` | `to_dict:239` | Sí | S5 | **(a)** |
| 11 | `review_observations[renderer]` (observación normalizada) | `renderer_pipeline.py:195-196`, `:199` | `asset_library.py:774` → `to_dict:259` | Sí | S4 | **(a)** |

Verificado: cero ocurrencias de `applied_caps`, `rating_before_caps`, `canonical_reference_count` y
`final_status` en `ada_app/static/` y `ada_app/templates/`.

### 3.2 Reproducibilidad y procedencia

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 12 | Seed determinista `sha256(run:concept:renderer)` | `renderer_pipeline.py:145` → `receipt.generation` `:163`, `:173` | Sí | S4 | **(a)** |
| 13 | `receipt.workflow` (ruta absoluta del grafo) | `renderer_pipeline.py:173` | Sí (sin etiqueta en la UI) | S4 | **(a)** |
| 14 | Grafo ComfyUI completo, `workflows/{r}_attempt_01.json` | `renderer_pipeline.py:159` | **No** → E7 | S4 | **(a)** dato, **(b)** endpoint |
| 15 | `prompt_artifacts[r].prompt` (prompt final) | `renderer_pipeline.py:141-144` | Sí | S4 | **(a)** |
| 16 | Parámetros efectivos (steps, cfg, sampler, resolución) | `production_workflows.py:318-329` → `renderer_pipeline.py:163` | Sí | S4 | **(a)** |
| 17 | `storage_provenance` {sha256, bytes, managed_path, original_source_path, adopted_at, copy_verified} | `managed_assets.py:78-89`; entra en el índice vía `asset_library.py:515` | Sí | S4, S7 | **(a)** |
| 18 | `source_artifact_root` | `asset_library.py:777` | Sí | S4, S3 | **(a)** |
| 19 | `lineage.sibling_image_ids` / `selected_image_id` / `generation_mode` / `template_mode` | `asset_library.py:781` | Sí | S4 | **(a)** |
| 20 | `automatic_final_renderer_decision` con `reason` y `source` | `renderer_pipeline.py:225`, persistido `:227`, copiado `:776` | Sí | S4 | **(a)** |
| 21 | `comparative_review` (`preferred_renderer`, `confidence`, `requires_human_review`) | `renderer_pipeline.py:221-223`, copiado `:776` | Sí | S4 | **(a)** |
| 22 | `stage_render_plans[r]` (plan de etapa validado) | `renderer_pipeline.py:138`, `:143` | Sí | S4 | **(a)** |

### 3.3 Evaluación dura

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 23 | `hard_rating_history` append-only, incluidos fallos | `asset_library.py:451-456`, atómico `:462-464`; viaja vía `get_assets` `:845` | Sí | S4 | **(a)** |
| 24 | `original_score` y `delta` | `main.py:508-509` | Sí (`original_score` nunca pintado) | S4 | **(a)** |
| 25 | Sub-scores duros y `problems` | contrato `config/runtime_instructions/hard_visual_review_v1.md`, cargado `hard_re_evaluator.py:11` | Sí (parcial en el modal) | S4 | **(a)** |
| 26 | `primary_hook_targets` / `context_hook_types` agregados contra `final_score` | idem | Sí (dato); agregado no existe | S5 | **(a)** |
| 27 | Registro de fallo de evaluación `{evaluation_failed, error, traceback}` | `main.py:516-517` | Sí (la UI lo descarta, `renderer_library.js:78`) | S4 | **(a)** |
| 28 | Modelo efectivo de cada evaluación dura | — `hard_re_evaluator.py:23` envía `"model": "local-model"` | No | S4 | **(b)** 1 línea |

### 3.4 Economía de conceptos y selección

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 29 | `quality.score` / `quality.reason` por concepto | `m3_filter.py:94-99`; persistido `mission_runner.py:301` | **Sí**, `/api/missions/{id}/funnel` como `item.m3` (`main.py:309`, `:320`) | S3 | **(a)** |
| 30 | `diversity.score` y `similar_to[]` (concept_id + score) | `m3_filter.py:100-103` | Sí, idem | S3 | **(a)** |
| 31 | `summary` de lote {generated, unique, duplicates, recommended, weak} | `m3_filter.py:107-114` | No en el funnel (sólo por concepto) → E1 lo añade | S3 | **(a)** |
| 32 | `semantic_status` por concepto (rechazo del guardián) | `main.py:319` desde `proposal_records.json` | Sí | S3 | **(a)** |
| 33 | `selection_rank` y `selection_reason` | `m4_selection.py:79-80` | Sí | S3 | **(a)** |
| 34 | `viral_score` | `m4_selection.py:56` vía `calculate_dataset_score` `:5-38`; sólo sobrevive interpolado en una frase, `:80` | No | S3 | **(b)** 1 línea |
| 35 | Telemetría M2: `latency_seconds`, tokens in/out, tok/s, TTFT, retries, `valid_count`, `semantic_guard_rejected_count` | `telemetry.json` del run | **Sí**, `GET /api/runs/{run_id}` (`main.py:706-731`) | S3 | **(a)** |

### 3.5 Fallos

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 36 | `failure_details` por candidato {stage, exception_type, message, traceback, candidate_id} | `renderer_pipeline.py:55` | **Sí**, `GET /api/runs/{run_id}/pilot` (`main.py:699-704`) | S3, S7 | **(a)** |
| 37 | `mission.failure_details` | `mission.py:70`, `:140`; poblado `mission_runner.py:265`, `:275`, `:357` | Sí, `/api/missions/{id}` | S3, S7 | **(a)** |
| 38 | Fallo de M2 con `exit_code`, `stderr`, `stdout` | `m2_failure_detail`, `mission_runner.py:42-50` → `:265` | Sí (la UI sólo pinta `error_message`, `:269`) | S3 | **(a)** |

Verificado: cero ocurrencias de `failure_details`, `exception_type` y `traceback` en `ada_app/static/` y
`ada_app/templates/`.

### 3.6 Progreso y vitalidad (derivables, ver §7)

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 39 | Secuencia de artefactos por candidato con `mtime` (14 puntos, 24 con img2img) | `renderer_pipeline.py:84`, `:86-90`, `:143`, `:144`, `:159`, `:175`, `:196`, `:223`, `:227` + `specialist_visual_reviewer.py:411-412`; escritura inmediata (`pilot_runner.py:70-72`) | **No** → E1 | S3 | **(a)** dato, **(b)** endpoint |
| 40 | Latencia del VLM por review (`latency_seconds`, tokens, `finish_reason`, TTFT) | `specialist_visual_reviewer.py:353-358`, persistido `:412` | No → E1 | S3, S4 | **(a)** dato |
| 41 | Cola y VRAM de ComfyUI en vivo `{idle, running, pending, vram_free, vram_total}` | `lmstudio_controller.py:301-314` | No (sólo un ping a `/system_stats`, `main.py:165`) → E3 | S1, S3 | **(a)** dato |
| 42 | Qué candidato está renderizando ComfyUI ahora mismo | `client_id = f"ada-mini-{renderer}-{concept_id}-{uuid}"`, `run_specialist_mini_e2e.py:36`; y `filename_prefix = AdaProduction/{run}/{concept}/{renderer}` en el grafo, `renderer_pipeline.py:157` | No → E3 | S1, S3 | **(a)** dato |
| 43 | Vitalidad autoritativa del hilo de misión | hilo nombrado `mission-{mission_id}`, `mission_runner.py:391`, **en el mismo proceso que uvicorn** | No → E2 | S1, S3, S7 | **(a)** dato |
| 44 | `duration_seconds` vivo | `mission.py:89-97`, serializado `:144` | **Sí** (la UI sólo lo pinta en la rama terminal, `app.js:687`) | S1, S3 | **(a)** |
| 45 | Número de ronda durante producción | nombre del run: `f"m2_{mission_id}_r{round:02d}_…"`, `mission_runner.py:254-257`; `source_runs` persistido antes de producir (`:285`, `:291`) | Sí (derivable de `/api/missions/{id}`) | S3 | **(a)** |

### 3.7 Capacidad, referencias e integridad

| # | Dato | Producido en | Endpoint hoy | P | a/b |
|---|---|---|---|---|---|
| 46 | `capability` con `reason`, y `renderer_capabilities` crudos | `character_capabilities.py:54-73`, `:174-175` | **Sí**, `/api/characters/catalog` | S2, S6 | **(a)** |
| 47 | `cover_source`, `stale_hero`, `stock_image_count` | `character_capabilities.py:169-174` | Sí | S6 | **(a)** |
| 48 | Evidencia por referencia canónica (`source_url`, `domain`, `final_score`, `sha256`, `duplicate_hashes`, `status`) | `data/references/*/manifest.json`, normalizado `character_reference_manifest.py:16-30`; verificación en `validate_storage.py:76-97` | **No** → E5 | S2, S6 | **(a)** dato, **(b)** endpoint |
| 49 | Informe de integridad de 18 métricas | `scripts/validate_storage.py:56-141`, **cero importadores** | **No** → E4 | S7 | **(a)** código, **(b)** endpoint + fix read-only |
| 50 | Verificación sha256 por registro | `managed_assets.py:101-107`, **cero llamadores** | No → E4 | S7 | **(a)** |
| 51 | `data/library/records/{asset_id}.json` (instantánea atómica por adopción) | `managed_assets.py:93-97`, **cero lectores en todo el repo** | No → E4 | S7 | **(a)** |
| 52 | `LIBRARY_SOURCE_POLICY` | `asset_library.py:18-23` | **Sí**, `/api/library/source-policy`, nunca llamado | S7 | **(a)** |
| 53 | `scene_template_spec_v1` derivable de cualquier asset (13 campos) | `reinterpretation.py:59-63`, persistido `:79`, atómico `:40-41` | **No** → E8 | S2 | **(a)** dato, **(b)** endpoint |
| 54 | Rastro humano por evento (`human_stage_review_v1`, `human_stage_override_v1`, `preference_history`, `stage_review_history`) | `asset_library.py:366-383`, `:388-410` | No → E6 | S4 | **(a)** dato, **(b)** endpoint |
| 55 | `RunReconciliation.reconcile` (deriva etapa válida y acción segura desde artefactos) | `run_reconciliation.py:12-124`; llamado sólo por el pipeline legacy (`pilot_runner.py:297`, `:370`) y con nombres de artefacto legacy | No | S3, S7 | **(a)** patrón, **(b)** v2 para los nombres actuales |

**Recuento: 55 elementos. 46 son (a) puros** — el dato existe y algo ya lo sirve, así que sólo falta
pintarlo. **7 son mixtos**: el dato existe (a) pero hace falta exponerlo (#14, #39, #48, #49, #53, #54,
#55). **Y sólo 2 son (b) puros**: `viral_score` como campo (#34) y el modelo efectivo del evaluador duro
(#28), una línea cada uno. Fuera de la tabla hay un tercer (b) menor: hacer que `template_mode` signifique
algo en los compiladores (§2 S2).

Dicho de otra forma: **de los 55 datos que este diseño saca a la luz, 53 ya los tiene ADA hoy.**

**Siete endpoints ya implementados que la UI nunca llama** (verificado con grep sobre los 4 archivos del
frontend, 0 ocurrencias cada uno): `GET /api/library/search`, `GET /api/library/source-policy`,
`POST /api/library/build_index`, `POST /api/pilot/resume/{run_id}`, `POST /api/characters/revalidate`,
`GET /api/runs/{run_id}/m3_analysis`, `GET /api/runs/last`.
Advertencia sobre uno de ellos: `POST /api/pilot/resume/{run_id}` arranca el pipeline **legacy**
(`main.py:640` → `pilot_runner.py:775-778` → `run_pilot_pipeline`), no `renderer_pipeline`
(`UI_IMPROVEMENTS.md` §B.1). No es "cablear un botón": no entra en este diseño.

---

## 4. Navegación

**Punto de partida medido**: hoy no hay router. La navegación es `classList.add('active')` sobre
`div.tab-content` (`app.js:11-30`, `:32-40`) y **cero ocurrencias** de `location.hash`, `pushState`,
`replaceState`, `hashchange` y `URLSearchParams` en los 4 archivos del frontend (verificado por grep). Tres
consecuencias medidas:

- `mission-detail` es una pantalla huérfana: existe como `tab-content` (`index.html:305`) sin ninguna
  entrada de sidebar (`index.html:12-43`), sólo alcanzable programáticamente (`app.js:617`, `:75`).
- `switchTab('queue')` (`app.js:586`) apunta a un `id` que no existe: pantalla en blanco justo después del
  único flujo que lanza N misiones a la vez.
- "View Assets in Library" fija el filtro y llama `switchTab` (`app.js:812-817`), pero `switchTab` sólo
  cambia clases: la Library se muestra con los datos que hubiera en memoria y el filtro no se aplica.

### 4.1 Rutas y qué es deep-linkable

| Ruta | Pantalla | Estado en la URL |
|---|---|---|
| `/` | S1 Workbench | nada |
| `/launch` | S2 Launch | `?character=`, `?from_asset=` (plantilla de escena), `?mode=scene\|stock` |
| `/run/{mission_id}` | S3 Run Monitor | `?tab=timeline\|concepts\|failures\|artifacts`, `?candidate={concept_id}` |
| `/image/{asset_id}` | S4 Image | `?tab=verdict\|repro\|history\|siblings`, `?renderer=` (hermano activo) |
| `/library` | S5 Library | `?machine=`, `?human=`, `?character=`, `?renderer=`, `?preset=`, `?cap=`, `?agent_min=`, `?human_min=`, `?sort=`, `?q=`, `?mission=` |
| `/character/{name}` | S6 Character | `?tab=capability\|references\|evidence\|gallery` |
| `/health` | S7 Health | `?report={report_id}` (informe de integridad ya calculado) |

**Regla**: si un estado se puede reconstruir desde el servidor y tiene sentido compartirlo o volver a él,
va en la URL. Si es efímero o de sesión, no.

**En la URL**: pantalla, identidad del objeto (mission_id, asset_id, nombre de personaje), todos los
filtros y el orden de la Library, la pestaña activa dentro de una pantalla, el candidato abierto en S3, el
renderer hermano activo en S4, el `report_id` de integridad.

**Fuera de la URL**: el conjunto de assets seleccionados en modo selección múltiple (efímero y
potencialmente enorme), el estado abierto/cerrado de acordeones (hoy en `localStorage`, clave
`ada-active-missions-expanded`, `app.js:53-54`, `:99-101`: se conserva ese patrón), la cadencia de sondeo,
y el texto no enviado del command bar.

### 4.2 Cómo se pasa de una pantalla a otra

Cada transición existe porque cierra una de las seis tareas. No hay ninguna que sea "volver al menú".

```
S1 Workbench ──"misión en curso"──────────────► S3 Run/{id}
             ──"misiones interrumpidas"───────► S7 Health?tab=stuck
             ──command bar / botón Launch─────► S2 Launch
             ──"servicios degradados"─────────► S7 Health

S2 Launch ────crear──────────────────────────► S3 Run/{id}          (reemplaza el historial, no lo apila)
          ────"referencias insuficientes"─────► S6 Character/{name}?tab=references

S3 Run ───────fila de candidato aprobado─────► S4 Image/{asset_id}
       ───────"ver todas las de esta misión"──► S5 Library?mission={id}
       ───────panel de fallo──────────────────► S7 Health?tab=failures
       ───────breadcrumb───────────────────────► S1

S5 Library ───tarjeta──────────────────────────► S4 Image/{asset_id}
           ───nombre de personaje──────────────► S6 Character/{name}
           ───"reinterpretar con esta escena"──► S2 Launch?from_asset={asset_id}

S4 Image ─────"run de origen"──────────────────► S3 Run/{mission_id}?candidate={concept_id}
         ─────hermano───────────────────────────► S4 Image/{sibling_id}   (misma pantalla, otro id)
         ─────personaje────────────────────────► S6 Character/{name}
         ─────"generar variante"───────────────► S2 Launch?from_asset={asset_id}

S6 Character ─"generar para este personaje"────► S2 Launch?character={name}
             ─galería───────────────────────────► S5 Library?character={name}

S7 Health ────misión clavada───────────────────► S3 Run/{id}
          ────asset con hash roto──────────────► S4 Image/{asset_id}
```

Dos reglas de comportamiento que el diseño actual incumple y que aquí son explícitas:

1. **Navegar carga.** Cada ruta es responsable de cargar sus propios datos al entrar, viniendo de donde
   venga. El bug de `switchTab` (`app.js:812-817` vs `openLibraryCollection` en `app.js:900`, que sí llama
   `loadLibrary()`) es la consecuencia directa de no tener esa regla.
2. **Salir para el sondeo.** Al abandonar `/run/{id}` el sondeo se detiene. Hoy el handler del sidebar
   (`app.js:11-30`) no limpia `missionPollInterval`, así que el intervalo sigue haciendo 2 peticiones cada
   3 s contra un panel oculto indefinidamente (`05_UX_OBSERVABILITY.md` Hallazgo 3.1.1), y una de esas
   peticiones puede disparar un `build_index` completo (`main.py:301-303` → `asset_library.py:835-836`).

### 4.3 Cadencia de sondeo

Sin WebSocket y sin SSE (§5). Tres cadencias, no una:

| Superficie | Cadencia | Endpoint |
|---|---|---|
| S3 durante producción | 2 s | E1 (progreso derivado del run dir; **no** toca `AssetLibrary`) |
| S1 con misión activa | 5 s | E2 + E3 |
| S1/S3 sin misión activa | sin sondeo | — |
| S5, S4, S6, S7 | sin sondeo | eventos de usuario |
| S7 informe de integridad | trabajo + sondeo del `report_id` | E4 |

Hoy son ~800 peticiones en una misión de 20 minutos, dos por tick, y una de ellas instancia
`AssetLibrary()` y llama `get_assets()` cada 3 segundos (`main.py:301-303`). El nuevo E1 debe ser
deliberadamente barato: `os.scandir` sobre un directorio y una lectura de `pilot_candidates.json`.

---

## 5. Qué NO va en la interfaz

Una pantalla que lo muestra todo no ayuda a nadie. Cada exclusión tiene su razón medida.

| Fuera | Por qué |
|---|---|
| **Model Lab y Benchmarks como pantallas** (hoy `index.html:392-472`, 5 endpoints) | La pregunta que responden —"¿qué renderer/preset funciona para este personaje?"— se responde mejor con evidencia de producción en S6 (§3.7 #46, muestra real, no sintética). Y el ancla es débil: su raíz de datos `experimental/model_lab/` **no existe en el snapshot** (`00_MAP.md` §8.3), `model_lab.py`, `direct_generator_lab.py` y `model_benchmark.py` son 3 de los 11 módulos de `ada_app/` sin ningún test que los importe (`00_MAP.md` §6.1), y sus esquemas escriben la etiqueta `schema_version` sin pasar por `validate_contract` (`04_AI_AGENTS.md` F-08). Además no hay camino de promoción: `LIBRARY_SOURCE_POLICY` declara `promotion_required: ["model_lab", "benchmark", "manual_benchmark"]` (`asset_library.py:18-23`) y **no está implementado** (`model_benchmark.py:206`: "No automatic promotion"). Un render de benchmark que no puede entrar en la Librería no cierra ninguna de las seis tareas. Los endpoints siguen existiendo; dejan de tener pantalla. |
| **Creative Lab** (`index.html:328-390`) | `POST /api/creative_expansion` (`main.py:757-765`) lanza un subproceso contra `experimental/` con `BackgroundTasks`, sin lock de GPU, y su panel de progreso (`pollPilot`, `app.js:1730-1762`) es una versión peor de S3. Duplicar la pantalla de monitorización para un camino no productivo es coste puro. |
| **Videos (Legacy)** (`index.html:318-326`) | Es un placeholder "Coming next". El MiniMax Agent existe (`scripts/specialist_agents.py:296`) y produce un prompt de vídeo, pero **nada** en el alcance lo conecta a un renderer. Diseñar una pantalla para eso sería diseñar para un dato (b) sin marcar. |
| **Roadmap** (`index.html:468`, `GET /api/roadmap` lee `config/roadmap.json`) | Documentación de producto. No es una tarea del operador. |
| **Settings editable** | `production_render_config()` relee `config/pipeline.json` en **cada** llamada sin caché (`production_workflows.py:55-60`) y **no existe snapshot por run** del pipeline (sí lo hay para M2: `m2_config_snapshot.json`). Editar a mitad de misión cambia el preset entre dos candidatos de la misma ronda y nada registra qué valor se usó en cada uno. Peor: los guardianes de workflow comparan el grafo contra la config viva (`production_workflows.py:180-189`, `:211-236`), así que una edición puede hacer fallar la validación de un render en vuelo. **Condición para levantarlo**: congelar `pipeline.json` por run primero. Hasta entonces, S7 lo muestra en sólo lectura. |
| **Visor de logs** | Cero `import logging` y cero `getLogger` en `ada_app/` (verificado). Cero archivos `.log`. Sería un panel para un archivo vacío. Se sustituye por `failure_details` estructurado en S3 y S7 (§3.5). |
| **Gestor de cola / prioridades / "2 misiones en paralelo"** | Un `filelock` con `timeout=86400` (`mission_runner.py:186`) no es una cola: adquiere por sondeo, **sin FIFO**, así que la misión que lleva 3 h esperando puede perder frente a la recién creada (`03_CONCURRENCY.md` §1.2). Todos los locks de datos son intra-proceso (`asset_library.py:24-26`, `character_capabilities.py:16`, `reinterpretation.py:26`), así que `--workers 2` no protegería nada. S1 **muestra** la espera; no ofrece un control que el backend no puede honrar. |
| **Progreso del sampler dentro de un render** ("paso 12/30") | Requeriría el WebSocket de ComfyUI, que no existe en el alcance (0 ocurrencias de `websocket`/`EventSource`/`text/event-stream` en `ada_app/` y `scripts/`). Marcado **(b)** y deliberadamente fuera: §7 explica que los límites de paso ya dan el 90 % del valor. |
| **Etiquetas, notas o colecciones propias por imagen** | Si se persisten como campos del registro del índice, se pierden: `_load_index` descarta el índice **completo** y devuelve sólo `explicit_images.json` si cualquier registro carece de `record_type == "library_image_v2"` (`asset_library.py:482-483`) o ante cualquier excepción (`:487-488`), y `_build_index_unlocked` reemplaza el fichero entero (`:787`, `:791`). El índice es una caché descartable. Sin un satélite indexado por `asset_id` (el patrón de `asset_review.json`), no hay pantalla de anotación. |
| **Undo del juicio humano** | El rastro por evento ya se escribe (`asset_library.py:366-383`, `:388-410`) y S4 lo **muestra**. Pero el escritor principal de `asset_review.json` es reemplazo total no atómico (`:415-416`) con last-writer-wins, y el evento se escribe **antes** de actualizar la review, así que un fallo entre `:382` y `:415` deja el evento sin efecto. Mostrar, sí. Deshacer, no todavía. |
| **Recolección de basura de blobs huérfanos** | Los blobs son direccionados por contenido y **compartidos** entre assets con píxeles idénticos (`managed_assets.py:61-65`). No hay índice inverso, `records/` no se lee nunca y el índice se vacía solo. **Ninguna ruta de código puede demostrar hoy que un blob no está referenciado.** Es la feature más peligrosa que se podría construir. |
| **Programar misiones (scheduler)** | Encolaría hilos daemon sobre un filelock de 24 h sin orden garantizado, y no hay ningún `on_event`/`lifespan`/hook de arranque en `ada_app/` que reconcilie: una misión programada que muera queda clavada en `PRODUCING`, no reanudable (`main.py:349-350`) ni borrable (`mission.py:158`). |
| **Login, multiusuario, temas, notificaciones, app móvil** | Prohibidas por el encargo, y hay una razón concreta de ADA para la primera: `GET /api/image` (`main.py:57-62`) acepta un parámetro `path` y devuelve `FileResponse(str(p))` **sin validar que esté bajo ninguna raíz**. Es lectura arbitraria de ficheros para cualquiera que alcance el puerto, y es el mecanismo por el que la UI muestra **todas** las imágenes. Exponer ADA fuera de `127.0.0.1` no es un problema de autenticación: es un problema de este endpoint. Por eso E7 sirve artefactos **por identificador**, no por ruta. |

---

## 6. Distancia respecto a lo que hay hoy

### 6.1 Pantallas: 11 → 7

| Pantalla actual | Destino |
|---|---|
| `home` (`index.html:48`) | **Cambia de forma y de contenido** → S1. Pierde assets recientes y colecciones; gana vitalidad, cola y etapa fina. |
| `library` (`index.html:106`) | **Sobrevive en contenido, cambia de eje** → S5. |
| `characters` (`index.html:81`) | **Sobrevive, se fusiona** con Character Workspace → S6. |
| `create` (`index.html:214`) | **Sobrevive, gana preflight** → S2. |
| `mission-detail` (`index.html:305`) | **Sobrevive el propósito, se rehace** → S3. Deja de ser huérfana: gana ruta. |
| `runs` (`index.html:424`) | **Desaparece** como pantalla; se absorbe en S3 (por misión) y S7 (fallos). |
| `model-lab` (`index.html:392`) | **Desaparece** (§5). |
| `settings` (`index.html:474`) | **Desaparece** como pantalla editable; su parte real (sondas + config efectiva) va a S1 y S7. |
| `creative` (`index.html:328`) | **Desaparece** (§5). |
| `roadmap` (`index.html:468`) | **Desaparece** (§5). |
| `videos` (`index.html:318`) | **Desaparece** (§5). |
| Asset Detail Modal (`renderer_library.js:43-262`) | **Se promociona a pantalla** → S4. |
| Panel Compare (`index.html:203`) | Se absorbe en S4 (hermanos). |
| Panel Reinterpret (`renderer_library.js:200`) | Se absorbe en S2 (`?from_asset=`). |
| — | **Nueva**: S7 Health. |

**Balance**: 4 de 11 sobreviven en contenido; **las 4 cambian de forma**. 6 desaparecen. 1 (el modal) sube
de rango. 1 es nueva.

### 6.2 Endpoints nuevos: 9

Ninguno inventa datos. Todos exponen algo ya persistido o ya calculado.

| # | Endpoint | Qué hace | Coste | Datos §3 |
|---|---|---|---|---|
| **E1** | `GET /api/runs/{run_id}/progress` | Escanea `{run_dir}/pilot/*` (presencia + `mtime` de los 11 artefactos), une con `pilot_candidates.json` y añade el `summary` de `m3_analysis.json`. **No** construye `AssetLibrary`. | S — un `os.scandir` y 2 lecturas de JSON | 39, 40, 31 |
| **E2** | `GET /api/missions/{id}/live` | Contadores derivados de `pipeline_state` en los `source_runs`, ronda desde el nombre del run, `duration_seconds`, y vitalidad por `threading.enumerate()`. | S | 43, 44, 45 |
| **E3** | `GET /api/gpu` | `comfy_status(COMFYUI_BASE_URL)` + `client_id` del prompt en ejecución + modelos cargados en LM Studio + quién tiene el lock. En `asyncio.to_thread`. | S — reutiliza `lmstudio_controller.py:301-314` | 41, 42 |
| **E4** | `POST /api/library/integrity` + `GET /api/library/integrity/{report_id}` | Trabajo + sondeo alrededor de `validate_storage.main()` refactorizado para **devolver** el dict (`:119-141` ya lo construye, `:142` lo imprime) y para leer `index.json` directamente en vez de construir `AssetLibrary` (`:44`). Añade el recuento de `records/`. | M — refactor + fix read-only + patrón de trabajo | 49, 50, 51 |
| **E5** | `GET /api/characters/{name}/references` | Resuelve el manifest, cuenta resolubles y verifica sha256 por referencia; devuelve la evidencia. | S — reutiliza `validate_storage.py:76-97` y `character_capabilities.py:113-127` | 48, 4 |
| **E6** | `GET /api/assets/{asset_id}` | Un asset con su rastro humano por evento listado desde `source_artifact_root`. Evita que S4 descargue el índice completo. | S | 54, y todo §3.1–3.3 |
| **E7** | `GET /api/artifact?asset_id=&kind=&renderer=` | Sirve **un** artefacto de candidato (workflow, prompt, receipt, plan, review) resolviendo la ruta desde `source_artifact_root`, no desde un `path` del cliente. Cierra de paso el patrón peligroso de `GET /api/image`. | S | 14, 22 |
| **E8** | `GET /api/scene-templates` | Glob sobre `RENDERER_RUNS_ROOT/reinterpretations/*.json` extrayendo `scene_template_spec`, deduplicado por `template_id`. | S | 53 |
| **E9** | `POST /api/missions/{id}/abandon` | Marca `FAILED` una misión en estado activo cuyo hilo no existe, para que sea borrable y reanudable. **Depende de D1.** | S, pero bloqueado por D1 | 43 |

Opcional (rendimiento, no funcionalidad): **E10** `GET /api/library/assets?fields=` — una proyección. Hoy
`GET /api/library/assets` entrega `render_outputs` completos, recibos, prompts y planes por asset
(`Asset.to_dict`, `asset_library.py:228-283`), lo que para una galería de cientos de imágenes es enorme.
No es requisito del diseño; es higiene.

Con E1–E9, `main.py` pasa de 45 a 54 rutas **en un solo archivo de 765 líneas**. No es un problema de la
interfaz, pero es el momento razonable para introducir `APIRouter` (hoy no hay ninguno: `00_MAP.md` §5).

### 6.3 Dependencias de backend (lo que hay que levantar o cuestionar)

**Hay que levantarlas — sin esto, pantallas del diseño mienten:**

| # | Restricción | Por qué bloquea | Superficie |
|---|---|---|---|
| **D1** | `MissionStore.save` es `write_text` directo no atómico (`mission.py:166-170`) y `update` es setattr-sobre-objeto-obsoleto + save (`:189-192`), con 17 escritores en `mission_runner.py` frente a 2 en `main.py` | Es la causa de que Cancel se pierda (`05` Hallazgo 5.1.2) y de que un crash a mitad de escritura haga desaparecer la misión en silencio (`mission.py:178`, `:186`). E9 (Abandon) escribe estado de misión: sin el fix, Abandon puede ser pisado por el hilo | Releer bajo lock + fusionar claves + temp/rename. Un método, ~15 líneas |
| **D2** | Cancel no se comprueba nunca dentro de producción (`mission_runner.py:202`, `:295` son los dos únicos puntos, ambos **antes** de `run_renderer_pipeline`) | El botón Cancel de S1 y S3 no puede existir honestamente | **Fichero centinela**, ver §7 B2: 1 línea en el endpoint + 2 en el bucle de `renderer_pipeline.py:241-245`. No toca `MissionStore` |
| **D3** | Endpoints `async def` que construyen `AssetLibrary()` en el event loop (`main.py:390-393`, `:397`, `:402`, `:435`, `:466`, `:480`, `:533`, `:567`) y pueden disparar un `build_index` completo con sha256 de todo el dataset (`asset_library.py:835-836`) | E1 se sondea cada 2 s. Si hereda ese patrón, la pantalla que arregla el progreso congelado congela el servidor | Los endpoints **nuevos** no construyen `AssetLibrary` y usan `asyncio.to_thread` (precedente ya en `main.py:86`, `:120`, `:574`, `:592`) |
| **D4** | `POST /api/library/hard-reevaluate` toma el filelock con `timeout=600` **por asset** dentro del event loop (`main.py:490`, `:498`) | S5 tiene un botón de lote. Tal cual, con una misión en curso son 600 s de servidor muerto por imagen (`03_CONCURRENCY.md` C6) | Convertirlo en trabajo + sondeo, como E4 |
| **D5** | `--reload` por defecto en `START_ADA_APP.cmd:14` | Cualquier `.py` tocado mata el hilo de misión dejando VRAM tomada, un render huérfano y una misión zombi imborrable (`03_CONCURRENCY.md` C9). El badge de vitalidad de S1 diría "Interrupted" **constantemente** en desarrollo | Quitar `--reload` del lanzador de producción. **1 palabra** |

**Que se cuestionan pero se pueden dejar (el diseño no las necesita):**

| # | Restricción | Postura |
|---|---|---|
| **Q1** | Cero WebSocket y cero SSE en todo el repo | **Se acepta y no se levanta.** §7 demuestra que el transporte no era el problema: el productor no emitía nada. Con derivación en el lado de lectura, el sondeo basta |
| **Q2** | Proceso único, `threading.Thread(daemon=True)` (`mission_runner.py:391-392`), sin cola ni worker | **Se acepta.** Y se explota: es precisamente porque el hilo vive en el proceso de uvicorn que `threading.enumerate()` es una prueba de vitalidad autoritativa (§7 A3). Una cola con workers separados **perdería** esa señal |
| **Q3** | Cero logging en `ada_app/` | **Se acepta.** §5: se sustituye por `failure_details` estructurado, que es más útil que un log |
| **Q4** | 45 rutas en un solo `main.py` | Se acepta para el diseño; se recomienda `APIRouter` al añadir las 9 |
| **Q5** | `continue_on_error=False` en Scene (`mission_runner.py:331-337` → default `False` en `renderer_pipeline.py:238`) | **Se cuestiona en serio.** La cronología por candidato de S3 pierde sentido si el primer candidato que explota aborta la ronda entera y descarta los contadores (`mission_runner.py:353` nunca corre). No es requisito del diseño, pero S2 debe **avisarlo** mientras siga así (§2 S2, punto 3) |
| **Q6** | `RETRY_EXHAUSTED` y `SETUP_FAILURE` nunca los produce `renderer_pipeline`, y `REVIEW_FAILED` no se cuenta en ninguna categoría en Scene (`01_MISSION_LIFECYCLE.md` §3.3) | **Se cuestiona.** S3 no pinta contadores que son siempre 0. Muestra los estados reales de `pilot_candidates.json`, que son los 8 verdaderos, y señala explícitamente que `approved + rejected + failed < selected` cuando ocurre |

### 6.4 Qué del frontend actual es reutilizable

3388 líneas en 4 archivos, sin framework, sin build, sin router, sin componentes, sin ningún test.

| Archivo | Líneas | Reutilizable | Qué |
|---|---|---|---|
| `static/style.css` | 670 | **~60 %** como tokens | Las variables de `:root` (`:1-15`) y la escala tipográfica/espaciado son un punto de partida válido. Hay que **definir** `--border-color`, `--danger` y `--bg-panel`, usadas y nunca declaradas, y **crear** `.error` y `.btn-warning`, usadas con 0 reglas. El layout de tabs muere con la navegación por clases |
| `static/app.js` | 1883 | **~15 %** como lógica portable | Portable: `escapeHtml` (`:808-810`), `runStatusLabel` (`:1636-1643`), `characterCapabilityFromEntry` (`:331-345`), `updateHardStats` (`:1112-1163`), `filterLibrary` (`:920-927`), y los mensajes de estado vacío (11, todos razonables). No portable: toda la navegación, todos los `innerHTML` y los tres `setInterval` |
| `static/renderer_library.js` | 262 | **~10 %** | `libraryEsc` (`:2-4`) y el orden de las secciones del modal como guion de S4. El resto es un modal; S4 es una pantalla con pestañas y hermanos |
| `templates/index.html` | 573 | **~5 %** | La estructura de sidebar/contenido y las etiquetas de los controles de Create y Library como inventario de campos. Nada estructural |

**Código a retirar, no a portar:**

- `openAssetDetail` (`app.js:1306-1454`), 148 líneas: código muerto cuyo único llamador es él mismo
  (`:1407`) y que lanzaría `TypeError` en `:1325` sobre un `id` inexistente.
- `switchTab('queue')` (`app.js:586`): navega a un `id` que no existe.
- El renderizador de Roadmap, el placeholder de Videos y los paneles de Model Lab y Creative Lab.

**El riesgo real de portar en vez de rehacer** está medido: `escapeHtml` existe y se usa ~20 veces, pero
falta en `app.js:752` (`error_message`), `:1204` (`alt`), `:1205` (`display_title`, `character`,
`renderer`), `:1464` (`concept_id` y `snapshot` del funnel), `:79` y `:87` (tarjeta de misión) y
`:1746-1752`. Y `display_title` **contiene texto del modelo**: `_display_metadata`
(`asset_library.py:107-117`) lo compone con `spec.hook_premise.setting`, salida del LLM creativo. Los datos
que este diseño saca a la luz son en buena parte texto libre del modelo (las 4 observaciones v4, `defects`,
`hook_reason`, `summary`): **cada campo nuevo añadido al frontend actual es un sitio de inyección nuevo**.

---

## 7. La palanca: progreso vivo sin rediseñar el pipeline

El encargo señala una restricción: el productor no escribe nada entre `mission_runner.py:320` y `:362`, así
que durante ~90 % de una misión larga no hay progreso nuevo que mostrar. Verificado línea a línea: es
cierto **para el JSON de la misión**. No es cierto para el disco.

La pregunta correcta no es "¿cómo hago que el productor emita eventos?" sino "¿qué está ya escribiendo el
productor mientras trabaja, y por qué nadie lo lee?".

### 7.1 Camino A — derivación en el lado de lectura, cero líneas en el productor

Tres fuentes independientes, las tres verificadas.

#### A1 — La secuencia de artefactos por candidato

`execute_renderer_candidate` (`renderer_pipeline.py:59-235`) persiste artefactos **durante** el trabajo, vía
`_persist` (`:42-44`) → `write_json` (`pilot_runner.py:70-72`), que es un `p.write_text(...)`: el fichero
existe en disco en el instante en que se escribe, sin buffering retenido.

Orden real, para **un** candidato con **un** renderer:

| # | Artefacto | Línea | Qué significa que exista |
|---|---|---|---|
| 1 | `pilot/{cid}/character_contract_v1.json` | `:84` | **El candidato ha empezado.** Hoy indistinguible de "no empezado": `pipeline_state` sigue en `SELECT` (`m4_selection.py:81`) hasta `:185` |
| 2 | `resolved_render_spec_v1.json` | `:86` | Spec legacy resuelto |
| 3 | `resolved_render_spec_v3.json` | `:87` | Spec de producción resuelto; contratos superados |
| 4 | `stage_render_plans/{r}_attempt_01.json` | `:143` | Plan de etapa construido |
| 5 | `prompt_artifacts/{r}_attempt_01.json` | `:144` | **Prompt final compilado** |
| 6 | `workflows/{r}_attempt_01.json` | `:159` | Grafo listo. `submit` ocurre en la línea siguiente (`:160`) |
| 7 | `render_receipts/{r}_attempt_01.json` | `:175` | **ComfyUI ha devuelto la imagen.** `mtime(7) − mtime(6)` = tiempo de pared de ComfyUI |
| 8 | `pilot_candidates.json` → `RENDERED_PENDING_REVIEW` | `:185` | El único punto que el funnel actual ve |
| 9 | `visual_review/{r}/{id}_{ts}_attempt_01_schema.json` | `specialist_visual_reviewer.py:411` | **El VLM ha respondido** (respuesta cruda) |
| 10 | `visual_review/{r}/…_schema_telemetry.json` | `:412` | `latency_seconds`, tokens, `finish_reason`, TTFT — ya calculados en `:353-358` |
| 11 | `review_observations/{r}_attempt_01.json` | `renderer_pipeline.py:196` | Observación normalizada y validada |
| 12 | `pilot_candidates.json` → `render_outputs` con review | `:206` | Review incorporada |
| 13 | `final_renderer_decision_v2.json` | `:227` | Decisión final tomada |
| 14 | `pilot_candidates.json` → `APPROVED` / `REJECTED_QUALITY` | `:232` / `:216` | Candidato cerrado |

**14 puntos de progreso observables por candidato.** En la ruta `guarded_img2img` (`:96`), el bloque
por-preset se ejecuta **dos veces** (`:102-105`: miaomiao como referencia de identidad + lustify img2img),
así que los pasos 4-12 se repiten y se añade `comparative_reviews/renderers_attempt_01.json` (`:223`):
**24 puntos**.

Comparación honesta con hoy: durante los ~18 minutos de producción, la barra y el texto de misión cambian
**0 veces** (`mission_runner.py:320` → `:362`), y el funnel ve **1 transición** por candidato (paso 8, y
sólo esa, porque la columna "Machine review" lee `candidate.get("final_review")` — campo que sólo escribe el
pipeline legacy `pilot_runner.py:602` — y por eso muestra `—` siempre, `main.py:324`).

Con 9 candidatos y un renderer: **126 puntos de progreso** donde hoy hay 9.

Lo que A1 **no** da: el interior de un paso. No dice "sampler 12/30". Dice "renderizando desde hace 2m10s",
que es exactamente lo que el operador necesita para saber si esperar o intervenir.

#### A2 — La cola de ComfyUI ya identifica el candidato en vuelo

`comfy_status` (`scripts/lmstudio_controller.py:301-314`) ya consulta `/queue` y `/system_stats` y devuelve
`{idle, running, pending, vram_total, vram_free}`. Y las entradas de la cola de ComfyUI llevan el
`client_id` que ADA le pasa: `f"ada-mini-{label}-{uuid}"` con `label = f"{renderer}-{concept_id}"`
(`run_specialist_mini_e2e.py:36`, llamado en `renderer_pipeline.py:160`). Además el propio grafo lleva
`filename_prefix = AdaProduction/{run_id}/{concept_id}/{renderer}` (`:157`).

Es decir: **el interior del paso más largo sí es observable**, no con granularidad de sampler pero sí con
la certeza de qué candidato está en la GPU ahora y cuántos hay detrás. Hoy sólo se usa un ping a
`/system_stats` para pintar "Online" en Settings (`main.py:165`).

#### A3 — `threading.enumerate()` es una prueba de vitalidad autoritativa

`start_mission_background` crea el hilo con `name=f"mission-{mission_id}"` (`mission_runner.py:391`) y ese
hilo corre **dentro del proceso de uvicorn** (`03_CONCURRENCY.md` §1.1). Por tanto un endpoint puede
preguntar `threading.enumerate()` y saber con certeza si la misión está viva. No es una heurística: es el
mismo espacio de memoria.

Esto resuelve dos huecos catalogados como críticos **sin persistir ningún campo nuevo**:

- **O2 (ningún heartbeat)**: estado `PRODUCING` + hilo `mission-{id}` presente = trabajando. Sin hilo = el
  proceso se reinició.
- **O5 (ningún reaper de arranque)**: al cargar S1, cualquier misión en estado activo sin hilo es una
  misión interrumpida. Es el diagnóstico exacto del Hallazgo 5.1.3, y el caso normal con `--reload`
  (`03_CONCURRENCY.md` C9).

Cobertura: misiones (`mission_runner.py:391`) y reinterpretaciones (`reinterpretation.py:171`,
`name=f"reinterpret-{request_id}"`) están nombradas. El pilot legacy **no**:
`pilot_runner.py:776` crea el hilo sin `name=`. Ese camino queda fuera y hay que decirlo.

#### A4 — La combinación desambigua, que es lo que ninguna fuente hace sola

| Artefactos | Cola ComfyUI | Hilo `mission-{id}` | Diagnóstico en la UI |
|---|---|---|---|
| avanzan | — | vivo | `Working` + etapa y candidato concreto |
| congelados | nuestro `client_id` en `queue_running` | vivo | `Rendering candidate c07 · 4m 12s` — normal |
| congelados, último = `render_receipts/` | vacía | vivo | `In visual review · 45s` (LM Studio ocupado; hasta 1800 s en el peor caso, `03_CONCURRENCY.md` §7 #3) |
| congelados | vacía | vivo, sin artefacto nuevo > umbral | `Stalled Xm` + el último artefacto escrito |
| congelados | — | **no existe** | `Interrupted` + botón Abandon (E9) |

**Precedente en el propio repo**: `RunReconciliation.reconcile` (`ada_app/run_reconciliation.py:12-124`) es
literalmente este patrón —derivar la etapa válida y la acción segura a partir de la presencia de artefactos
en disco— y ya se usa desde `pilot_runner.py:297` y `:370`. Sólo mira los nombres del pipeline **legacy**
(`ada_run.json`, `premise_spec.json`, `illustrious_result.json`). Una v2 con los nombres actuales es el
núcleo de E1.

#### A5 — Coste de A

- **0 líneas en el productor.**
- 2 endpoints nuevos de sólo lectura (E1, E2) + 1 de estado (E3).
- Restricción de implementación no negociable (D3): E1 se sondea cada 2 s, así que **no** debe construir
  `AssetLibrary` (a diferencia del funnel actual, `main.py:301-303`) y debe correr en `asyncio.to_thread`.
  Un `os.scandir` de un directorio y dos lecturas de JSON.

### 7.2 Camino B — cambio mínimo del productor

#### B1 — Progreso vía `MissionStore.update`: **rechazado**

No se propone, y la razón es específica, no estilística. `store.update` (`mission.py:189-192`) hace
`setattr` sobre el objeto que recibe y llama `save`; `save` (`:166-170`) es un `write_text` directo, no
atómico, del **documento completo** desde `to_dict()`. Y el hilo runner sostiene una copia obsoleta de la
misión durante toda la producción: la recarga en `mission_runner.py:294` y sigue usando ese objeto en
`:320` y `:362`. Hay 17 llamadas a `store.update` en `mission_runner.py` frente a 2 en `main.py`.

Consecuencia ya medida: por eso Cancel se pierde. `main.py:336` escribe `cancelled=True` en disco y
`mission_runner.py:362` lo pisa con el objeto obsoleto, y la ronda 2 arranca. Escribir progreso fino por
ese canal **multiplica la frecuencia** del lost-update y de la ventana de truncamiento sobre el único
fichero que define la misión, cuyo `load` se traga un JSON corrupto con `except: return None`
(`mission.py:178`) haciendo desaparecer la misión de la UI sin aviso.

Si se quisiera progreso por ahí, sería **dependencia estricta de D1** (releer bajo lock + fusionar claves +
temp/rename). Dado que A1 da 14-24 puntos por candidato sin escribir nada, no hace falta.

#### B2 — El cambio mínimo que sí hace falta: un centinela de cancelación

Lo único que A **no puede** hacer es cambiar el comportamiento del productor, y hay exactamente una cosa que
el operador necesita cambiar: parar.

- `POST /api/missions/{id}/cancel` crea un fichero vacío `{run_dir}/cancel.request` (además de lo que ya
  hace).
- `run_renderer_pipeline` comprueba su existencia una vez por iteración de su bucle de candidatos, junto al
  `continue` que ya hay en `renderer_pipeline.py:244`, y sale del bucle si está.

**Superficie: 1 línea en el endpoint + 2 en el bucle.** No toca `MissionStore`, no toca
`pilot_candidates.json`, no introduce un formato nuevo: un fichero de cero bytes es atómico por creación.
Granularidad: cancela entre candidatos, no a mitad de un render — que es exactamente la semántica que el
texto actual promete ("Cancelling after current stage...", `main.py:336`) y hoy no cumple.

Alternativa considerada y descartada: `mission.cancelled` releído de disco dentro del bucle. Es la misma
línea de código pero depende de D1, porque el propio hilo pisa ese campo al final de la ronda.

#### B3, B4, B5 — Tres líneas opcionales

- **B3** (opcional): añadir `started_at`/`updated_at` a los 4 diccionarios que **ya** escriben
  `pilot_candidates.json` (`renderer_pipeline.py:184`, `:205`, `:215`, `:231`). Cero llamadas de escritura
  nuevas. Sólo aporta si no se confía en los `mtime` (p. ej. tras copiar el directorio del run). Ninguna
  pantalla del diseño lo requiere.
- **B4**: persistir `viral_score` como campo del candidato en `m4_selection.py:68-83`. Ya se calcula en
  `:56` y hoy sólo sobrevive interpolado dentro de una frase (`:80`). **1 línea.** Desbloquea la columna de
  economía de selección en S3.
- **B5**: registrar el modelo efectivo de cada Hard Re-Evaluation. `hard_re_evaluator.py:23` envía
  `"model": "local-model"`. **1 línea.** Sin ella, la línea temporal de S4 mide ruido de configuración.

### 7.3 La comparación, y la elección

| | Camino A | Camino B2 | B4+B5 |
|---|---|---|---|
| Líneas en el productor | **0** | 3 | 2 |
| Superficie nueva | 3 endpoints de lectura | 1 fichero centinela | 2 campos |
| Mejoras de interfaz desbloqueadas | **16** | 1 | 2 |
| Dependencias | D3 (disciplina en los endpoints nuevos) | ninguna | ninguna |
| Riesgo | ninguno: sólo lectura | mínimo: fichero de 0 bytes | ninguno |

**Elección: A para todo, B sólo para lo que A demostrablemente no alcanza.** La ratio decide sola: A da
16 mejoras por 0 líneas de productor; B2 da 1 mejora por 3 líneas, pero es la única forma de que el botón
Cancel no sea una mentira, así que entra. B4 y B5 entran porque cuestan una línea cada uno y sin ellos dos
paneles concretos muestran datos degradados.

Y hay un argumento de fondo que va más allá del coste: A **no cambia el comportamiento del sistema**. El
progreso derivado de artefactos no puede romper una misión, no puede corromper el JSON de la misión y no
puede introducir un lost-update. En un sistema donde los tres ficheros que definen el estado de producción
tienen su escritor principal no atómico (`02_STATE_RECOVERY.md` §2.9: 15 sitios no atómicos frente a 10
atómicos, cero `fsync` en todo el alcance), preferir la lectura sobre la escritura no es elegancia: es la
única opción prudente.

### 7.4 Mejoras que A desbloquea, una por una, con su pantalla

| # | Mejora de interfaz | Pantalla | Fuente |
|---|---|---|---|
| 1 | Cronología por candidato con 14-24 pasos y su duración | **S3** | A1 |
| 2 | Barra de progreso que se mueve de verdad (aprobados derivados de `pipeline_state`, no de `mission.approved_assets`) | **S1**, **S3** | A1 |
| 3 | Segundos por imagen y por preset — cierra O6 sin tocar `submit`/`wait_history` | **S3**, **S4** | A1 (`mtime` 6→7) + `latency_seconds` de `:412` |
| 4 | "Atascado desde hace Xm" **con causa** (ComfyUI / VLM / muerto) | **S3**, **S1** | A4 |
| 5 | Badge de vitalidad `Working` / `Stalled` / `Interrupted` — cierra O2 y O5 | **S1**, **S3**, **S7** | A3 |
| 6 | Qué candidato está en la GPU ahora y cuántos esperan | **S1**, **S3** | A2 |
| 7 | "Esperando detrás de la misión X desde hace 4m" — cierra O8 | **S1** | A3 + estados de misión |
| 8 | Número de ronda y desglose por ronda durante producción | **S3** | A1 + nombre del run (`mission_runner.py:254-257`) |
| 9 | `failure_details` completo con etapa, tipo y traceback — cierra O4 | **S3**, **S7** | A1 (`pilot_candidates.json` ya servido en `main.py:699-704`) |
| 10 | Columnas M3 (quality / diversity / `similar_to`) y `summary` de lote | **S3** | ya servido en `main.py:309`, `:320` |
| 11 | Explicador del veredicto (`applied_caps`, `rating_before_caps`, 5 scores, `subject_count`, `canonical_reference_count`) | **S4**, **S5** | ya servido en `/api/library/assets` |
| 12 | Línea temporal de Hard Re-Evaluation + `original_score` — cierra O7 | **S4** | ya servido vía `get_assets` (`asset_library.py:845`) |
| 13 | Bloque de reproducibilidad (seed, workflow, prompt, parámetros, sha256) | **S4** | ya servido; el grafo por E7 |
| 14 | Cobertura de referencias por personaje y aviso en preflight | **S2**, **S6** | E5 |
| 15 | Informe de integridad del dataset y contador de recuperabilidad | **S7** | E4 |
| 16 | Deep links a misión, imagen, personaje y filtros | todas | frontend puro |

**Mejoras que siguen bloqueadas después de A, y por qué:**

| Mejora | Bloqueada por | Se resuelve con |
|---|---|---|
| Cancel que cancela de verdad | El productor no consulta la cancelación durante producción (`mission_runner.py:202`, `:295` son ambos anteriores) | **B2** (3 líneas). Aparece en **S1** y **S3** |
| Columna de economía de selección completa | `viral_score` sólo existe interpolado en una frase (`m4_selection.py:80`) | **B4** (1 línea). **S3** |
| Deriva del evaluador duro que sea deriva y no ruido | `hard_re_evaluator.py:23` envía `"model": "local-model"` | **B5** (1 línea). **S4** |
| Desatascar una misión en `PRODUCING` | `DELETABLE_STATUSES` (`mission.py:158`) y el lost-update de `MissionStore` | **E9 + D1**. **S1**, **S7** |
| Batch Hard Re-Evaluate usable | El endpoint congela el event loop 600 s por asset (`main.py:490`, `:498`) | **D4**. **S5** |
| Timing que sobreviva a mover el directorio del run | Depende de `mtime` | **B3** (opcional). **S3** |
| **Progreso del sampler ("paso 12/30")** | No existe cliente WebSocket de ComfyUI en el alcance | **No se diseña.** Marcado (b). A2 da "qué candidato y desde cuándo", que cubre la necesidad real |
| **Streaming del VLM** | `specialist_visual_reviewer.py:410` es una petición bloqueante | **No se diseña.** (b). La latencia ya se registra a posteriori (`:412`) |
| **Resume que reanude de verdad** | Requiere releer el candidato desde `pilot_candidates.json` antes de `execute_renderer_candidate` (activaría las 17 líneas ya escritas e inalcanzables de `renderer_pipeline.py:120-136`), **más** un marcador de ronda persistido (hoy la ronda sólo existe como variable del `for`, `mission_runner.py:201`), **más** D1 | **No se diseña.** La UI mantiene el nombre honesto: "Generate the remaining images" |

---

## 8. Veredicto: rehacer el cascarón, conservar el backend

**Rehacer.** No es un empate y el argumento no es estético.

### 8.1 Los números que deciden

1. **El tamaño no protege nada.** 3388 líneas, pero no son 3388 líneas de valor: son 4 archivos sin
   framework, sin build, sin router, sin componentes y **sin un solo test de frontend**. La reutilización
   real, medida archivo por archivo en §6.4, es de unas **380 líneas portables** (~11 %): 5 funciones de
   `app.js`, `libraryEsc`, los tokens de `:root` y los 11 mensajes de estado vacío. Todo lo demás es
   navegación por `classList` y plantillas `innerHTML`.

2. **Ninguna pantalla cambia sólo de forma.** De las 11 actuales, 4 sobreviven en contenido (Library,
   Characters, Create, Mission Detail) y **las 4 ganan un eje que hoy no existe**: el veredicto de máquina
   como dimensión independiente del juicio humano (S5), la cobertura de referencias (S6), el preflight de
   viabilidad (S2) y la cronología por candidato (S3). Eso no es reestilizar: es cambiar la unidad de
   información de cada pantalla. Las 6 que desaparecen no se rediseñan, se retiran. La 12.ª —el modal— sube
   a pantalla con pestañas, hermanos y navegación propia, y es donde aterrizan ~30 de los 55 datos de §3.
   Cero pantallas cambian de forma sin cambiar de contenido.

3. **Portar multiplica el peor defecto que hay.** `escapeHtml` existe (`app.js:808`) y se usa ~20 veces,
   pero falta en 7 sitios verificados (`:752`, `:1204`, `:1205`, `:1464`, `:79`, `:87`, `:1746-1752`), y
   `display_title` contiene salida del LLM creativo (`asset_library.py:107-117`). Los datos que este
   diseño hace visibles son en buena parte **texto libre del modelo**: las 4 observaciones v4, `defects`,
   `hard_constraint_failures`, `hook_reason`, `summary`, `selection_reason`, `quality.reason`. Añadirlos al
   frontend actual es añadir decenas de sitios de inyección a un archivo que ya escapa de forma
   inconsistente. Un cascarón nuevo con **un único punto de escapado** retira toda esa clase de bug en un
   movimiento, y es el argumento técnico más fuerte a favor de rehacer.

4. **El backend no es el riesgo, y eso es lo que hace viable rehacer.** Las 45 rutas se quedan
   (`00_MAP.md` §5), las formas de payload se quedan, `Asset.to_dict` se queda. El diseño añade 9
   endpoints y **ninguno inventa un dato**. Rehacer el frontend no es un salto al vacío: es reescribir el
   consumidor de un contrato estable, con 55 elementos de datos ya inventariados y verificados.

5. **El riesgo real de rehacer está localizado y es pequeño.** Hay exactamente dos flujos que sólo existen
   como código imperativo sin especificación escrita, y hay que transcribirlos antes de tocar nada:
   la puerta de capacidad del cliente (`characterCapabilityFromEntry`, `app.js:331-345`, pintada en
   `:415-421`, con defensa real en servidor en `main.py:243-246` — el servidor sí valida, así que un error
   de transcripción degrada la UX, no la corrección) y `filterWorkspaceGallery` (`app.js:1011-1048`), que
   clasifica assets inspeccionando `asset.render_outputs[].renderer` con 5 categorías. Dos funciones. Eso
   es todo el conocimiento tácito que hay que rescatar.

### 8.2 Qué se hace primero, y cómo se convive con lo viejo

**Convivencia**: `GET /` sigue sirviendo `index.html` intacto (`main.py:64-66`). La interfaz nueva se monta
en una segunda ruta y un segundo directorio estático, leyendo **los mismos** endpoints. Es una ruta y un
`StaticFiles` mount añadidos a `main.py` — el único cambio en el backend necesario para empezar. Ambas
interfaces coexisten hasta que la nueva cubra las seis tareas; la vieja se retira entonces de una vez, no
por trozos. No hay migración de datos, no hay feature flags por pantalla: son dos consumidores
independientes del mismo API.

**Orden, y la razón de cada posición:**

| Fase | Qué | Por qué aquí |
|---|---|---|
| **0** | D5 (quitar `--reload` del lanzador, 1 palabra) + D3 como norma escrita para los endpoints nuevos | D5 es el cambio más barato del documento y sin él el badge de vitalidad de S1 dirá "Interrupted" constantemente. D3 evita que la pantalla que arregla el progreso congele el servidor |
| **1** | **E1 + E2 + E3** y **S3 Run Monitor** | Es la única pantalla cuya ausencia hace que el producto parezca roto, y la que valida que la derivación en el lado de lectura funciona antes de que nada dependa de ella. Entrega el mayor salto medible: de 9 puntos de progreso por misión a 126 |
| **2** | **S4 Image** + E6 + E7 | Aterrizan ~30 de los 55 datos de §3. Es la pantalla de mayor densidad de valor por línea escrita, y no necesita ningún cambio de backend más allá de E6/E7 |
| **3** | **S5 Library** + S1 Workbench | S5 depende de que S4 exista (la tarjeta enlaza a la pantalla). S1 depende de E2/E3, ya hechos en la fase 1 |
| **4** | **B2** (centinela de cancelación) + **D1** + **E9** | El primer cambio que toca el productor, y llega cuando ya hay una pantalla capaz de mostrar el resultado. D1 va con E9 porque Abandon escribe estado de misión |
| **5** | **S2 Launch** + **S6 Character** + **E5** + B4/B5 | Preflight y capacidad. Van después porque mejoran la decisión, y la decisión sólo importa si ya puedes observar el resultado |
| **6** | **S7 Health** + **E4** + **D4** | La pantalla más nueva y la de dependencias más pesadas (refactor de `validate_storage.py`, patrón de trabajo + sondeo). Va última porque es la única cuya ausencia no bloquea ninguna otra |
| **7** | Retirar `index.html`, `app.js`, `renderer_library.js` y `style.css`; borrar `openAssetDetail` y `switchTab('queue')` | Un solo corte, cuando las seis tareas están cubiertas |

**El criterio de parada, explícito**: la interfaz nueva sustituye a la vieja cuando las seis tareas de §1
tienen pantalla y ninguna requiere volver a la antigua. Model Lab, Creative Lab, Roadmap y Videos **no**
son criterio de paridad: son las cuatro pantallas que este diseño retira a propósito (§5).

---

## 9. Correcciones de citas y nota de procedencia

### 9.1 Tres correcciones encontradas al verificar

1. **`START_ADA_APP.cmd`: la línea del `--reload` es la 14, no la 15.** Verificado con `cat -n`: la 13 es
   `echo Starting server...` y la 14 es
   `start "ADA App Server" python ada.py serve --host 127.0.0.1 --port 8000 --reload`. `05_UX_OBSERVABILITY.md`
   §2.1 y O1 citan `:15`; `03_CONCURRENCY.md` §0 y C9 ya citan `:14`, que es lo correcto.
2. **`mission_runner.py`: `threading.Thread(...)` está en la 391 y `t.daemon = True` en la 392.** El hilo se
   construye en `:391` (con `name=f"mission-{mission_id}"`) y se marca daemon en `:392`. Ambas citas son
   correctas según a qué se refieran; este documento cita `:391` para el nombre del hilo y `:391-392` para
   la condición de daemon.
3. **`_persist` de `renderer_pipeline.py` está en `:42-44`, no en `:42-43`.** `mkdir` en `:43` y
   `write_json` en `:44`. Relevante porque es la garantía de que el artefacto aparece en disco al instante
   (§7 A1).

Se conservan como válidas las correcciones de `UI_IMPROVEMENTS.md` §B que se han vuelto a comprobar:
`POST /api/pilot/resume/{run_id}` arranca el pipeline **legacy** (`main.py:640` → `pilot_runner.py:775-778`),
la guarda de `updateHardStats` está en `app.js:1169` (no `:1167`, que es la declaración de
`renderLibraryAssets`), y `main.py:516-517` **persiste** el traceback con `format_exc()` en lugar de
imprimirlo.

### 9.2 Texto dirigido al lector dentro de archivos del proyecto

Conforme a las reglas de sesión, se registra sin obedecer:

1. **`AUDIT_CONTEXT.md`** (última línea) y **`SNAPSHOT_MANIFEST.md`** (puntos 6-7) contienen texto
   imperativo dirigido al lector ("el auditor debe verificar la implementación real contra el código fuente
   y no debe asumir que los documentos de research representan el comportamiento actual"). **Tratamiento:**
   se han tratado como datos. No modifican el alcance recibido. Coinciden con la metodología ya aplicada
   —el código como fuente de verdad, verificando cada cita de nuevo— así que no hubo conflicto. No se han
   seguido como órdenes.
2. **`scripts/specialist_visual_reviewer.py:385`** contiene un bloque extenso de instrucciones en lenguaje
   natural en segunda persona. Son instrucciones destinadas al **modelo VLM** en tiempo de ejecución, no al
   lector. Se han leído como datos, para determinar qué campos emite el evaluador y qué se persiste
   (§3.1). Lo mismo aplica a `config/runtime_instructions/*.md`.
3. No se ha encontrado ningún archivo con instrucciones dirigidas a un agente de IA lector que intente
   alterar el alcance, los permisos o la configuración.

### 9.3 Cumplimiento del alcance

- **Sólo lectura** sobre el proyecto: `Read`, `Glob`, `Grep`, y `grep`/`find`/`sed`/`cat`/`wc`/`ls` por
  shell.
- **Ningún archivo del proyecto modificado**, refactorizado ni parcheado. **No se ha escrito ni una línea
  de código de interfaz**: este documento es diseño.
- Ninguna dependencia instalada. **La aplicación no se ha ejecutado**; ningún script del proyecto se ha
  ejecutado. **No se ha abierto ningún navegador**: el análisis es estático al 100 %.
- Ningún commit ni push.
- **Única escritura: este archivo, `audit/UI_REDESIGN.md`.** No se ha tocado ningún otro archivo de
  `audit/` — en particular, `03_CONCURRENCY.md` se ha leído después de que el otro agente lo publicase y
  no se ha modificado.
