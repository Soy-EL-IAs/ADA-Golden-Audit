# FIXES — Lista ordenada de cambios concretos

Documento de **plan**. Nada de lo que sigue está implementado. Auditoría de solo lectura sobre
`C:\Users\elias.bojko\Documents\Test Laboratory IA\ADA-Golden-Audit`.

Autoridad: **el código**. Cada item cita `archivo:línea` verificado en este clon.
Fuentes: `audit/01_MISSION_LIFECYCLE.md`, `audit/02_STATE_RECOVERY.md`, `audit/03_CONCURRENCY.md`,
`audit/04_AI_AGENTS.md`.

**Clasificación aplicada con rigor:**

- **A — pérdida de datos:** el fallo destruye o corrompe datos ya persistidos, o los vuelve irrecuperables.
- **B — trabajo perdido:** el fallo pierde trabajo en vuelo (GPU, una ronda, una misión) pero no corrompe lo guardado.
- **C — el resto.**

Cuando un item cae entre dos bloques va en el más grave y la razón está en una línea marcada
`Clasificación:`.

**No incluido aquí:** los items de interfaz (van en `audit/UI_IMPROVEMENTS.md`), incluido el escapado de
`ada_app/static/app.js:1464`. Sí están incluidos los bugs de backend que se manifiestan en la UI (C1, C2).

## Correcciones de cita respecto a los informes de fase

| Afirmación en informes | Línea real verificada |
|---|---|
| `--reload` en `START_ADA_APP.cmd:15` (01 §4, 01 §13 #21, 05) | **`START_ADA_APP.cmd:14`** |
| `vram_release.timeout_seconds` en `config/orchestration.json:83` (03 §4.3, §6 C3, §7) | **`config/orchestration.json:80`** |
| `comfy_min_free_ratio` en `config/orchestration.json:85` (03 §4.3) | **`config/orchestration.json:82`** |
| rol `visual_review_worker` en `orchestration.json:74-81` (04 §1.5) / `:65-71` (03 §3.1) | **`config/orchestration.json:69-77`** |

En todo este documento se usan las líneas reales.

---

# BLOQUE A — PÉRDIDA DE DATOS

Los items **A1 a A5 están encadenados y su orden es obligatorio**: el motivo está en cada entrada.
A partir de A6 el orden es por severidad.

---

## A1 — Backup rotatorio de `asset_review.json` antes de cualquier otro cambio

**Archivo que se toca:** `ada_app/asset_library.py:286-289` (constructor de `AssetLibrary`), con la ruta
`REVIEW_PATH` definida en `ada_app/asset_library.py:14-17`.

**Qué cambia.** Antes de la primera escritura de la sesión, copiar `data/library/asset_review.json` a
`data/library/asset_review.backups/asset_review-<UTC-ISO-compacto>.json` con `shutil.copy2`, manteniendo
las N últimas copias (N = 20 es suficiente; es un JSON pequeño). El punto de enganche correcto **no** es
`__init__` (se construye ~10 veces por página, `ada_app/main.py:303, 392, 397, 402, 422, 435, 466, 480, 533, 567`):
es un helper `_backup_reviews_once()` invocado al entrar en los tres escritores —
`save_review` (`asset_library.py:414`), `set_library_status` (`asset_library.py:432`) y
`save_hard_rating` (`asset_library.py:447`) — con un flag de módulo para no repetirlo por proceso.
La copia debe hacerse **sobre el fichero en disco, no sobre `self.reviews`**: si el fichero ya está
corrupto, el backup debe contener los bytes corruptos, que son la única evidencia recuperable a mano.

**Qué se rompe si sale mal.** (a) Si el backup se engancha en `__init__`, cada carga de la Library escribe
un fichero nuevo y el directorio crece sin control. (b) Si la copia se hace desde `self.reviews` en lugar
de desde el fichero, el backup ya está vaciado por el `except` de `asset_library.py:307-308` y es inútil —
exactamente el fallo que este item existe para cubrir. (c) Si el `copy2` lanza (disco lleno, permisos) y no
está en un `try`, deja de funcionar `POST /api/library/review/{id}`: el backup debe degradar a warning, no
bloquear la escritura.

**Cómo verificar que funcionó.** Con la aplicación parada: puntuar una imagen desde la UI y comprobar que
aparece **un** fichero en `data/library/asset_review.backups/` cuyo contenido es byte a byte idéntico al
`asset_review.json` **anterior** a la puntuación (`fc /b` en Windows). Repetir la puntuación en la misma
sesión del servidor: no debe crearse un segundo backup. Reiniciar y puntuar: sí debe crearse el segundo.
Después truncar a mano una copia de `asset_review.json` a la mitad, arrancar y puntuar: el backup debe
contener el JSON truncado.

**Depende de.** Nada. Es el primer paso porque A2 y A3 modifican el camino de lectura y escritura de este
fichero, y hasta que exista una copia cualquier error durante esos cambios es irreversible.

---

## A2 — `_load_reviews` debe fallar ruidosamente en vez de devolver `{}`

**Archivo que se toca:** `ada_app/asset_library.py:294-308`, concretamente el `except Exception: return {}`
de `:307-308`.

**Qué cambia.** Distinguir tres casos que hoy colapsan en uno:

1. Fichero ausente (`asset_library.py:292-293`): sigue devolviendo `{}`. Es el caso legítimo.
2. Fichero presente pero **ilegible o no parseable**: renombrar el fichero a
   `asset_review.json.corrupt-<UTC>` y **lanzar** (`RuntimeError` con la ruta y el error original de
   `json.load`). Nunca devolver `{}`.
3. Fichero presente y parseable pero no `dict` (`asset_library.py:297-298`): mismo tratamiento que 2.

Los llamadores hay que ajustarlos: `AssetLibrary.__init__` (`asset_library.py:288`) propagará la excepción,
así que los endpoints que construyen `AssetLibrary()` devolverán 500. Eso es lo correcto y es el objetivo:
hoy devuelven 200 con la Library vacía. Añadir en `ada_app/main.py` un manejo explícito en el endpoint de
Library (`main.py:390-393`) que devuelva `503` con `{"error": "asset_review_corrupt", "backup_path": ...}`
en lugar de un 500 anónimo.

**Qué se rompe si sale mal.** Si el `except` se elimina sin el renombrado del caso 2, cada carga de la
Library reintenta el parseo y falla igual: la aplicación queda inservible hasta que alguien borre el
fichero a mano, y borrarlo es exactamente la pérdida que se quiere evitar. Si el renombrado se hace sin
comprobar antes que el destino no existe, dos arranques consecutivos pueden sobrescribir el primer
`.corrupt`. Y si se lanza dentro de `save_review` sin haber corrido A1, la corrupción queda detectada pero
sin copia.

**Cómo verificar que funcionó.** Copiar `asset_review.json` a un lado, truncarlo a la mitad de un objeto
(`{"a": {"stat`), arrancar el servidor y abrir la Library. Debe observarse: (1) un error visible con la
ruta del fichero, no una galería vacía con HTTP 200; (2) un fichero `asset_review.json.corrupt-<UTC>` en
`data/library/`; (3) que una `POST /api/library/review/{id}` posterior **no** escribe un
`asset_review.json` nuevo con una sola entrada. Test unitario que debe afirmar:
`AssetLibrary()` lanza cuando `REVIEW_PATH` contiene bytes no-JSON, y **no** lanza cuando el fichero no
existe.

**Depende de.** A1. Va **antes** de A3 por criterio explícito del usuario: si se arregla primero el
escritor (A3) y se deja el `except`, un `asset_review.json` ya corrupto sigue convirtiéndose en `{}` en la
siguiente carga y la primera review lo persiste con esa forma. Arreglando el lector primero, la corrupción
se **detecta** y el backup de A1 sirve para algo.

---

## A3 — `save_review`: escritura atómica + `_REVIEWS_LOCK`

**Archivo que se toca:** `ada_app/asset_library.py:414-417`. Referencia del patrón correcto ya presente en
el mismo fichero: `set_library_status` (`asset_library.py:438-440`) y `save_hard_rating` (`:462-464`).

**Qué cambia.** Sustituir

```python
with open(REVIEW_PATH, "w", encoding="utf-8") as f:
    json.dump(self.reviews, f, indent=2)
```

por el mismo patrón que las otras dos rutas: temporal + `Path.replace`, **dentro de** `with _REVIEWS_LOCK:`
(`asset_library.py:25`). `save_review` es hoy el único de los tres escritores de `asset_review.json` que no
toma el lock (`asset_library.py:318-417`) y el único no atómico. El nombre del temporal debe ser único —
ver A14; si A14 aún no está aplicado, usar `REVIEW_PATH.with_suffix(f".json.{os.getpid()}.tmp")` aquí y
alinear después.

Mover también el bloque de escritura de los ficheros de evento (`asset_library.py:377-382` y `:404-409`,
ambos `open("x")`) **después** de la persistencia de `asset_review.json`, o hacerlos parte de la misma
sección crítica. Hoy el evento durable se escribe en `:380-382` y la review en `:415`: un fallo en medio
deja el evento en disco y la decisión humana perdida (02 §H2).

**Qué se rompe si sale mal.** (a) Si el `with _REVIEWS_LOCK` engloba las llamadas a `validate_contract`
(`asset_library.py:376`, `:401`) y estas lanzan, el lock se libera pero puede quedar el fichero de evento
escrito sin review: hay que mantener la validación **fuera** del lock. (b) `_REVIEWS_LOCK` es un
`threading.Lock` intra-proceso (`asset_library.py:25`): no protege contra el segundo proceso uvicorn que
existe durante un reload (`START_ADA_APP.cmd:14`). Este fix reduce la ventana, no la cierra; cerrarla
requiere B4. (c) Si se reordena la escritura del evento sin cuidado, el `open("x")` puede colisionar en
el mismo microsegundo y lanzar `FileExistsError` donde antes no lo hacía.

**Cómo verificar que funcionó.** Test que debe afirmar: durante `save_review`, en el instante posterior a
la escritura del temporal y anterior al `replace`, el contenido de `REVIEW_PATH` sigue siendo el previo
íntegro (se puede afirmar interceptando `Path.replace` con un `monkeypatch` que lea `REVIEW_PATH` y
compruebe el JSON anterior). Segunda aserción: lanzar 20 hilos que llamen `save_review` sobre 20
`asset_id` distintos y comprobar que el `asset_review.json` final contiene las **20** entradas — hoy con
`open(..., "w")` sin lock se pierden entradas. Comprobación manual: `dir data\library\asset_review.json*`
no debe dejar ningún `.tmp` residual tras 50 reviews.

**Depende de.** A1, A2. Después de A2 la corrupción se detecta; A3 impide producirla.

---

## A4 — Referencias canónicas vacías: la review debe FALLAR, no puntuar igual

**Archivos que se tocan:**
- `ada_app/pilot_runner.py:461-465` — llama `review_stage_image` **sin** `character_contract`.
- `ada_app/pilot_runner.py:589-593` — idem.
- `scripts/run_full_pipeline.py:155-158` y `:276` — idem.
- `scripts/specialist_visual_reviewer.py:40-57` (`canonical_reference_paths`, devuelve `[]` sin manifest),
  `:379` (`references = canonical_reference_paths(...)`), `:201` (`canonical_reference_count`),
  `:424` y `:468` (`reference_count=len(references)`).

**Qué cambia.** Dos cambios, ambos necesarios:

1. **Pasar el contrato.** En los cuatro call sites, pasar `character_contract=<contrato del personaje>`
   igual que hace el único camino correcto, `ada_app/renderer_pipeline.py:191`. El manifest solo se
   resuelve desde `character_contract` (`specialist_visual_reviewer.py:46-52`) o desde
   `semantic_spec["character_refs_manifest"]` (`:55`), y esa segunda vía es **inalcanzable** porque
   `schemas/resolved_render_spec_v3.schema.json` tiene `additionalProperties: false` y no declara esa
   clave. Sin el contrato, `references == []` siempre.
2. **Cerrar la puerta.** En `review_stage_image`, después de `:379`, si `len(references) == 0` y
   `premise_spec` describe un personaje registrado, **lanzar** `VisualReviewSetupError` en vez de
   continuar. Motivo: el propio prompt afirma en `:385` que las referencias canónicas son la autoridad de
   identidad, y con cero referencias el modelo puntúa identidad (0.30 del rating,
   `specialist_visual_reviewer.py:153-156` y `:195-198`) contra los tags de texto que salen del **mismo**
   spec del que se compiló el prompt de generación. Es identidad 100 % contaminada presentada como
   verificada. Alternativa aceptable si se quiere ser menos brusco: forzar
   `identity.result = "UNCERTAIN"` y `applied_caps += [{"reason": "no_canonical_references", "cap": 6.0}]`,
   pero entonces hay que arreglar C7 primero porque `UNCERTAIN` cae hoy en el fallback `REJECT`.

Añadir además una aserción de consumo: `canonical_reference_count` se persiste (`:201`) y hoy **ningún
consumidor lo comprueba** — la única aserción `> 0` del repo vive en
`tests/test_character_reference_manifest.py:141`.

**Qué se rompe si sale mal.** Si se activa la puerta del punto 2 antes del punto 1, **todo** el camino de
`pilot_runner.py` y `run_full_pipeline.py` empieza a lanzar en la etapa de review: dejan de funcionar
`POST /api/pilot/generate` y `/api/pilot/resume`. Si se pasa un `character_contract` construido con una
forma distinta a la que espera `canonical_reference_paths` (`:46-52`), el manifest no resuelve y el efecto
es el mismo `[]` de hoy pero ahora fatal. Y si la puerta se aplica también a stock, ojo: `:379` usa
`limit=1 if is_stock else 2` — stock debe seguir aceptando 1 referencia, no exigir 2.

**Cómo verificar que funcionó.** Ejecutar una misión scene de 1 imagen y abrir
`data/runs/missions/<run>/pilot/<cid>/visual_review/<renderer>/` : el artefacto de review debe traer
`canonical_reference_count >= 1`. Después renombrar temporalmente el manifest de referencias del personaje
y repetir: la review debe **fallar** con un error que nombre las referencias, no producir un
`identity: PASS`. Test que debe afirmar: `review_stage_image` con `character_contract=None` sobre un
personaje registrado lanza; y que `pilot_runner` y `run_full_pipeline` pasan `character_contract` no vacío
(aserción sobre los kwargs con `monkeypatch` de `review_stage_image`).

**Depende de.** Nada técnicamente. **Subido a Bloque A y colocado en cuarto lugar por decisión del
usuario:** sin esto el `scoring_version` de A5 estampa dos etiquetas sobre **tres** poblaciones (asset
contaminado sin referencias / contaminado con referencias / limpio). Arreglarlo antes hace que el sello de
A5 signifique una sola cosa coherente.

---

## A5 — `scoring_version` en `asset_review.json` y filtrado por versión en toda comparación

**Archivos que se tocan:** `ada_app/asset_library.py:311-316` (`_default_review`), `:414` (`save_review`),
`:444-466` (`save_hard_rating`), `ada_app/main.py:508-509` (cálculo de `original_score` y `delta`),
y los consumidores de historial `ada_app/asset_library.py:883` y `:889`.

**Qué cambia.**

1. Añadir a cada entrada de review una clave `scoring_version` (string) y a cada elemento de
   `hard_rating_history` la misma clave. Valor actual sugerido: `"grounded_v4_2026-08"`.
2. **Migración de una sola pasada** que recorra el `asset_review.json` existente y estampe en cada entrada
   sin la clave el valor `"grounded_v4_pre_reference_gate"`. Debe ser un script separado en `scripts/`,
   idempotente (si la clave existe, no la toca), que escriba con el patrón atómico de A3 y que exija que
   exista un backup de A1 antes de correr.
3. Hacer que toda comparación filtre o etiquete por versión. Concretamente `main.py:508-509`
   (`hard_data["delta"] = hard_data.get("final_score", 0) - orig`) hoy resta un score nuevo contra un
   `agent_rating` (`main.py:505-506`) medido con la regla vieja. Si las versiones difieren, `delta` debe
   ser `None` y llevar `delta_unavailable_reason: "scoring_version_mismatch"`.

**Motivo y ventana de tiempo.** Al quitar la contaminación de A4 los scores bajarán en toda la Library
porque desaparece el sesgo, no porque las imágenes empeoren. Sin marcar cuáles se midieron con la regla
vieja, la distinción es **irrecuperable**. Es el único item de este documento con ventana temporal: cada
review escrita después de A4 y antes de A5 es indistinguible.

**Qué se rompe si sale mal.** (a) La migración reescribe **todos** los `asset_review.json`: si el escritor
no es el atómico de A3, un fallo a mitad destruye el fichero completo — de ahí que A5 vaya después de A2 y
A3. (b) Si la migración no es idempotente y se ejecuta dos veces, puede sobrescribir versiones nuevas con
la etiqueta antigua. (c) Si `delta` pasa a `None` sin ajustar el consumidor de UI, la tarjeta de Hard
Re-Evaluation puede renderizar `NaN`; hay que devolver la razón y que el frontend la muestre (eso va en
`UI_IMPROVEMENTS.md`, pero el backend debe emitir el campo). (d) Si se estampa la versión **antes** de A4,
el sello miente: assets sin referencias y con referencias quedan bajo la misma etiqueta.

**Cómo verificar que funcionó.** Antes de migrar, guardar el conteo de entradas de `asset_review.json`
(`python -c "import json;print(len(json.load(open(r'data\library\asset_review.json'))))"`). Después de
migrar: mismo conteo, y **cero** entradas sin `scoring_version`. Ejecutar la migración una segunda vez:
diff del fichero vacío. Después de A4, lanzar un `hard-reevaluate` sobre un asset antiguo y comprobar que
la respuesta trae `delta: null` con `delta_unavailable_reason`. Test que debe afirmar: dos entradas con
`scoring_version` distinto nunca producen un `delta` numérico.

**Depende de.** A1, A2, A3 (el escritor debe estar arreglado antes de reescribir todo el fichero) y A4
(la semántica debe estar estable antes de sellarla). **Va último de este grupo por eso.**

---

## A6 — `MissionStore`: relectura bajo lock, merge de claves recibidas, escritura atómica, y dejar de tragarse la corrupción

**Archivos que se tocan:** `ada_app/mission.py:166-170` (`save`), `:172-178` (`load`), `:180-187`
(`list_all`), `:189-192` (`update`).

**Qué cambia.** Un solo fix con cuatro partes:

1. **`update` deja de volcar el documento completo desde memoria.** Hoy hace `setattr` + `save()`
   (`mission.py:189-192`), es decir *whole-document overwrite* desde una copia potencialmente obsoleta.
   Cambiar a: adquirir un `filelock` por misión (`LOCKS_ROOT / f"mission-{mission_id}.lock"`, `timeout`
   corto de 10 s), **releer** el JSON de disco, aplicar **solo** las claves recibidas en `**kwargs`,
   escribir temporal + `os.replace`. El objeto en memoria se actualiza desde el resultado.
2. **`save` pasa a temporal + `os.replace`** con nombre de temporal único (ver A14).
3. **`load` deja de devolver `None` ante corrupción** (`mission.py:178`, `except: return None`): debe
   distinguir "no existe" (devuelve `None`) de "no parsea" (renombra a `<id>.json.corrupt-<UTC>` y lanza).
4. **`list_all` deja de hacer `except: continue`** (`mission.py:186`): la misión ilegible debe aparecer en
   la lista con `status="CORRUPT"` sintético, no desaparecer.

Hay **19 call sites** de `save`/`update`: 17 en `ada_app/mission_runner.py`
(`:185, 188, 192, 203, 212, 249, 266, 276, 291, 296, 320, 362, 382, 387` y los de stock `:95, 132, 169`)
contra 2 en `ada_app/main.py` (`:336` cancel, `:352` resume). El merge por claves los arregla todos de
golpe: es lo que hace que la cancelación de `main.py:336` deje de perderse (01 §2.3).

**Qué se rompe si sale mal.** (a) Un `filelock` por misión con `timeout` largo dentro del hilo de misión
puede serializar accidentalmente el bucle de rondas contra un endpoint lento: el timeout debe ser corto y
el fallo de adquisición debe degradar a warning, nunca tumbar la misión. (b) El merge por claves cambia la
semántica: hoy `store.update(mission, status=...)` publica también los contadores que el hilo tenga en
memoria. Si el merge solo escribe `status`, los contadores acumulados en memoria (`mission.approved_assets`
en `mission_runner.py:353`) dejan de persistirse salvo que se pasen explícitamente como kwargs. **Hay que
auditar los 19 call sites y añadir los kwargs que hoy viajaban de gorra** — este es el riesgo real del
item. (c) Si `load` empieza a lanzar y `GET /api/missions/{id}` (`main.py:289-290`) no lo captura, un
JSON corrupto devuelve 500 en vez de 404: hay que mapearlo a un 409 con la ruta del `.corrupt`.

**Cómo verificar que funcionó.** Prueba manual de la cancelación, que es el síntoma observable: crear una
misión, esperar a que entre en `PRODUCING`, llamar `POST /api/missions/{id}/cancel`, y comprobar que
`data/missions/<id>.json` mantiene `"cancelled": true` después del siguiente `store.update` del hilo (hoy
`mission_runner.py:291` lo borra). Test que debe afirmar: dos `MissionStore()` distintos, el primero llama
`update(m, cancelled=True)` y el segundo `update(m2, status="PRODUCING")` sobre un objeto cargado **antes**
del primer update — el fichero final debe tener `cancelled=True` **y** `status="PRODUCING"`. Segundo test:
`load` sobre un fichero de 3 bytes lanza y deja un `.corrupt`; `list_all` devuelve la misión con
`status="CORRUPT"` en vez de omitirla.

**Depende de.** Nada. Cubre además la parte de "cancelación perdida" de B5.

---

## A7 — `pilot_candidates.json` y `manifest.json`: escritor atómico y dejar de descartar el run en silencio

**Archivos que se tocan:** `ada_app/pilot_runner.py:70-72` (`write_json`), `ada_app/main.py:50-53`
(`write_json`), `ada_app/asset_library.py:695-698` (el `except: continue` que oculta el daño),
`scripts/run_index.py:58-66`, `ada_app/mission_runner.py:378-381`.

**Qué cambia.**

1. `pilot_runner.write_json` (`:70-72`) escribe con `p.write_text(...)` directo sobre el fichero final.
   Es el escritor de `pilot_candidates.json`, y `ada_app/renderer_pipeline.py` lo llama **5 veces por
   candidato** (`:56, 185, 206, 216, 232`), más `mission_runner.py:117` y `:316`, más
   `pilot_runner.update_candidate_state` (`:187-195`). Cambiar a temporal único + `os.replace`.
2. Igual en `main.write_json` (`ada_app/main.py:50-53`), que escribe el mismo fichero desde
   `main.py:657` y `:693`.
3. `_build_index_unlocked` descarta el run entero con `except: continue` cuando
   `pilot_candidates.json` no parsea (`asset_library.py:695-698`). Cambiar a: registrar el run como
   `degraded` y **conservar** los assets que ya estuvieran en el `index.json` previo para ese run, en vez
   de eliminarlos. Como mínimo, emitir un error visible en vez de `continue`.
4. Quitar el `except: pass` de `mission_runner.py:378-381`, que hoy oculta el fallo de `build_index`
   completo y reporta la misión `COMPLETE` con la Library sin actualizar.

**Qué se rompe si sale mal.** El punto 3 es el delicado: si al conservar entradas previas no se comprueba
que sus ficheros siguen existiendo, `index.json` acumula registros muertos y la UI muestra imágenes que no
cargan. El punto 4 convierte un fallo hoy invisible en una misión `FAILED`: hay que decidir
deliberadamente si un `build_index` fallido debe tumbar la misión (recomendado: **no** tumbarla, pero
escribir el error en `mission.error_message` y dejar el status en `PARTIAL`, nunca `COMPLETE`). El punto 1
toca un helper usado por muchísimos sitios: un temporal en un volumen distinto haría fallar `os.replace`
con `OSError`; el temporal debe crearse siempre **junto** al destino.

**Cómo verificar que funcionó.** Reproducción manual del daño actual: con una misión completada, truncar
`data/runs/missions/<run>/pilot_candidates.json` a la mitad y abrir la Library — hoy todas las imágenes de
ese run desaparecen sin ningún mensaje. Después del fix debe verse un error identificando el run. Test que
debe afirmar: durante `write_json` de `pilot_candidates.json`, el fichero de destino nunca existe en
estado no-parseable (interceptar `os.replace` y hacer `json.loads` del destino). Segundo test: con un
`pilot_candidates.json` corrupto, `build_index()` **no** reduce el número de entradas de `index.json` a
cero para ese run.

**Depende de.** Nada. A14 alinea el nombre del temporal.

---

## A8 — `_safe_key`: dos `asset_id` distintos escriben el mismo fichero en `records/`

**Archivo que se toca:** `ada_app/managed_assets.py:26-28` (`_safe_key`) y su uso en `:94`.

**Qué cambia.** `_safe_key` sustituye cada secuencia de caracteres fuera de `[a-zA-Z0-9._-]` por un único
`_` y trunca a 180 caracteres. Los `asset_id` derivados son `f"{generation_id}::{renderer}"`
(`asset_library.py:738`) y los de reinterpretación `f"{request_id}::{renderer}"` (`:805`). Por tanto
`X::lustify` y `X_lustify` producen el mismo `records/X_lustify.json` y la instantánea de un asset
**sobrescribe** la de otro (`managed_assets.py:94-97`).

El cambio: el nombre del fichero pasa a ser `f"{_safe_key(asset_id)[:150]}-{sha1(asset_id)[:16]}.json"`,
con el `asset_id` original completo también dentro del JSON para poder auditar. Cualquier función
inyectiva sirve; lo que no sirve es la normalización actual, que es sobreyectiva.

**Qué se rompe si sale mal.** Los `records/*.json` ya escritos con el nombre viejo quedan huérfanos: al
cambiar el esquema de nombres, un `records/` poblado deja de coincidir con lo que busca A9. Hay que
acompañar el cambio con un barrido único que, para cada fichero existente en `LIBRARY_RECORDS_ROOT`, lea
su `asset_id` interno y lo renombre al nombre nuevo, dejando en un log los casos donde **dos** ficheros
reclamen el mismo `asset_id` (esas son las colisiones ya materializadas: una de las dos instantáneas ya se
perdió y hay que anotarlo, no inventarlo). Si el truncamiento a 150 se hace mal, se puede exceder el límite
de ruta de Windows.

**Cómo verificar que funcionó.** Test que debe afirmar: `adopt_library_record` con
`asset_id = "run_c01::lustify"` y luego con `asset_id = "run_c01_lustify"` produce **dos** ficheros
distintos en `LIBRARY_RECORDS_ROOT`, y leer cada uno devuelve el `asset_id` correcto. Comprobación manual
tras el barrido: `dir /b data\library\records | find /c ".json"` debe igualar el número de `asset_id`
únicos presentes en `index.json` más las reinterpretaciones.

**Depende de.** Nada. **Va antes de A9** porque A9 convierte `records/` en fuente de recuperación y no se
puede confiar en una fuente donde dos ids se pisan.

---

## A9 — `build_index` debe LEER `records/` en vez de gatear por la existencia de la ruta de ComfyUI

**Archivos que se tocan:** `ada_app/asset_library.py:731` (el filtro por existencia),
`:732-733` (`continue`), `:787` (`derived = self._save_index(assets)`), `:790-791`.
Fuente durable ya existente y hoy sin lectores: `ada_app/managed_assets.py:93-97`, ruta
`LIBRARY_RECORDS_ROOT` en `scripts/ada_paths.py:56`.

**Qué cambia.** Hoy:

```python
normalized = [output for output in normalized if Path(output["receipt"]["output_asset"]).is_file()]
if not normalized:
    continue
```

La ruta comprobada en `:731` es la del `output/` de **ComfyUI**, porque `pilot_candidates.json` nunca se
reescribe con la ruta gestionada (`managed_assets.py:75` trabaja sobre un `deepcopy`). Y `:787` reemplaza
`index.json` **por completo** con lo encontrado. Consecuencia: limpiar el `output/` de ComfyUI y lanzar
cualquier misión (`mission_runner.py:380` ejecuta `build_index()` incondicionalmente) borra del índice todo
el catálogo histórico, con sus ratings, aprobaciones, favoritos e historial de Hard Re-Evaluation.
`README.md:68` afirma explícitamente lo contrario.

**Este fix no es construir almacenamiento durable: es recablearlo.** `records/` ya es exactamente eso y
está bien hecho: `managed_assets.py:93-97` escribe `<asset_id>.json.tmp` y hace `.replace()` — atómico —
con `storage_provenance` (sha256, bytes, `copy_verified`) y `full_image_path` apuntando **dentro** del
almacenamiento de ADA (`data/library/assets/sha256/`). Solo le falta un lector: el grep de
`LIBRARY_RECORDS_ROOT` en todo el repo devuelve el escritor (`managed_assets.py`) y la constante
(`ada_paths.py:56`), nada más.

El cambio concreto:

1. Antes del bucle de runs (`asset_library.py:688`), cargar todos los `records/*.json` en un dict por
   `asset_id`.
2. Sustituir el filtro de `:731` por: el output existe si su ruta de ComfyUI existe **o** si hay un record
   para su `asset_id` cuyo `full_image_path` existe y cuyo `storage_provenance.sha256` verifica. Para lo
   segundo ya existe `verify_managed_record` (`managed_assets.py:101-107`), que **no tiene ningún llamador
   en el repo**: este es su llamador natural. Verificar el sha256 completo por asset en cada rebuild es
   caro; usar `path.is_file()` + tamaño en el camino normal y el sha256 solo bajo bandera.
3. Cuando el asset se resuelve por `records/`, el registro derivado debe salir del record (que ya tiene la
   ruta gestionada) y no de la re-derivación desde el árbol del run.
4. `:790-791`: unificar en **una** escritura de `index.json` en vez de las dos actuales (`:787` derivados,
   `:791` derivados + explícitos), que dejan una ventana en la que el fichero en disco no contiene ninguna
   reinterpretación.

**Qué se rompe si sale mal.** Este es el fix con más superficie del documento.
(a) Si `records/` contiene instantáneas de assets legítimamente eliminados, el rebuild los **resucita** y
la Library crece con entradas que el operador creía borradas — hay que respetar `explicit_images.json` y el
`library_status` de `asset_review.json` al reintroducirlos.
(b) Si se confía en `records/` sin A8, dos assets colisionados devuelven la instantánea equivocada y el
índice queda con metadatos cruzados: peor que el estado actual.
(c) La verificación sha256 completa en el rebuild puede añadir minutos con la GPU parada, porque
`build_index` corre **dentro** de la sección crítica del lock de GPU (`mission_runner.py:380` está dentro
del `with` de `:186`).
(d) `adopt_library_record` lanza `FileNotFoundError` (`managed_assets.py:56-57`) dentro de una comprensión
de lista (`asset_library.py:515`): un solo asset huérfano aborta `build_index` completo. Al cambiar la
puerta de existencia hay que envolver la adopción por asset y saltar el fallido, no el índice entero.

**Cómo verificar que funcionó.** El escenario de daño es reproducible en un minuto: con una Library
poblada, mover `<COMFYUI_ROOT>/output/AdaProduction/` a un lado, llamar `POST /api/library/build_index` y
contar las entradas de `data/library/index.json`. Hoy caen a las de los runs cuyos ficheros sobrevivan
(típicamente cero). Después del fix, el conteo debe ser **igual** al de antes, y cada
`full_image_path` debe apuntar bajo `data/library/assets/sha256/`. Test que debe afirmar: dado un
`records/<id>.json` válido con su blob presente y **sin** el fichero original de ComfyUI,
`build_index()` incluye ese `asset_id` en `index.json`. Test complementario: dado un record cuyo blob **no**
existe, el asset **no** entra.

**Depende de.** A8 (obligatorio). Se apoya en A7 punto 4 para que un fallo de `build_index` deje de ser
invisible.

---

## A10 — `scripts/validate_storage.py` es read-only en el docstring y dispara el rebuild destructivo

**Archivo que se toca:** `scripts/validate_storage.py:44` (`runtime_assets = AssetLibrary().get_assets()`),
docstring en `:2` ("Read-only structural and data-integrity smoke test for ADA storage").

**Qué cambia.** `get_assets` dispara `build_index()` si el índice está vacío
(`asset_library.py:835-836`), y el constructor puede ejecutar la escritura truncante de `:478-481`.
El resultado es que la herramienta a la que el operador acude para **comprobar** la integridad es la que la
rompe: ejecuta exactamente el rebuild destructivo de A9, en un **proceso distinto** donde
`_INDEX_BUILD_LOCK` (`asset_library.py:26`) no aplica, y con el temporal de nombre fijo de
`managed_assets.py:67` colisionando contra el `build_index` del servidor (03 §6 C8). Y el informe que
imprime (`validate_storage.py:120-141`) describe el estado **posterior a su propia mutación**.

El cambio: sustituir `:44` por una lectura directa de `data/library/index.json` y de
`data/library/records/*.json`, sin construir `AssetLibrary`. Todo lo que el validador necesita
(`asset_id`, `full_image_path`, `storage_provenance.sha256`) está en esos dos ficheros. Corregir el
docstring para que diga qué lee exactamente.

Estas 146 líneas son funcionales y hashean cada blob: **son la herramienta de verificación natural de A3,
A7, A8, A9 y A20**. Por eso este item va aquí y no en el Bloque C: mientras `:44` siga como está, no se
puede usar para verificar nada sin arriesgar el daño que se está verificando.

**Qué se rompe si sale mal.** Si el validador lee `index.json` directo y el índice está legítimamente
vacío (instalación nueva), debe reportar "índice ausente" y salir con un código distinguible, no fallar
con un `FileNotFoundError` que parezca corrupción. Si se cablea a un endpoint sin `asyncio.to_thread`,
hashear todos los blobs bloquea el event loop (mismo patrón que A16).

**Cómo verificar que funcionó.** Con una Library poblada, borrar `data/library/index.json` y ejecutar
`python scripts/validate_storage.py`. Hoy reconstruye el índice (mutación); después del fix debe reportar
"index.json ausente" y **no** debe existir un `index.json` nuevo al terminar. Comprobación adicional:
comparar `dir /s data\library` antes y después de una ejecución completa — ni un byte de diferencia, y
cero ficheros `.tmp`.

**Depende de.** Puede aplicarse en cualquier momento, pero es más útil **después** de A9, porque entonces
lo que valida (`records/` + blobs) es lo que el sistema realmente usa para recuperar.

---

## A11 — Adoptar el blob al aprobar el candidato, y llamar `build_index` también en el camino de excepción

**Archivos que se tocan:** `ada_app/renderer_pipeline.py:228-232` (escritura de `APPROVED`),
`ada_app/mission_runner.py:376-381` (el `build_index` del camino feliz) y `:385-388` (el `except` que lo
salta), `ada_app/managed_assets.py:48-98` (`adopt_library_record`).

**Qué cambia.** Hoy la adopción — copia con verificación sha256 al almacenamiento de ADA — ocurre **solo**
dentro de `build_index` vía `_save_index` (`asset_library.py:514-517`), disparado al final de la misión
(`mission_runner.py:380`). Entre `renderer_pipeline.py:232` (candidato `APPROVED` en disco) y
`mission_runner.py:380` la imagen existe **únicamente** en el `output/` de ComfyUI. Ese intervalo cubre
todas las rondas restantes: con `max_rounds=2`, la primera imagen aprobada pasa toda la producción
siguiente sin ninguna copia propiedad de ADA. Y en el camino de excepción (`mission_runner.py:385-388`)
`build_index` **no se llama nunca**: los candidatos ya `APPROVED` no se adoptan ni se indexan.

El cambio:

1. En `renderer_pipeline.py`, inmediatamente **antes** de escribir `pipeline_state: "APPROVED"` (`:231`),
   llamar `adopt_library_record` sobre el output seleccionado. La función es idempotente y content-addressed
   (`managed_assets.py:63-65` revalida el destino existente), así que adoptar aquí y de nuevo en
   `build_index` no duplica nada.
2. Persistir en el candidato la ruta gestionada resultante, en un campo **nuevo**
   (`receipt.managed_output_asset`), sin tocar `receipt.output_asset` — ese campo es provenance de ComfyUI
   y hay código que lo usa como clave de identidad (`asset_library.py:718`, `:731`, `:751`).
3. En `mission_runner.py`, mover el `build_index()` a un `finally` que cubra también el camino de
   `:385-388`, o duplicar la llamada en el `except` antes del `store.update(..., "FAILED")`.

**Qué se rompe si sale mal.** (a) `adopt_library_record` lee y hashea el fichero completo: hacerlo por
candidato añade E/S dentro de la sección crítica del lock de GPU. Con imágenes grandes y muchos candidatos
es medible; es un coste aceptable frente a perder la imagen, pero hay que saberlo.
(b) Si se sobrescribe `receipt.output_asset` con la ruta gestionada, se rompe el filtro de
`asset_library.py:731` y la deduplicación por `(renderer, path)` de `:718-720` — de ahí el campo nuevo.
(c) Si el `build_index` del `finally` lanza y no está envuelto, el `except` de `mission_runner.py:385`
puede quedar enmascarado y perderse el `error_message` real.
(d) Adoptar antes de escribir `APPROVED` significa que un fallo de adopción impide la aprobación: hay que
decidir si eso es deseable (lo es: una imagen que no se puede copiar tampoco se puede conservar) y
asegurarse de que el fallo cae en `_record_failure` con un estado distinguible, no en `REVIEW_FAILED`.

**Cómo verificar que funcionó.** Lanzar una misión de `max_rounds=2` y, en cuanto la UI muestre la primera
imagen aprobada de la ronda 1, comprobar que ya existe un blob en
`data/library/assets/sha256/<xx>/<digest>.png` — hoy no existe hasta el final de la misión. Segunda
prueba: provocar una excepción en la ronda 2 (por ejemplo parando ComfyUI) y comprobar que la misión queda
`FAILED` **pero** la imagen de la ronda 1 aparece en `index.json`. Test que debe afirmar: tras
`execute_renderer_candidate` con verdict PASS, existe un fichero bajo `LIBRARY_ASSETS_ROOT` cuyo sha256
coincide con el del original.

**Depende de.** A7 punto 4 (para que el fallo de `build_index` sea visible). Se complementa con A9: A11
garantiza que el blob existe, A9 garantiza que el índice lo encuentra.

---

## A12 — El `finally` de la revisión visual convierte un PASS real en `REVIEW_FAILED`

**Archivos que se tocan:** `ada_app/renderer_pipeline.py:189-194` (el `try/finally`),
`ada_app/renderer_pipeline.py:47-56` (`_record_failure`, con la rama `:51-52`),
`scripts/lmstudio_controller.py:260-269` (`wait_for_vram_release`),
`config/orchestration.json:79-82` (`vram_release`).

**Clasificación:** cae entre A y B. Va en **A** porque el registro durable resultante es una **mentira**:
`_record_failure` sobrescribe el `pipeline_state` ya persistido (`RENDERED_PENDING_REVIEW`, escrito en
`renderer_pipeline.py:185`) con `REVIEW_FAILED` (`:51-52`), y el veredicto PASS verdadero se descarta antes
de persistirse. El registro falso es después indistinguible de un fallo genuino.

**Qué cambia.** El código actual:

```python
try:
    controller.activate_role("visual_review_worker")   # :190
    review = review_stage_image(...)                    # :191  ← devuelve PASS
finally:
    controller.unload_all()                             # :193
    controller.wait_for_vram_release()                  # :194  ← puede lanzar
```

`wait_for_vram_release` (`lmstudio_controller.py:260-269`) exige que `inventory["loaded"]` esté **vacío**
en `vram_release.timeout_seconds` = 90 s (`config/orchestration.json:80`) y si no lanza `TimeoutError`
(`:268`). Al estar en el `finally`, esa excepción sustituye al camino de éxito. No distingue entre "mis
modelos" y "los modelos de otro flujo", y hay tres invocadores de carga que no toman el lock de GPU (ver
B8), más el `POST /api/creative_expansion` (`main.py:757-765`) que carga bajo demanda.

El cambio: la limpieza de recursos del `finally` **no puede alterar el resultado del trabajo**. Envolver
`:193-194` en su propio `try/except Exception` que registre el fallo de liberación en el candidato
(campo `vram_release_warning`, exactamente como ya hace `reinterpretation.py:143-144`) y no lo propague.
Además, mover el cálculo de `review` fuera del alcance del `finally` no es suficiente: lo que hay que
garantizar es que si `review` ya existe, el flujo continúa a `:195-206`.

**Qué se rompe si sale mal.** Si se silencian **todos** los fallos de liberación, la VRAM puede quedar
ocupada y el siguiente candidato falla en `handoff_comfy_to_lm` (`:188`) por una razón que ahora no se
registra en ningún sitio: de ahí que el warning tenga que quedar **escrito en el candidato**, no solo
impreso. Si se convierte el `TimeoutError` en un `continue` sin persistir la review ya calculada, se pierde
igual. Y ojo: si se cambia `wait_for_vram_release` para tolerar modelos ajenos (por ejemplo comprobando
solo que el propio `_active_signature` se haya descargado), hay que recordar que
`LMStudioController()` se construye por candidato (`renderer_pipeline.py:187`) y `_active_signature` se
reinicia a `None` en cada construcción (`lmstudio_controller.py:60`): esa comprobación **nunca acertaría**.

**Cómo verificar que funcionó.** Reproducción determinista sin concurrencia: bajar
`vram_release.timeout_seconds` a `1` en `config/orchestration.json:80` y lanzar una misión de 1 imagen. Hoy
el candidato acaba en `REVIEW_FAILED` con la misión `FAILED` aunque la review haya pasado; después del fix
debe acabar en `APPROVED` con un `vram_release_warning` en el candidato. Test que debe afirmar:
con `review_stage_image` devolviendo `verdict: "PASS"` y `wait_for_vram_release` lanzando `TimeoutError`,
el `pipeline_state` final del candidato en `pilot_candidates.json` es `APPROVED`.

**Depende de.** Nada. Su severidad la determina B7 (sin `prepare_for_comfy`, el fallo hermano
`wait_for_comfy_vram_release` es **determinista**, no una carrera) y B6 (`continue_on_error=False` lo
escala de un candidato a la ronda entera).

---

## A13 — Los dos escritores de `index.json` que están fuera de `_INDEX_BUILD_LOCK`

**Archivos que se tocan:** `ada_app/asset_library.py:478-481` (purga de entradas legacy dentro de
`_load_index`, llamado desde `__init__` en `:289`) y `ada_app/asset_library.py:825-831`
(`register_reinterpretation`). Lock afectado: `_INDEX_BUILD_LOCK` (`:26`), que solo envuelve `build_index`
(`:676-678`).

**Qué cambia.**

1. **`:478-481`** hace `open(INDEX_PATH, "w")` — escritura truncante directa, sin lock, ejecutada desde
   el constructor, que se invoca en ~10 endpoints (`main.py:303, 392, 397, 402, 422, 435, 466, 480, 533, 567`).
   Dos peticiones concurrentes dejan `index.json` truncado; `_load_index` cae en `:487-488` y la Library
   aparece casi vacía con HTTP 200. El cambio: **sacar la purga del camino de lectura**. `_load_index`
   debe filtrar en memoria y no escribir nunca. La purga persistente pasa a ser una operación explícita
   dentro de `build_index` (bajo el lock) o un script de migración de una pasada.
2. **`:830-831`** ejecuta `self.index = [...]` y `_write_index_records(self.index)` **después** de salir
   del `with _EXPLICIT_IMAGES_LOCK` (`:825-829`) y sin tomar `_INDEX_BUILD_LOCK`. Y lo hace desde
   `self.index`, que es una instantánea del constructor (`:289`): si entre medias un `build_index`
   reconstruyó el índice, esta escritura lo **pierde entero**. El cambio: mover `:830-831` dentro de
   `_INDEX_BUILD_LOCK`, y releer `index.json` de disco justo antes de componer la lista, en vez de usar
   `self.index`.
3. **Elevar `_INDEX_BUILD_LOCK` a `filelock`.** Es un `threading.Lock` intra-proceso: no protege contra el
   subproceso M2 (`mission_runner.py:259`), contra `scripts/validate_storage.py` ni contra el segundo
   proceso uvicorn del reload (`START_ADA_APP.cmd:14`). Un `filelock` sobre
   `LOCKS_ROOT / "library_index.lock"` cierra los tres.

**Qué se rompe si sale mal.** (a) El paso 3 introduce un lock de fichero en el camino de lectura de la
Library: si el `timeout` es largo y una misión está reconstruyendo el índice, `GET /api/library/assets`
se queda esperando. Timeout corto (30 s) y degradación a "índice en reconstrucción, reintente" es lo
correcto. (b) Si se anida el nuevo `filelock` con el `gpu_execution.lock` en distinto orden desde
distintos caminos, hay deadlock: `build_index` se llama **dentro** del lock de GPU
(`mission_runner.py:380`) y desde endpoints que **no** lo tienen (`main.py:436`). El orden debe ser
siempre GPU → índice, nunca al revés. (c) Sacar la purga de `_load_index` significa que un `index.json`
con entradas legacy deja de auto-limpiarse: las entradas seguirán ahí hasta el rebuild o la migración,
y hay que comprobar que `:482-483` no las considera inválidas y degrade a `explicit_images.json`.

**Cómo verificar que funcionó.** Test que debe afirmar: con un `index.json` que contenga una entrada
`concept_snapshot == "Legacy Image Pipeline Result"`, construir `AssetLibrary()` **no** modifica el mtime
del fichero. Segundo test: `register_reinterpretation` llamado sobre una instancia construida **antes** de
un `build_index()` externo produce un `index.json` que contiene tanto los assets derivados nuevos como la
reinterpretación (hoy pierde los derivados). Comprobación manual: lanzar 20
`GET /api/library/assets` concurrentes con `curl` mientras una misión termina, y verificar que
`json.load(index.json)` parsea al final y que el conteo de assets no bajó.

**Depende de.** Nada. A14 es complementario (nombre del temporal); A9 cambia el contenido de lo que estos
escritores publican, así que aplicar A13 antes de A9 reduce el riesgo de A9.

---

## A14 — Los seis escritores "atómicos" comparten nombres de temporal deterministas

**Archivos que se tocan:**

| Escritor | Temporal actual | Línea |
|---|---|---|
| `_write_index_records` | `INDEX_PATH.with_suffix(".json.tmp")` | `ada_app/asset_library.py:510` |
| `set_library_status` | `REVIEW_PATH.with_suffix(".json.tmp")` | `ada_app/asset_library.py:438` |
| `save_hard_rating` | `REVIEW_PATH.with_suffix(".json.tmp")` | `ada_app/asset_library.py:462` |
| `_save_explicit_images` | `EXPLICIT_IMAGES_PATH.with_suffix(".json.tmp")` | `ada_app/asset_library.py:503` |
| `adopt_library_record` (blob) | `destination.with_suffix(suffix + ".tmp")` | `ada_app/managed_assets.py:67` |
| `adopt_library_record` (record) | `record_path.with_suffix(".json.tmp")` | `ada_app/managed_assets.py:95` |
| `_write_record` (reinterpretación) | `path.with_suffix(".json.tmp")` | `ada_app/reinterpretation.py:39` |

**Qué cambia.** Ninguno lleva PID, uuid ni `mkstemp`. Dos procesos que adopten el mismo blob abren el
**mismo** `<sha256>.png.tmp` en modo escritura: uno trunca lo que el otro está copiando, el `_sha256` de
`managed_assets.py:69` no coincide, se hace `unlink` (`:70`) y el otro proceso obtiene `FileNotFoundError`
en el `replace` de `:72`. Como la adopción vive en una comprensión de lista
(`asset_library.py:515`), eso aborta `build_index` **completo**. El escenario no es hipotético:
`scripts/validate_storage.py:44`, `ada.py:28` (`ada.py check`) y el proceso viejo durante un reload
construyen `AssetLibrary` en procesos distintos donde `_INDEX_BUILD_LOCK` no aplica.

El cambio, mecánico en los siete sitios: nombre de temporal único por escritura, con
`tempfile.mkstemp(dir=destino.parent, prefix=destino.name + ".", suffix=".tmp")`, y limpieza del temporal
en el `except` — el patrón ya está bien implementado en el repo, en
`scripts/ada_run_state.py:189-195`. Copiar de ahí.

**Qué se rompe si sale mal.** `mkstemp` devuelve un descriptor abierto: si no se cierra antes del
`os.replace`, en Windows el rename falla con `PermissionError`. Los temporales huérfanos dejan de tener
nombre predecible, así que hay que añadir un barrido (`*.tmp` con mtime > 1 h) o se acumulan sin
posibilidad de limpiarlos a mano — hoy ya se acumulan (01 §13 #15) pero al menos son identificables.
Y `Path.with_suffix` sobre nombres con puntos se comporta de forma distinta a la concatenación: al
sustituirlo hay que comprobar que el temporal cae en el **mismo** directorio que el destino, o `os.replace`
cruza volúmenes y lanza.

**Cómo verificar que funcionó.** Test que debe afirmar: dos llamadas concurrentes a
`adopt_library_record` sobre el mismo fichero fuente desde dos hilos producen el blob correcto y **ninguna**
lanza `RuntimeError("Library copy verification failed")`. Comprobación manual del caso entre procesos:
lanzar `python scripts/validate_storage.py` (después de A10, con la variante que sí construya
`AssetLibrary`, o con `python ada.py check`) mientras una misión termina, y comprobar que `build_index`
completa y que `index.json` contiene los assets de la misión.

**Depende de.** Nada. A3, A7 y A13 deben usar el nuevo helper en lugar de inventar su propio temporal.

---

## A15 — `_REVIEWS_LOCK` da falsa seguridad: relectura obligatoria dentro del lock

**Archivos que se tocan:** `ada_app/asset_library.py:288` (`self.reviews = self._load_reviews()` en el
constructor), `:433` (`updated = dict(self.reviews)` en `set_library_status`) y `:448` (idem en
`save_hard_rating`).

**Qué cambia.** `self.reviews` se lee **una vez por instancia**, en el constructor, **fuera** del lock. Las
tres escrituras reemplazan el fichero **entero** desde esa instantánea. `_REVIEWS_LOCK` (`:25`) serializa
el reemplazo pero no revalida la lectura: es una pérdida de actualización que ocurre **sin ningún crash**.

Escenario exacto y trivial: `POST /api/library/hard-reevaluate` con 20 assets construye **una**
`AssetLibrary` en `main.py:480` y llama `save_hard_rating` una vez por imagen (`main.py:511`) a lo largo de
decenas de minutos (`scripts/hard_re_evaluator.py:41` con `timeout=120`, más la espera del lock de GPU de
`main.py:498` con `timeout=600`). Cualquier `POST /api/library/review/{id}` emitido en ese intervalo queda
borrado por la siguiente escritura del lote.

El cambio: dentro del `with _REVIEWS_LOCK`, releer `REVIEW_PATH` de disco (`self._load_reviews()`) y
aplicar la mutación sobre **eso**, no sobre `self.reviews`. Aplica a los tres escritores: `:414-416`
(después de A3), `:433` y `:448`.

**Qué se rompe si sale mal.** Releer dentro del lock hace que cada escritura pague una lectura del fichero
completo: con miles de entradas es E/S por review, aceptable pero no gratis. Más importante: después de A2,
`_load_reviews` **lanza** ante corrupción. Si esa excepción salta dentro del `with _REVIEWS_LOCK` en medio
de un lote de `hard-reevaluate`, el lote entero aborta; hay que decidir el comportamiento (recomendado:
abortar el lote y devolver el error, que es correcto — no seguir escribiendo sobre un fichero corrupto).

**Cómo verificar que funcionó.** Test que debe afirmar: construir `AssetLibrary` A, luego construir
`AssetLibrary` B y llamar `B.save_review(x, rating=8)`, y después llamar `A.save_hard_rating(y, {...})`.
El `asset_review.json` final debe contener el `rating=8` de `x` **y** el `hard_rating` de `y`. Hoy la
segunda llamada borra la primera. Comprobación manual: lanzar un `hard-reevaluate` de 3 assets y, mientras
corre, puntuar una cuarta imagen desde la UI; al terminar el lote, la puntuación debe seguir ahí.

**Depende de.** A2 (el nuevo `_load_reviews` lanza), A3 (para que los tres escritores compartan patrón).

---

## A16 — `POST /api/library/hard-reevaluate` escribe fallos durables falsos y congela el servidor

**Archivo que se toca:** `ada_app/main.py:472-521`. Puntos concretos: `:473` (`async def`), `:490`
(construcción del `FileLock`), `:498` (`with lock.acquire(timeout=600)` **por asset**), `:511`
(`save_hard_rating` **fuera** de la sección crítica), `:513-519` (el `except` que persiste el fallo).

**Clasificación:** el síntoma más visible es un servidor congelado (que sería B/C), pero va en **A**
porque `main.py:517` llama `lib.save_hard_rating(asset_id, error_data, failed=True)` y eso **escribe en el
único hogar del Human Judgment** (`asset_review.json`, vía `asset_library.py:455-456`) una entrada
`evaluation_failed` permanente en `hard_rating_history` por cada timeout de **contención de lock**. Son
fallos que no son fallos de evaluación, y contaminan de forma irreversible el historial que A5 intenta
hacer comparable.

**Qué cambia.**

1. **Salir del event loop.** `filelock.acquire` bloquea con `time.sleep` en un bucle; en el hilo del event
   loop eso para todo el servidor. Envolver el bucle completo (`:493-519`) en `asyncio.to_thread`, o
   convertir el endpoint en un trabajo en background con un endpoint de estado. El proyecto ya usa
   `asyncio.to_thread` en `main.py:86, 120, 574, 592`: el patrón está disponible y no se aplica aquí.
2. **Un solo turno de lock para todo el lote.** Hoy la sección crítica es por asset (`:498` dentro del
   `for` de `:493`), así que el lock se libera y se vuelve a pedir en cada iteración y una misión se cuela
   en la ventana. Adquirir una vez, fuera del bucle.
3. **No persistir la contención como fallo de evaluación.** Distinguir `filelock.Timeout` del resto en el
   `except` de `:513`: ante contención, **no** llamar `save_hard_rating` y devolver el asset en una lista
   `skipped` con la razón. Solo los fallos reales de `evaluate_image` merecen entrada durable.
4. Mover `save_hard_rating` (`:511`) dentro de la misma unidad de trabajo, o al menos garantizar que se
   ejecuta para el asset cuyo `evaluate_image` acabó de completar.

**Qué se rompe si sale mal.** (a) Con un solo turno de lock para todo el lote, un `hard-reevaluate` de 50
imágenes retiene el `gpu_execution.lock` durante horas y bloquea todas las misiones: hay que acotar el
tamaño del lote en el endpoint (rechazar > N assets con 400) o liberar y reintentar entre grupos.
(b) Al mover el bucle a un hilo, `lib` deja de ser exclusivo del event loop y compite con otros escritores
de `asset_review.json`: A15 es lo que lo hace seguro.
(c) Si se convierte en background sin endpoint de estado, el operador pierde la única señal de que algo
está pasando, que hoy es la congelación.

**Cómo verificar que funcionó.** Reproducción del daño actual: lanzar una misión, esperar a que tenga el
lock, y llamar `POST /api/library/hard-reevaluate` con 3 `asset_ids`. Hoy: `GET /api/system` no responde
durante ~30 minutos y `asset_review.json` acaba con 3 entradas `evaluation_failed`. Después del fix:
`GET /api/system` responde en < 1 s durante toda la operación, y la respuesta del endpoint trae los 3
assets en `skipped` con razón `gpu_lock_timeout`, **sin** entradas nuevas en `hard_rating_history`
(comprobar contando entradas antes y después).

**Depende de.** A15 (el bucle en un hilo necesita la relectura bajo lock). Se apoya en A5 para que las
entradas legítimas queden versionadas.

---

## A17 — Las decisiones humanas de concepto se destruyen con el mismo patrón de reemplazo total

**Archivo que se toca:** `ada_app/main.py:743-750`
(`POST /api/runs/{run_id}/concepts/{concept_id}/review`), con `read_json` en `main.py:43-48` y `write_json`
en `:50-53`.

**Qué cambia.** El endpoint hace `read_json` (que devuelve `{}` ante **cualquier** error, `main.py:47-48`)
→ mutación → `write_json` no atómico, en el event loop y sin ningún lock. Si `human_review.json` se trunca
o dos revisores marcan conceptos a la vez, la siguiente petición persiste un diccionario con **una sola**
decisión: todas las decisiones humanas previas de ese run desaparecen y `main.py:715-722` deja de mostrar
`human_decision`, sin ningún mensaje de error.

El cambio: (1) `read_json` no puede devolver `{}` ante error de parseo cuando el fichero existe — mismo
tratamiento que A2 (renombrar a `.corrupt` y lanzar); (2) escritura atómica con el helper de A14;
(3) `filelock` por `run_dir` alrededor del ciclo leer-mutar-escribir. `ada_app/character_onboarding.py:127-133`
es el único sitio del proyecto donde este patrón está bien hecho: copiar de ahí.

**Qué se rompe si sale mal.** `read_json` es un helper compartido en `ada_app/main.py`: cambiar su
semántica de error afecta a todos sus llamadores (entre ellos `main.py:674` para `m2_config.json`,
`main.py:649` para `pilot_candidates.json`, `main.py:687-688`). Muchos dependen hoy del `{}` silencioso
para el caso "fichero ausente". Hay que separar el helper en dos (`read_json_optional` que devuelve `{}`
solo si el fichero no existe, y `read_json_strict`) o el cambio provoca 500 en endpoints hoy tolerantes.

**Cómo verificar que funcionó.** Marcar 3 conceptos de un run desde la UI, comprobar que
`data/runs/missions/<run>/human_review.json` tiene 3 entradas. Truncar el fichero a la mitad y marcar un
cuarto: hoy el fichero queda con 1 entrada; después del fix debe haber un error visible y un
`human_review.json.corrupt-<UTC>`. Test que debe afirmar: dos llamadas concurrentes al endpoint sobre
concept_ids distintos del mismo run dejan **ambas** decisiones en el fichero.

**Depende de.** A14 (helper de temporal). Comparte el patrón de A2 para el lector.

---

## A18 — `heroes.json`: reemplazo total no atómico de todas las portadas

**Archivo que se toca:** `ada_app/character_capabilities.py:42-47` (`save_character_hero`, `write_text`
directo) y `:38-39` (`load_character_heroes`, que devuelve `{}` ante cualquier error). Lock afectado:
`_HEROES_LOCK` (`:16`), intra-proceso.

**Qué cambia.** Escritura atómica con el helper de A14, relectura de disco **dentro** de `_HEROES_LOCK`
antes de mutar (mismo patrón que A15), y `load_character_heroes` debe distinguir "ausente" de "corrupto"
como en A2.

El daño actual: si el fichero se trunca, `load_character_heroes` devuelve `{}`, y la siguiente misión stock
llega a `mission_runner.py:166` y `save_character_hero` persiste un fichero con **una** entrada. Todas las
portadas elegidas a mano para todos los personajes se pierden. El sistema lo oculta activamente:
`stale_hero` (`character_capabilities.py:174`) y el fallback `library_latest` (`:155-157`) presentan una
portada distinta sin avisar de que la elección humana desapareció.

**Qué se rompe si sale mal.** Si `load_character_heroes` empieza a lanzar, se rompe
`build_character_catalog` (`:139-157`) y con él `GET /api/characters`, que es la pantalla de entrada. Hay
que capturarlo en el endpoint y devolver el catálogo con los fallbacks más una bandera
`heroes_unavailable`, no un 500.

**Cómo verificar que funcionó.** Elegir portadas para 3 personajes, truncar `data/characters/heroes.json`,
y lanzar una misión stock. Hoy el fichero acaba con 1 entrada; después del fix la misión debe registrar un
error de portada y **no** reescribir el fichero desde `{}`. Test que debe afirmar: `save_character_hero`
sobre un `heroes.json` con 3 entradas produce 4, no 1; y que con el fichero corrupto la función lanza en
vez de reemplazarlo.

**Depende de.** A14. Mismo patrón de lector que A2, mismo patrón de lock que A15.

---

## A19 — `m2_config.json`: estado global mutable comiteado en el árbol de código

**Archivos que se tocan:** `ada_app/mission_runner.py:18` (definición de `M2_CONFIG`), `:223-240`
(lectura-mutación-escritura), `ada_app/main.py:672` y `:674-676`
(`POST /api/pilot/generate`, **sin** el lock de GPU), `experimental/m1_creative_expansion_lab/m2_config.json`
(el fichero, comiteado), `experimental/m1_creative_expansion_lab/run_m2.py:271` (el consumidor),
`ada_app/main.py:171` (`GET /api/system` lo lee).

**Clasificación:** va en **A** porque el resultado se persiste como una etiqueta falsa e indetectable: los
conceptos generados con el `character` contaminado van a `pilot_candidates.json` (`main.py:693`) y de ahí a
`index.json` vía `build_index` (`pilot_runner.py:771`) atribuidos al personaje equivocado, y
`m2_config_snapshot.json` (escrito por `run_m2.py:288`) guarda el config **ya contaminado**, de modo que la
evidencia durable confirma la mentira. No hay forma de reconstruir cuál era el parámetro real.

**Qué cambia.** Tres cosas, en este orden:

1. **Sacar el fichero del árbol de código.** `mission_runner.py:18` lo construye a mano como
   `ADA_ROOT / "experimental" / "m1_creative_expansion_lab" / "m2_config.json"`, ignorando
   `EXPERIMENTAL_ROOT` (`scripts/ada_paths.py:67`) y toda la política de `ada_paths`. El estado de runtime
   debe vivir bajo `DATA_ROOT`. El fichero versionado queda como plantilla de valores por defecto,
   **inmutable**.
2. **Dejar de usar un fichero global como canal de parámetros.** `run_m2.py` recibe por CLI únicamente
   `--run-id` (`mission_runner.py:260`, `main.py:681`). Pasar a escribir el config **dentro del `run_dir`**
   (`<run_dir>/m2_config.json`) y pasar su ruta por CLI. Eso elimina de golpe la ventana de contaminación,
   que hoy es de hasta **300 s** porque entre el `write_json` de `:240` y el `load_config` del hijo
   (`run_m2.py:271`) media la carga del modelo de `mission_runner.py:243-246`
   (`POST /api/v1/models/load`, `timeout=300` en `scripts/lmstudio_controller.py:149`).
   El comentario de `mission_runner.py:252-253` demuestra que la concurrencia entre misiones **se
   consideró** para el `run_id`: el problema se resolvió en la salida y no en la entrada.
3. **Eliminar la fuga en serie.** `mission_runner.py:227-230` solo sobrescribe `what_happens` y `where`
   **si la misión los trae no vacíos**, y `:223` parte del fichero existente sin normalizarlo. Con el
   `m2_config.json` tal como está comiteado hoy (`character: "2B"`, `what_happens: "Standing in a
   futuristic city"` en `:59`, `where: "a sunlit stone courtyard beside an adventurers guild"` en `:35`,
   `generation_context.mode: "reinterpretation"` con un `source_asset_id` real en `:28-29`), **toda misión
   sin acción explícita se promptea con el contenido de una ejecución ajena** — incluso ejecutando misiones
   en serie, sin ninguna concurrencia. Y `creation_mode == "stock"` fuerza `what_happens = ""` y
   `where = ""` en el constructor (`main.py:252-253`), así que una misión stock no limpia el config y la
   siguiente scene sin texto lo hereda. El cambio: construir el config **desde cero** a partir de la
   plantilla y de la misión, escribiendo explícitamente `""` cuando la misión no trae valor.

**Qué se rompe si sale mal.** (a) `GET /api/system` (`main.py:171`) lee el fichero global: si se mueve sin
ajustar ese lector, el panel de sistema deja de mostrar el modelo creativo. (b) `POST /api/creative_expansion`
(`main.py:757-765`) lanza `run_m2.py` **sin `--run-id`**: si el config pasa a ser obligatorio por CLI, ese
endpoint rompe. Hay que darle su propio run_id o su propio config. (c) El punto 3 cambia lo que ve el
generador de conceptos: misiones que hoy producen algo (heredando texto) pasarán a producir conceptos sin
acción ni lugar. Eso es lo correcto, pero es un cambio de comportamiento visible y hay que decidir si el
endpoint debe entonces **exigir** `what_happens` en modo scene (hoy no se valida en absoluto,
`main.py:252-253`).

**Cómo verificar que funcionó.** Prueba de la fuga, que no necesita concurrencia: lanzar una misión scene
de un personaje distinto de "2B" **sin** rellenar acción ni lugar, y leer
`data/runs/missions/<run>/m2_config_snapshot.json`. Hoy contiene `"Standing in a futuristic city"` y el
patio de piedra; después del fix debe contener cadenas vacías y el personaje correcto. Prueba de la
contaminación cruzada: lanzar una misión y, mientras está en `GENERATING_CONCEPTS`, pulsar "Generar" en el
panel Pilot; comprobar que el run del pilot tiene su propio `character` y que el `requested_count` de la
misión no cambió (hoy la misión sub-produce sin ningún error). Test que debe afirmar: `_run_mission_internal`
sobre una misión con `what_happens=""` escribe `""` en el config del run, no el valor previo.

**Depende de.** Nada. Cierra también la mitad de escritura sin lock de `main.py:676`.

---

## A20 — Cero `fsync` en todo el alcance: la atomicidad no cubre un corte de energía

**Archivos que se tocan:** los diez escritores atómicos:
`ada_app/asset_library.py:509-512`, `:438-440`, `:462-464`, `:503-505`;
`ada_app/managed_assets.py:67-72`, `:95-97`; `ada_app/character_onboarding.py:236-237`;
`ada_app/reinterpretation.py:40-41`; `scripts/ada_run_state.py:189-195`; `scripts/ada_batch_state.py:55-61`.
Más los que A3, A6, A7, A14, A17 y A18 convierten en atómicos.

**Qué cambia.** Ningún sitio del alcance llama a `os.fsync` (verificado por grep). Todos los escritores
escriben el temporal y hacen `replace` sin forzar el vaciado a disco. Un corte de energía justo después de
`temporary.replace(INDEX_PATH)` (`asset_library.py:512`) puede dejar el `rename` en los metadatos del
volumen mientras el contenido del temporal sigue en la caché de escritura: `index.json` queda con nombre
válido y datos truncados o a ceros. `_load_index` cae en `:487-488` y la Library aparece vacía. El mismo
riesgo aplica al `replace` del blob (`managed_assets.py:72`), cuya verificación sha256 (`:69`) se hizo
**antes** del `replace` y no se vuelve a comprobar nunca.

El cambio: un único helper `write_json_atomic(path, data)` en un módulo compartido que haga
`temporal → write → flush → os.fsync(fd) → close → os.replace`, y que todos los escritores usen. Es el
mismo helper que A14 necesita, así que los dos items son un solo cambio en el código y dos en el plan.

**Qué se rompe si sale mal.** `fsync` por escritura cuesta latencia real. `pilot_candidates.json` se
reescribe **5-6 veces por candidato** (`renderer_pipeline.py:56, 185, 206, 216, 232`): con un disco lento
eso es medible. Es aceptable en este proyecto (los ciclos son de minutos) pero no debe aplicarse
indiscriminadamente a artefactos de telemetría. Y `os.fsync` sobre un descriptor obtenido de `Path.open`
requiere `handle.fileno()`: hay que asegurarse de hacer `flush()` antes o el `fsync` no ve los datos del
buffer de Python.

**Cómo verificar que funcionó.** No es verificable con un corte de energía real de forma razonable. Lo
verificable es la implementación: test que debe afirmar, con `monkeypatch` sobre `os.fsync`, que el helper
lo llama **una** vez con el descriptor del temporal y **antes** de `os.replace` (registrar el orden de
llamadas). Y un grep que debe devolver cero: cualquier `write_text(` o `open(..., "w")` sobre una ruta bajo
`DATA_ROOT` en `ada_app/`.

**Depende de.** A14 (mismo helper). Es el último de A porque es el único cuyo escenario requiere un fallo
de hardware, no de software.

---

# BLOQUE B — TRABAJO PERDIDO

---

## B1 — `filelock` no está declarado en ninguna parte y su `import` está fuera del `try`

**Archivos que se tocan:** `ada_app/mission_runner.py:180` (el `import`, **fuera** del `try` que empieza
en `:184`), `START_ADA_APP.cmd:5` (comprobación de dependencias), la raíz del repo (no existe
`requirements.txt`, `pyproject.toml` ni `setup.py` — verificado).

**Qué cambia.**

1. **Mover `import filelock` dentro del `try` de `mission_runner.py:184`**, o mejor al principio del
   módulo. Hoy, si la librería no está instalada: `main.py:272` guarda la misión (`CREATED`),
   `main.py:274` arranca el hilo, `main.py:276` devuelve `HTTP 200`, y `mission_runner.py:180` lanza
   `ImportError` **antes** del `try`. El hilo muere sin escribir `FAILED`. La misión queda en `CREATED`: no
   reanudable (`main.py:349` solo acepta `PARTIAL`/`FAILED`) y no borrable
   (`mission.py:158`, `DELETABLE_STATUSES`). **Zombi permanente**, y el único rastro es un traceback en la
   consola del servidor. `CADA` misión falla así.
   Contraste: en `ada_app/reinterpretation.py:93` el `import filelock` sí está dentro del `try`, así que
   ese camino degrada a `FAILED` con registro. En `ada_app/main.py:486` está en el cuerpo de una función
   `async`: `ImportError` → HTTP 500, ruidoso.
2. **Crear `requirements.txt`** con los nombres, sin fijar versiones (no hay venv ni lockfile en el clon y
   no se ejecuta `pip` en esta auditoría). Nombres mínimos verificados como importados en el alcance:
   `fastapi`, `uvicorn`, `filelock`, `jsonschema` (usado por `scripts/agent_contracts.py`), `Pillow` si el
   camino de referencias lo usa. Procedimiento para el usuario: crear el venv, `pip install -r
   requirements.txt`, y después `pip freeze > requirements.lock.txt` en su máquina para fijar versiones.
3. **`START_ADA_APP.cmd:5`** comprueba solo `python -c "import fastapi, uvicorn"`. Ampliar a la lista
   completa, y hacer que el mensaje de error de `:7-8` nombre el `requirements.txt`.

**Qué se rompe si sale mal.** Un `import filelock` a nivel de módulo en `mission_runner.py` convierte una
dependencia ausente en un `ImportError` al importar `ada_app.main`, es decir: el servidor no arranca. Eso
es preferible a una misión zombi silenciosa, pero es un cambio de comportamiento (hoy el servidor arranca y
la Library funciona). Si se prefiere degradación, hay que dejar el import donde está y envolverlo, con
`store.update(mission, status="FAILED", error_message="filelock no instalado")`. Y si el
`requirements.txt` lista un paquete que en realidad no se usa, el arranque falla por una dependencia
inexistente: hay que derivar la lista de los `import` reales, no de suposiciones.

**Cómo verificar que funcionó.** En un venv limpio con solo `fastapi` y `uvicorn`: `START_ADA_APP.cmd`
debe fallar en `:5-10` con un mensaje que nombre `filelock`, **antes** de arrancar el servidor. Si se
arranca a mano saltando la comprobación y se crea una misión, debe quedar en `FAILED` con
`error_message` legible en `GET /api/missions/{id}`, nunca en `CREATED`. Test que debe afirmar: con
`sys.modules["filelock"] = None`, `run_mission` escribe `status="FAILED"` en el JSON de la misión.

**Depende de.** Nada. Es el prerrequisito operativo de todo lo demás: sin la dependencia, ninguna misión
llega a ejecutarse.

---

## B2 — `resume` no reanuda: reejecuta desde la ronda 1, y la única rama de recuperación es inalcanzable

**Archivos que se tocan:** `ada_app/main.py:339-355` (el endpoint), `ada_app/mission_runner.py:201` (el
bucle arranca en la ronda 1), `:254-262` (`run_id` nuevo y M2 nuevo),
`ada_app/renderer_pipeline.py:120-136` (la rama de recuperación de renders),
`ada_app/renderer_pipeline.py:238-241` (`run_renderer_pipeline`).

**Qué cambia.** Tres cambios en el mismo camino:

1. **Reutilizar el run anterior.** `resume` llama `start_mission_background`, que reentra en
   `_run_mission_internal`: el bucle arranca en `range(1, mission.max_rounds + 1)` (**ronda 1**,
   `mission_runner.py:201`), se genera un `run_id` nuevo con microsegundos (`:254-257`) y se relanza el
   subproceso M2 completo (`:259-262`), que crea un directorio nuevo con `mkdir(exist_ok=False)`
   (`run_m2.py:276`) y **conceptos nuevos**. No hay ni una lectura de los candidatos del run anterior. La
   misión tiene `mission.source_runs` (`mission_runner.py:285`): el resume debe leer el último run de esa
   lista, cargar su `pilot_candidates.json`, y si contiene candidatos en estados no terminales, pasarlos a
   `run_renderer_pipeline` **antes** de generar conceptos nuevos.
2. **Hacer alcanzable la recuperación de renders.** `renderer_pipeline.py:120-136` reutiliza un
   `render_output` previo si su fichero sigue existiendo (`:123`), pero lo busca en el `candidate` **en
   memoria**. Los dos únicos llamadores de `run_renderer_pipeline` (`mission_runner.py:119` stock y `:331`
   scene, verificado por grep) pasan siempre candidatos recién construidos
   (`mission_runner.py:99-109` y el retorno de `select_top_candidates` en `:303`), **sin `render_outputs`**.
   Las líneas 123-136 nunca se ejecutan en producción: el coste GPU de un reintento es siempre del 100 %.
   El punto 1 las vuelve alcanzables por sí solo. Añadir además el filtro de idempotencia que hoy falta:
   `:244` solo salta `APPROVED` y `FAILED_RUNTIME`; `RENDERED_PENDING_REVIEW` debería reanudarse **desde
   la review**, no desde el render.
3. **Guarda contra doble resume.** `main.py:349` → `:352` → `:354` es un check-then-act de milisegundos y
   el endpoint no comprueba si ya hay un hilo para esa misión. Dos clics rápidos crean dos hilos
   `mission-<mismo_id>` (`mission_runner.py:391`, mismo `name`), ambos con su propio objeto
   `ProductionMission`, ambos escribiendo el mismo JSON y ambos generando `run_id` distintos: **producción
   duplicada en la GPU**, serializada por el lock, con los contadores sobrescritos alternativamente por dos
   objetos divergentes. La guarda: registro de misiones en vuelo (un `filelock` por `mission_id`, o el
   estado `RECOVERING`/`WAITING_FOR_GPU` como candado con timestamp) comprobado dentro de la misma sección
   crítica que el cambio de estado.

**Qué se rompe si sale mal.** (a) Reutilizar el run anterior significa reutilizar su semilla: la semilla es
`sha256(f"{run_dir.name}:{concept_id}:{renderer}")` (`renderer_pipeline.py:145`), así que un reintento en
el mismo `run_dir` produce **los mismos píxeles**. Eso es deseable para la idempotencia (mismo digest →
mismo blob) pero significa que un concepto que falló por calidad volverá a fallar igual: hay que
distinguir "reintentar el render" de "reintentar el concepto".
(b) Si se reanuda un run cuyo `pilot_candidates.json` está corrupto, `pilot_runner.read_json` (`:69`) lanza
sin `try`: hay que capturarlo y caer al comportamiento actual (run nuevo).
(c) `RunReconciliation.reconcile` (`scripts/run_reconciliation.py:12-124`) parece la función para esto y
**no lo es**: solo entiende el pipeline histórico Illustrious/Klein y sobre un run productivo devuelve
siempre `{"last_valid_stage": "CREATED", "next_safe_action": "START_PREMISE"}` (`:25-27`), porque
`ada_run.json` solo lo escribe `AdaRunState` (`scripts/ada_run_state.py:38`), usado exclusivamente desde
`scripts/specialist_orchestrator.py:73`. No apoyarse en ella.
(d) `scripts/launchers/run_recovery.py:10` y `:14` tienen `mission_id` y `run_dir` **literales** de una
misión de agosto de 2026, llaman al pipeline legacy sin tomar el lock de GPU y pueden escribir
`status="COMPLETE"` (`:28-32`). Ejecutarlo apuntando al run equivocado corrompe los contadores de una
misión ajena de forma irreversible. Ese script debe borrarse o parametrizarse en el mismo cambio.

**Cómo verificar que funcionó.** Lanzar una misión de 6 imágenes, dejar que apruebe 2, y matar el proceso.
Reanudar. Hoy: `run_id` nuevo, 6 imágenes nuevas, 8 en la Library, contadores desalineados. Después del
fix: el resume debe reutilizar el `run_id` anterior (comprobable en `mission.source_runs`), no volver a
renderizar las 2 aprobadas (comprobable por el mtime de los PNG en el `output/` de ComfyUI) y producir solo
4. Test que debe afirmar: `run_renderer_pipeline` con un candidato que trae `render_outputs` poblados y su
fichero presente **no** llama a `submit` (monkeypatch con contador).

**Depende de.** A6 (los contadores deben dejar de perderse antes de que reanudar tenga sentido) y B3 (un
resume que solo acepta `PARTIAL`/`FAILED` no puede recuperar los zombis).

---

## B3 — Misiones zombi: la vitalidad ya es derivable del nombre del hilo; nada de heartbeat, nada de reaper

**Archivos que se tocan:** `ada_app/mission_runner.py:390-393` (donde nace el hilo, con nombre),
`ada_app/mission.py:158` (`DELETABLE_STATUSES`), `ada_app/main.py:349` (condición de `resume`),
`ada_app/main.py:279-290` y `:329-337` (los endpoints que exponen el estado),
`ada_app/mission.py:12` (`STATES`).

**El dato que abarata el fix, verificado en este clon:**

- `ada_app/mission_runner.py:391` lanza el hilo con nombre explícito:
  `threading.Thread(target=run_mission, args=(mission_id,), name=f"mission-{mission_id}")`.
- Grep de `threading.enumerate` y de `is_alive` sobre todo el repo (`*.py`): **cero ocurrencias.** Nadie
  consulta hoy la vitalidad de ningún hilo.

Por tanto la pregunta "¿esta misión está realmente viva?" ya es contestable **en proceso y sin persistir
nada nuevo**:

```python
any(t.name == f"mission-{mission_id}" for t in threading.enumerate())
```

Y distingue exactamente los dos casos que importan:

| Hilo | `status` en disco | Interpretación |
|---|---|---|
| presente | `PRODUCING` | corriendo de verdad |
| **ausente** | `PRODUCING` | **zombi** — es seguro permitir `Delete` y `Resume` |

Tras un reinicio del proceso (el `--reload` de `START_ADA_APP.cmd:14`, o un crash) el hilo no existe, así
que el resultado es "muerta", que es la respuesta correcta.

**Qué cambia.**

1. **Un helper de vitalidad** (`ada_app/mission_runner.py`, junto a `start_mission_background`) que
   devuelva si existe un hilo `mission-<id>`. Exponerlo como campo derivado — no persistido — en
   `GET /api/missions` y `GET /api/missions/{id}` (`main.py:279-290`).
2. **Ampliar `DELETABLE_STATUSES`** (`mission.py:158`, hoy solo `{FAILED, COMPLETE, CANCELLED}`) y la
   condición de `resume` (`main.py:349`, hoy solo `("PARTIAL", "FAILED")`) para admitir los cinco estados
   hoy bloqueados — `CREATED`, `WAITING_FOR_GPU`, `RUNNING`, `GENERATING_CONCEPTS`, `PRODUCING` — **cuando
   el hilo está ausente**. Como `DELETABLE_STATUSES` es un `frozenset` consultado en `mission.py:198`, la
   comprobación de vitalidad hay que pasarla como argumento a `MissionStore.delete`, no meter
   `threading` dentro de `mission.py`.
3. **`RECOVERING`** es un estado fantasma de milisegundos: `main.py:352` lo escribe y `main.py:354` arranca
   el hilo, que en `mission_runner.py:185` lo sobrescribe con `WAITING_FOR_GPU`. Incluirlo en el mismo
   tratamiento.
4. **`PLANNING` es un estado muerto:** está en `ProductionMission.STATES` (`mission.py:12`) y el frontend
   lo trata como misión activa (`ada_app/static/app.js:8`), pero ningún camino del backend lo escribe.
   Eliminarlo de la lista o del frontend. Y `STATES` en sí es una lista muerta: no se referencia en ningún
   sitio salvo su propia definición, así que `store.update(mission, status=...)` acepta cualquier cadena.
   Validar contra `STATES` en `MissionStore.update`.
5. La misma técnica sirve para las reinterpretaciones atascadas: `ada_app/reinterpretation.py:171` también
   nombra su hilo (`name=f"reinterpret-{request_id}"`), así que el `_ACTIVE` en memoria (`:27`) que se
   pierde en cada reload es reconstruible del mismo modo, sin tocar disco.

**Descartado deliberadamente: heartbeat periódico + reaper de arranque.** Un heartbeat implica escrituras
periódicas en el documento de la misión, es decir **más** frecuencia de lost-update y de truncamiento por el
camino de `MissionStore` que A6 aún no ha arreglado. La detección por hilo no escribe nada. Y un reaper de
arranque que marque `FAILED` en bloque es activamente peligroso: si corre en un proceso que no es el único
—exactamente lo que ocurre durante un reload de `uvicorn --reload`— destruye misiones vivas en el otro
proceso.

**Qué se rompe si sale mal.** Tres limitaciones reales, ninguna oculta:

1. **Es por proceso.** No sabe nada de misiones de una ejecución anterior salvo "no está viva", que de
   todos modos es la respuesta correcta.
2. **Hay un hueco entre procesos concurrentes que el coordinador no cubrió y hay que cubrir.**
   `scripts/launchers/run_smoke.py:15`, `:34` y `scripts/launchers/run_production.py:14` ejecutan
   `run_mission` en hilos **sin nombre** y desde un **proceso aparte**. Una misión lanzada así está
   corriendo de verdad y el `threading.enumerate()` del servidor la reporta como muerta → un `Delete`
   borraría el JSON de una misión activa. Mitigación barata: antes de permitir el borrado o el resume de un
   estado no terminal, intentar adquirir `gpu_execution.lock` con `timeout=0`; si está tomado y no hay hilo
   local, hay otro proceso trabajando y hay que negarse. No es perfecto (el lock cubre la GPU, no la
   misión) pero cierra el caso observable.
3. **Se rompería con multi-worker.** Un segundo worker de uvicorn tiene su propio `threading.enumerate()`.
   Está descartado por arquitectura —hilo daemon, `filelock`, locks intra-proceso— según
   `audit/ROADMAP_IDEAS.md:736` (§15), así que es aceptable, pero conviene dejarlo escrito junto al helper
   para que nadie lo dé por válido el día que se plantee escalar.
4. **No sustituye a A6.** Seguirá habiendo estados persistidos inconsistentes: la escritura no atómica y el
   lost-update de `MissionStore` son otro problema. Esto solo evita necesitar un heartbeat para
   **detectarlos**.

**Cómo verificar que funcionó.** Crear una misión, esperar a que entre en `PRODUCING`, matar el proceso del
servidor con el gestor de tareas, y arrancarlo de nuevo. Hoy la misión aparece eternamente activa en la UI,
`POST /resume` devuelve `not_resumable` (`main.py:350`) y `DELETE` devuelve error (`mission.py:198-199`).
Después del fix debe reportarse como no viva, ser reanudable y ser borrable — **sin que su `status` en
disco haya cambiado**, que es la prueba de que no hay ninguna escritura nueva. Prueba del caso contrario:
con una misión realmente en curso, `DELETE` debe seguir siendo rechazado. Test que debe afirmar: con un
hilo dummy vivo llamado `mission-X`, el helper devuelve `True` y `delete("X")` lanza; al terminar el hilo,
el helper devuelve `False` y `delete("X")` funciona con `status="PRODUCING"`.

**Depende de.** Nada obligatorio. B4 sigue siendo muy recomendable (elimina la causa más frecuente de
zombis) pero **ya no es prerrequisito**: al no escribir nada, este fix no puede dañar una misión viva de
otro proceso. Habilita B2.

---

## B4 — El lanzador por defecto arranca con `--reload`

**Archivo que se toca:** `START_ADA_APP.cmd:14`:

```
start "ADA App Server" python ada.py serve --host 127.0.0.1 --port 8000 --reload
```

**Qué cambia.** Quitar `--reload` del lanzador de uso normal y dejarlo en un `START_ADA_APP_DEV.cmd`
separado. `ada.py:41` hace `uvicorn.run("ada_app.main:app", ..., reload=args.reload)` **sin
`reload_includes`**, así que el watcher vigila todos los `*.py` bajo el directorio de trabajo — todo el
repo.

Lo que provoca cada reload, con los hilos de misión en `daemon=True` (`mission_runner.py:392`) y sin ningún
hook de apagado: (a) el modelo de 9B cargado en `mission_runner.py:246` **sigue en VRAM** porque el único
`unload_all()` del camino está en `renderer_pipeline.py:193`, que nunca se alcanza, y el `ttl_seconds` de
la configuración nunca se envía (`lmstudio_controller.py:146-148`); (b) ComfyUI sigue renderizando un
prompt que nadie recogerá y no hay ninguna llamada a `/interrupt` en todo el alcance; (c) el subproceso M2
(`mission_runner.py:259`, **sin `timeout`**) queda huérfano escribiendo en el `run_dir`, produciendo un run
sin `manifest.json` que `scripts/run_index.py:58-60` ignorará para siempre; (d) la misión queda zombi
(B3); (e) `reinterpretation._ACTIVE` (`:27`) — el **único** estado mutable de negocio en memoria de toda la
aplicación — se pierde, y una reinterpretación en `QUEUED`/`PREPARING_RENDER`/`RENDERING` queda
irrecuperable porque `start_reinterpretation` solo acepta `READY_FOR_RENDER` o `FAILED` (`:163-166`)
— recuperable por la técnica de B3 punto 5, porque `reinterpretation.py:171` también nombra su hilo.
Con el lanzador por defecto esto es el **caso normal, no el excepcional**.

**Qué se rompe si sale mal.** El desarrollador pierde la recarga automática y puede no darse cuenta de que
está ejecutando código viejo tras editar un fichero. El mensaje del lanzador (`START_ADA_APP.cmd:22-23`)
debe decirlo. Si en vez de quitar `--reload` se añade `reload_excludes` en `ada.py:41`, hay que verificar
que excluye también `data/` y `experimental/`, porque `mission_runner.py:240` escribe
`experimental/m1_creative_expansion_lab/m2_config.json` **en el árbol de código**: hoy ese `.json` no
dispara el watcher (vigila `*.py`) pero cualquier ampliación del patrón lo convertiría en un reinicio por
cada ronda de cada misión.

**Cómo verificar que funcionó.** Lanzar una misión, y con la misión en `PRODUCING` guardar un `.py`
cualquiera del repo. Hoy el servidor reinicia y la misión queda colgada. Después del fix la misión debe
continuar hasta terminar. Comprobación adicional en LM Studio: tras el ciclo completo, el inventario de
modelos cargados debe quedar vacío.

**Depende de.** Nada. Reduce la ventana de A3, A13 y A14, y elimina la causa más frecuente de los zombis
de B3 (aunque B3 ya no lo necesita como prerrequisito).

---

## B5 — La cancelación no se observa durante la fase larga

**Archivos que se tocan:** `ada_app/mission_runner.py:202` y `:295` (los dos únicos chequeos de
`cancelled`), `ada_app/renderer_pipeline.py:238-255` (`run_renderer_pipeline`, sin ningún chequeo),
`ada_app/main.py:329-337` (el endpoint de cancelación).

**Qué cambia.** Los dos chequeos de cancelación viven **antes** de la fase de producción: `:202` al entrar
en la ronda y `:295` justo después de la única relectura de la misión desde disco (`:294`). No hay ningún
chequeo dentro de `run_renderer_pipeline`, que es la fase de minutos u horas. Consecuencia: cancelar
durante `PRODUCING` no tiene efecto observable hasta la siguiente ronda.

El cambio: `run_renderer_pipeline` recibe un `should_cancel: Callable[[], bool]` y lo consulta al principio
de cada iteración del bucle de candidatos (`renderer_pipeline.py:241`). El callable relee el JSON de la
misión desde disco (`MissionStore().load(...).cancelled`). Al detectar cancelación, salir del bucle
limpiamente y dejar que `mission_runner` escriba `CANCELLED`.

**Qué se rompe si sale mal.** Un chequeo por candidato añade una lectura de disco cada varios minutos:
irrelevante. El riesgo es la granularidad: un candidato ya en marcha seguirá hasta terminar (20 min de
render + hasta 30 min de review), y el usuario que pulsa cancelar espera algo más rápido. Cancelar de
verdad requeriría interrumpir el prompt de ComfyUI, y **no hay ninguna llamada a `/interrupt` ni al borrado
de cola en todo el alcance** (grep confirmado): eso es parte de B10. Mientras tanto, el mensaje de la UI
("Cancelling after current stage...", `main.py:336`) es honesto y debe mantenerse.

**Cómo verificar que funcionó.** Lanzar una misión de 4 imágenes, esperar a que la primera esté renderizando,
y llamar `POST /api/missions/{id}/cancel`. Hoy la misión termina las 4. Después del fix debe terminar la que
está en curso y quedar en `CANCELLED` sin empezar la segunda. Test que debe afirmar: con `should_cancel`
devolviendo `True`, `run_renderer_pipeline` sobre 3 candidatos llama `execute_renderer_candidate` **cero**
veces.

**Depende de.** A6 — obligatorio. Sin el merge por claves de `MissionStore.update`, el `cancelled=True` que
escribe `main.py:336` es sobrescrito por el siguiente `store.update` del hilo (por ejemplo
`mission_runner.py:291`), así que el `should_cancel` leería `False` de un fichero recién pisado.

---

## B6 — `continue_on_error=False` en scene, y `REVIEW_FAILED` no se cuenta en ninguna categoría

**Archivos que se tocan:** `ada_app/mission_runner.py:331-337` (la llamada a `run_renderer_pipeline` sin
`continue_on_error`), `ada_app/renderer_pipeline.py:238` (el parámetro, `False` por defecto),
`ada_app/renderer_pipeline.py:248-251`, `ada_app/mission_runner.py:341-345` (los contadores),
`ada_app/mission_runner.py:385-388` (el `except` que descarta la ronda).

**Qué cambia.**

1. **Pasar `continue_on_error=True` en scene**, como ya se hace en stock (`mission_runner.py:123`). Hoy un
   único candidato que lance excepción se propaga por `renderer_pipeline.py:250` y aborta la ronda entera →
   salta a `mission_runner.py:385-388` → misión `FAILED`, contadores de la ronda (`:353-358`) **nunca
   aplicados** y sin `build_index`. Asimetría severa: en scene un fallo aislado destruye el resultado de
   toda la ronda, incluidos los candidatos ya `APPROVED`.
2. **Contar `REVIEW_FAILED`.** `mission_runner.py:341-345` cuenta `APPROVED`, `REJECTED_QUALITY`,
   `RETRY_EXHAUSTED` y `{FAILED_RUNTIME, SETUP_FAILURE, CONTRACT_FAILURE}`. `REVIEW_FAILED` **sí** lo
   produce `renderer_pipeline.py:51-52` y **no se cuenta en ninguna categoría** en scene (la ruta stock sí
   lo cuenta, `mission_runner.py:137`). Un candidato que renderiza bien y falla en la revisión desaparece de
   todos los contadores: `approved + rejected + failed < selected`, sin que nada lo señale. Añadirlo a
   `failed_states` (`:344`) o a un contador propio.
3. **Limpiar los contadores muertos.** `RETRY_EXHAUSTED` y `SETUP_FAILURE` **nunca** los produce
   `renderer_pipeline.py`: son siempre 0 en misiones scene. Los produce solo `ada_app/pilot_runner.py`
   (`:656-679`, `:724`), que es el camino paralelo Illustrious/Klein. Dejarlos documentados como tal o
   eliminarlos del recuento de scene.
4. **Aplicar los contadores en el camino de excepción.** Mover el bloque `:341-358` a un `finally` o
   duplicarlo en el `except` de `:385`, para que una ronda abortada no descarte lo que sí produjo.

**Qué se rompe si sale mal.** `continue_on_error=True` cambia lo que hace un fallo sistémico: hoy un
ComfyUI caído tumba la misión en el primer candidato; con el cambio, intenta los N candidatos y falla N
veces, consumiendo tiempo y llenando `failure_details`. Hay que añadir un corte por fallos consecutivos
(por ejemplo 3 seguidos → abortar la ronda). Y si se cuenta `REVIEW_FAILED` como fallo, `is_target_met`
(consumido en `mission_runner.py:365` y `:369`) no cambia, pero los porcentajes que muestre la UI sí: hay
que comprobar que la suma de contadores nunca excede `selected_candidates`.

**Cómo verificar que funcionó.** Lanzar una misión scene de 3 candidatos y provocar un fallo determinista en
el segundo (por ejemplo bajando `vram_release.timeout_seconds` a `1` en `config/orchestration.json:80`, que
reproduce A12). Hoy: la misión queda `FAILED` con `approved_assets = 0` aunque el primer candidato se
aprobara, y sin `build_index`. Después del fix: el primero debe contar como aprobado, el tercero debe
intentarse, y la suma `approved + rejected + review_failed + failed` debe igualar 3. Test que debe afirmar:
con `execute_renderer_candidate` lanzando en el candidato 2 de 3, `run_renderer_pipeline` llama a los tres
y el contador de aprobados de la misión refleja los que pasaron.

**Depende de.** A7 punto 4 y A11 punto 3 (que `build_index` se ejecute también en el camino de fallo).
A12 elimina la causa más frecuente del fallo que este item contiene.

---

## B7 — El camino productivo nunca llama `prepare_for_comfy`: el primer candidato de cada ronda puede fallar de forma determinista

**Archivos que se tocan:** `ada_app/renderer_pipeline.py:160` (el `submit`, sin preparación previa),
`ada_app/mission_runner.py:246` (`activate_role("premise_agent")`, que carga el 9B),
`scripts/lmstudio_controller.py:350-362` (`prepare_for_comfy`, la función que existe y no se llama),
`scripts/lmstudio_controller.py:164-191` (`activate_role`, aditivo),
`scripts/lmstudio_controller.py:271-284` (`wait_for_comfy_vram_release`),
`config/orchestration.json:80` y `:82`.

**Qué cambia.** El camino productivo de misión es el **único** que llama `handoff_comfy_to_lm`
(`renderer_pipeline.py:188`) sin llamar nunca `prepare_for_comfy`. Sí lo llaman
`ada_app/pilot_runner.py:57`, `ada_app/model_lab.py:185`, `ada_app/direct_generator_lab.py:191`,
`ada_app/reinterpretation.py:100` y `scripts/run_full_pipeline.py:225`. Y `prepare_for_comfy` **nunca** se
llama desde `renderer_pipeline.py` ni desde `mission_runner.py` (grep confirmado).

Por qué importa aritméticamente, no probabilísticamente: `activate_role` es **aditivo**. La línea
`scripts/lmstudio_controller.py:175` filtra por `item.get("model") == role.model`, así que solo desaloja
instancias del **mismo** modelo con otro `context_length` (`:178-188`). Un modelo con otra clave nunca se
descarga. Secuencia real: `mission_runner.py:246` carga
`qwen3.5-9b-uncensored-hauhaucs-aggressive` (`config/orchestration.json:33`); el render de
`renderer_pipeline.py:160-161` no descarga nada; `renderer_pipeline.py:190` carga
`qwen/qwen3-vl-8b` (`config/orchestration.json:69`), clave distinta → solo carga. El 9B sigue en VRAM
durante el render **y** durante la revisión.

Entonces, cuando `renderer_pipeline.py:188` pide el handoff, `wait_for_comfy_vram_release`
(`lmstudio_controller.py:271-284`) exige `vram_free / vram_total >= comfy_min_free_ratio` = **0.75**
(`config/orchestration.json:82`) en un máximo de `timeout_seconds` = **90 s**
(`config/orchestration.json:80`). Y `vram_free` viene de `GET /system_stats` de ComfyUI
(`lmstudio_controller.py:302-313`): es memoria **libre del dispositivo**, no de ComfyUI, así que el 9B
residente la reduce. **Si el modelo creativo ocupa más del 25 % de la VRAM total, el umbral es inalcanzable
y el primer candidato de cada ronda falla siempre**, y por A12 se lleva por delante la ronda.

El cambio: llamar `prepare_for_comfy` antes del `submit` de `renderer_pipeline.py:160`, exactamente como lo
hace `pilot_runner.py:57` a través del helper `prepare_comfy_handoff` (`pilot_runner.py:56-58`), que ya
está escrito y probado en ese camino.

**Qué se rompe si sale mal.** `prepare_for_comfy` hace `unload_all()` (`lmstudio_controller.py:353`), que
descarga **todas** las instancias, sean de quien sean. Si se llama por candidato dentro del bucle de
presets (`renderer_pipeline.py:118`), se descarga y recarga el modelo de review N veces por ronda: cada
carga cuesta hasta 300 s (`lmstudio_controller.py:149`). Hay que llamarlo una vez por candidato **antes**
del primer `submit`, no por preset. Además exige `status["idle"]` y lanza `RuntimeError` si ComfyUI está
ocupado (`:356-357`): con un prompt huérfano en cola (B10) eso convierte un fallo silencioso en un fallo
ruidoso — correcto, pero es un cambio de comportamiento. Y ojo: `unload_all` también descarga los modelos
que el **usuario** tenga cargados a mano, y la aplicación ya lo hace sin consultar la puerta `enabled` (ver
C8).

**Cómo verificar que funcionó.** El artefacto de handoff se persiste: comprobar en el candidato el campo de
`resource_handoff` / la salida de `handoff_comfy_to_lm`. La prueba directa es medir: con el 9B cargado,
`curl http://127.0.0.1:8188/system_stats` y calcular `vram_free / vram_total`. Si es < 0.75 antes del fix,
el handoff de `renderer_pipeline.py:188` está fallando en cada primer candidato — observable como
`REVIEW_FAILED` sistemático en el candidato 1 de cada ronda. Después del fix, ese ratio debe ser > 0.75
justo antes del `submit`. Test que debe afirmar: `execute_renderer_candidate` llama `prepare_for_comfy`
antes de la primera llamada a `submit` (monkeypatch registrando el orden).

**Depende de.** Nada. Es la causa raíz de la mitad de los `REVIEW_FAILED` que A12 y B6 mitigan.

---

## B8 — Cinco de los ocho caminos que consumen GPU no piden el lock

**Archivos que se tocan:** `ada_app/pilot_runner.py:775-778` (`start_pilot_background`),
`ada_app/main.py:680-683` (`subprocess.run` de M2 en `POST /api/pilot/generate`),
`ada_app/main.py:695` (`start_pilot_background`), `ada_app/main.py:762`
(`POST /api/creative_expansion`), `ada_app/model_lab.py:184-199` (vía `main.py:82`),
`ada_app/direct_generator_lab.py:190-194` (vía `main.py:116` → `ada_app/model_benchmark.py:297`).
Referencia del uso correcto: `ada_app/mission_runner.py:182-189`.

**Qué cambia.** Toda la búsqueda de `filelock` en el alcance devuelve **3 usos**, todos sobre el mismo
`gpu_execution.lock`: `mission_runner.py:182`, `main.py:490` y `reinterpretation.py:96`. Los caminos
listados arriba tocan la GPU sin pedir turno, y **todos son alcanzables desde botones de la UI**.

El daño concreto y demostrado (03 §6 C2): con una misión en plena revisión visual
(`renderer_pipeline.py:191`, `timeout=600`), un clic en `POST /api/model-lab/run` (`main.py:82`) llega por
`asyncio.to_thread` (`main.py:86`) a `model_lab.py:185`, que llama `prepare_for_comfy` →
`unload_all()` (`lmstudio_controller.py:353`) y **descarga el modelo que la misión está usando**. La
petición de inferencia muere, se agotan los 2 intentos y el fallback nativo
(`scripts/specialist_visual_reviewer.py:408`, `:461`), `_record_failure` escribe `REVIEW_FAILED`
(`renderer_pipeline.py:51-52`), y con `continue_on_error=False` la misión entera queda `FAILED` sin
`build_index` ni contadores. **Un clic destruye una misión.** Mismo interleaving vía `main.py:116` y vía
`main.py:695` → `pilot_runner.py:778` → `:732` (`release_lm_handoff` → `unload_all`).

El cambio: envolver la sección de GPU de los cinco caminos en el mismo `gpu_execution.lock`, con un
`timeout` corto (30-60 s) y una respuesta `409 gpu_busy` en vez de esperar — un endpoint interactivo no
debe bloquearse 24 h como hace `mission_runner.py:186`. Para `main.py:680` y `:762`, que ejecutan
`subprocess.run` **en el event loop**, el lock hay que tomarlo dentro de un `asyncio.to_thread` (mismo
problema que A16).

**Qué se rompe si sale mal.** (a) Un `timeout` corto convierte "el Model Lab espera su turno" en "el Model
Lab devuelve error mientras hay una misión", que dura horas. Es el comportamiento correcto pero hay que
comunicarlo, y `GET /api/system` (`main.py:147-181`) **no expone quién tiene el lock ni cuántas misiones
esperan**: sin eso, el 409 es inexplicable para el usuario. (b) Tomar el lock en
`start_pilot_background` (`pilot_runner.py:775-778`) desde un hilo daemon reintroduce el problema de la
espera larga. (c) `filelock` no es FIFO: adquiere por sondeo, así que con varios competidores el orden es
indefinido y una misión que lleva 3 h esperando puede perder frente a un clic recién hecho.
(d) Hay un **cuarto proceso** que puede llamar `unload_all()` y `prepare_for_comfy` sin tocar el lock:
`scripts/lmstudio_operator.py:570` y `:649`, el servidor MCP. Es el único invocador que respeta la puerta
`enabled` (`:647`), pero está fuera de este fix.

**Cómo verificar que funcionó.** Lanzar una misión, esperar a que esté en `PRODUCING`, y pulsar el botón
del Model Lab. Hoy: la misión pasa a `FAILED` con un candidato en `REVIEW_FAILED`. Después del fix: el
Model Lab debe responder `409 gpu_busy` y la misión debe terminar intacta. Repetir con
`POST /api/pilot/generate` y con `POST /api/creative_expansion`. Test que debe afirmar: `run_model_test`
llamado mientras el `gpu_execution.lock` está tomado por otro handle no llega a invocar `unload_all`.

**Depende de.** B4 reduce la ventana pero no la cierra. A12 evita que el daño escale de "revisión
reintentada" a "misión destruida"; los dos items son complementarios y ninguno sustituye al otro.

---

## B9 — La reinterpretación suelta el lock de GPU **antes** de tocar la GPU

**Archivo que se toca:** `ada_app/reinterpretation.py:98` (`with lock.acquire(timeout=86400)`), y las
líneas `:110`, `:111`, `:112`, `:115`.

**Qué cambia.** El bloque `with` termina en la línea 110. Verificado con la indentación literal del
fichero:

```
ri:98          with lock.acquire(timeout=86400):
ri:99              controller = LMStudioController()
ri:100             handoff = controller.prepare_for_comfy(...)
ri:101-110         seed / workflow / artifact_dir / workflow_path
ri:111         workflow_path.write_text(...)                              ← 8 espacios: FUERA del with
ri:112         prompt_id = submit(COMFYUI_BASE_URL, workflow, request_id)  ← FUERA
ri:115         history = wait_history(COMFYUI_BASE_URL, prompt_id)         ← FUERA
```

La sección crítica cubre **descargar LM Studio y construir un diccionario**. Todo el trabajo de GPU —
`submit` y hasta 1200 s de `wait_history` — corre sin lock. El cambio: indentar `:111` a `:145` dentro del
`with`, de forma que el lock cubra hasta el `register_reinterpretation` de `:135` inclusive.

Consecuencias del bug, ya trazadas: una misión creada en ese hueco adquiere el lock de inmediato
(`mission_runner.py:186`), carga el 9B en la misma VRAM (`:246`) y encola su propio render
(`renderer_pipeline.py:160`) mientras ComfyUI está renderizando la reinterpretación. Dos servicios pesados
sobre la misma tarjeta, con el lock "correctamente" adquirido por ambos flujos. Y ese mismo desbordamiento
pone `register_reinterpretation` (`reinterpretation.py:135` → `asset_library.py:831`) a escribir el mismo
`index.json.tmp` que el `build_index` de la misión (`mission_runner.py:380` → `asset_library.py:510`), que
es A13/A14.

**Qué se rompe si sale mal.** Ampliar la sección crítica a `wait_history` significa retener el
`gpu_execution.lock` hasta 1200 s por reinterpretación: las misiones esperarán detrás. Eso es lo correcto
(es lo que el lock existe para hacer) pero es un cambio de rendimiento observable. Y la liberación de VRAM
de `:139-144` debe quedar **dentro** del `with` también, o la siguiente misión adquiere el lock con la VRAM
de ComfyUI aún tomada. Cuidado con no meter dentro del lock el `_write_record` final (`:146` en adelante):
es E/S de disco y no necesita GPU.

**Cómo verificar que funcionó.** Lanzar una reinterpretación y, mientras la UI la muestre en `RENDERING`,
crear una misión. Hoy la misión pasa de `WAITING_FOR_GPU` a `RUNNING` inmediatamente. Después del fix debe
quedarse en `WAITING_FOR_GPU` hasta que la reinterpretación termine. Test que debe afirmar: con
`submit` y `wait_history` monkeypatcheados para registrar si el `gpu_execution.lock` está tomado en el
momento de la llamada, ambos deben verlo tomado.

**Depende de.** Nada. Es un cambio de un nivel de indentación y es el hallazgo de concurrencia con la
mejor relación entre trivialidad de la causa y magnitud del daño.

---

## B10 — Timeouts que no cancelan nada: M2 sin timeout, ComfyUI 1200 s fijo, y un hipo de red que destruye 20 minutos de render

**Archivos que se tocan:** `ada_app/mission_runner.py:259-262` y `ada_app/main.py:680-683`
(`subprocess.run` **sin `timeout`**), `scripts/run_specialist_mini_e2e.py:41-50` (`wait_history`),
`ada_app/renderer_pipeline.py:161` (lo llama sin `timeout`), `ada_app/mission_runner.py:186`
(`timeout=86400`).

**Qué cambia.** De los 19 timeouts definidos en el alcance, **ninguno cancela el trabajo remoto al
expirar** (03 §7). Tres cambios concretos:

1. **`subprocess.run` de M2 sin `timeout`.** `mission_runner.py:259-262` y `main.py:680-683`. Un M2
   colgado retiene el `gpu_execution.lock` **indefinidamente** y bloquea toda la GPU hasta que alguien mate
   el proceso a mano; no hay ningún endpoint ni script que rompa el lock. Añadir `timeout=` configurable
   (valor de partida: 900 s) y matar el hijo en el `TimeoutExpired`.
2. **`wait_history` no cancela el prompt.** `scripts/run_specialist_mini_e2e.py:41-50` tiene un
   presupuesto de **1200 s** por imagen como valor por defecto del parámetro, y
   `renderer_pipeline.py:161` lo llama **sin `timeout`**, así que no es configurable desde `config/`.
   Al expirar lanza `TimeoutError` y el prompt **sigue en la cola de ComfyUI** consumiendo GPU: no hay
   ninguna llamada a `/interrupt` ni a `/queue` con `delete` en todo el alcance (grep confirmado).
   El prompt huérfano envenena al candidato siguiente, porque `handoff_comfy_to_lm`
   (`renderer_pipeline.py:188`) exige que ComfyUI esté **idle** (`lmstudio_controller.py:316-324`, 600 s).
   Añadir: `timeout` leído de `config/`, y en el `except` una llamada a
   `POST {comfy}/interrupt` más el borrado del `prompt_id` de la cola.
3. **Un fallo de red en un sondeo aborta la espera entera.** El bucle de
   `run_specialist_mini_e2e.py:44-49` llama `http_json` **sin `try`**: un `urlopen` que lance por un hipo
   de red de 1 s destruye la espera de una imagen **ya renderizada**, que se trata como `FAILED_RUNTIME`.
   Envolver el sondeo en `try/except` con reintento y backoff (hoy el intervalo es de 2 s fijo, `:49`, sin
   backoff), reintentando hasta agotar el presupuesto total.

Nota sobre el lock de 24 h (`mission_runner.py:186`, `timeout=86400`): al vencer, **todas** las misiones
apiladas fallan a la vez con `FAILED` (`:190-192`) sin haber tocado la GPU. No hace falta cambiar el valor
en este item, pero sí exponer el estado del lock en `GET /api/system` (`main.py:147-181`), que hoy no
reporta ni quién lo tiene ni cuántas misiones esperan: `WAITING_FOR_GPU` es indistinguible de "colgado".

**Qué se rompe si sale mal.** (a) Un `timeout` de M2 demasiado corto mata generaciones legítimas: el valor
debe salir de una medición real, no de una suposición, y el fallo debe distinguirse en `failure_details`.
(b) `POST /interrupt` en ComfyUI interrumpe **el trabajo en ejecución**, no necesariamente el prompt que se
quiere cancelar: si otro flujo tiene un render en marcha (posible por B8), se le mata a él. Hay que
comprobar antes con `GET /queue` que el `prompt_id` en ejecución es el propio, y usar el borrado de cola
para los pendientes.
(c) Reintentar los sondeos alarga el peor caso: hay que mantener el `deadline` absoluto de `:44` y no
reiniciarlo en cada reintento.

**Cómo verificar que funcionó.** Para (1): lanzar una misión y suspender el proceso `run_m2.py` con el
gestor de tareas; el hilo debe abortar al vencer el timeout con un `error_message` claro, y el
`gpu_execution.lock` debe liberarse (comprobable creando una segunda misión, que debe pasar a `RUNNING`).
Para (2): reducir el timeout de ComfyUI a 10 s y lanzar un render; al expirar, `GET /queue` de ComfyUI
debe quedar vacío, no con el prompt corriendo. Para (3): con un proxy que corte una conexión de `/history`
a mitad, el render debe completarse igual. Test que debe afirmar: `wait_history` con un `http_json` que
lanza una vez y luego responde, devuelve el resultado.

**Depende de.** B8 (para (2): sin exclusión de GPU, `/interrupt` puede matar el trabajo de otro flujo).

---

# BLOQUE C

---

## C1 — `HTTPException` no está importada y las cuatro rutas de error lanzan `NameError` → 500

**Archivos que se tocan:** `ada_app/main.py:1` (el import) y los usos en `:421`, `:424`, `:426`, `:428`.

**Qué cambia.** `main.py:1` es `from fastapi import FastAPI, Request, BackgroundTasks`. No importa
`HTTPException`, y no hay ningún import local en toda la función ni en el módulo (grep confirmado: los
únicos cuatro usos en `ada_app/` son esas cuatro líneas). `POST /api/characters/{name}/hero` devuelve por
tanto **500 con `NameError`** en los cuatro casos de error, en lugar de 400 (`asset_id` ausente), 404
(imagen no encontrada), 409 (imagen de otro personaje) y 409 (imagen no visible en Library).

El cambio: añadir `HTTPException` al import de `:1`. Alternativa más consistente con el resto del fichero:
sustituir las cuatro por `JSONResponse(status_code=..., content={"error": ...})`, que es el patrón que usan
las otras 30 rutas de error del módulo (por ejemplo `main.py:334-335`, `:478`, `:483`).

**Qué se rompe si sale mal.** Si se importa `HTTPException` sin más, el cuerpo del error cambia de forma:
FastAPI serializa `{"detail": "..."}` mientras el resto del módulo emite `{"error": "..."}`. El frontend
que lea `error` no verá nada. De ahí que la segunda opción sea preferible: mismo contrato de error en todo
el módulo.

**Cómo verificar que funcionó.** `curl -X POST http://127.0.0.1:8000/api/characters/2B/hero -d "{}"
-H "Content-Type: application/json"`. Hoy: 500. Debe devolver 400 con un cuerpo legible. Repetir con un
`asset_id` inexistente (404) y con uno de otro personaje (409). Test que debe afirmar: el endpoint devuelve
400/404/409 y **nunca** 500 para esos tres casos.

**Depende de.** Nada. Es el fix más pequeño del documento y hoy hace que una función completa de la UI sea
inutilizable.

---

## C2 — `GET /api/image` sirve cualquier fichero del disco

**Archivo que se toca:** `ada_app/main.py:57-62`.

**Qué cambia.** El endpoint es:

```python
@app.get("/api/image")
async def get_image(path: str):
    p = Path(path)
    if not p.is_file():
        return JSONResponse(status_code=404, content={"error": "Not found"})
    return FileResponse(str(p))
```

Cero validación de ruta. Cualquier ruta absoluta de la máquina.

**Proporción, dicha honestamente:** es `127.0.0.1`, monousuario, sin autenticación, y el usuario ya tiene
acceso a sus propios ficheros. Los dos riesgos reales son: (1) el día que se exponga en red — o se
publique el puerto por un túnel — es lectura arbitraria de ficheros inmediata; (2) se encadena con la
salida de LLM sin escapar en `ada_app/static/app.js:1464` (`insertAdjacentHTML`), de modo que contenido que
llegue a ejecutar en el origen puede pedir `/api/image?path=` de cualquier cosa y exfiltrarla.

El cambio: resolver la ruta (`Path(path).resolve()`) y exigir que caiga bajo una de las raíces permitidas —
`LIBRARY_ROOT`, `RUNS_ROOT`, `REFERENCES_ROOT` y el `output/` de ComfyUI (`COMFYUI_ROOT`), todas ya
definidas en `scripts/ada_paths.py:54-63` y `:86-87`. Comparar con `os.path.commonpath` o
`Path.is_relative_to` sobre las rutas **resueltas**, para que `..` no funcione.

**Qué se rompe si sale mal.** La UI muestra hoy imágenes desde el `output/` de ComfyUI (`full_image_path`
de un asset no adoptado apunta ahí, `asset_library.py:762`) **y** desde
`data/library/assets/sha256/` (tras la adopción, `managed_assets.py:90`). Si la lista de raíces omite
`COMFYUI_ROOT`, se rompen las miniaturas de todo lo no adoptado. Y `COMFYUI_ROOT` es `None` si no está
configurado (`ada_paths.py:86-87`): hay que tolerarlo sin lanzar. Si se usa comparación de cadenas en
lugar de rutas resueltas, en Windows falla por mayúsculas y por rutas UNC.

**Cómo verificar que funcionó.** `curl "http://127.0.0.1:8000/api/image?path=C:\Windows\win.ini"` debe
devolver 403, no el contenido. `curl "http://127.0.0.1:8000/api/image?path=<ruta de un asset real>"` debe
seguir devolviendo la imagen. Probar también con `..`:
`?path=<LIBRARY_ROOT>\..\..\Windows\win.ini` → 403. Y abrir la Library en el navegador: todas las
miniaturas deben cargar, tanto las adoptadas como las que aún viven en el `output/` de ComfyUI.

**Depende de.** A9/A11 reducen el número de rutas legítimas fuera del almacenamiento de ADA, así que
aplicarlos antes hace la lista de raíces más corta y el fix más estrecho.

---

## C3 — Fail-open del evaluador: una review truncada o basura se normaliza a PASS

**Archivos que se tocan:** `scripts/specialist_visual_reviewer.py:210-214` (la función `score`),
`:236-239` (`actual` por defecto igual a `expected`), `:246` (`summary` fabricado),
`:255-258` (`subject_count.result`), `:161` (`verdict = "MINOR_DEFECT" if defects else "PASS"`),
`:352` y `:357` (donde `finish_reason` se registra y se ignora),
`config/orchestration.json:69-77` (ctx del rol), `:399` (`max_tokens`).

**Qué cambia.** `_normalize_grounded_review` (`:205-264`) se ejecuta **antes** de la validación de esquema y
rellena huecos con valores neutros:

- `score()` devuelve **5.0** ante cualquier valor no parseable (`:210-214`), aplicado a las cuatro
  dimensiones en `:260`.
- `subject_count.actual` **por defecto es igual a `expected`** (`:236-239`) → `result: "PASS"` en `:258`.
- `summary` se fabrica si falta (`:246`).
- Y en `_rated_grounded_review`, `verdict = "MINOR_DEFECT" if defects else "PASS"` (`:161`).

Efecto compuesto: una respuesta cortada por tokens que solo alcanzó a emitir
`{"identity":{"result":"PASS",...}` se convierte en `verdict: "PASS"` con rating ~5-6 y `subject_count
PASS`. Y `ada_app/renderer_pipeline.py:210` aprueba exactamente por `verdict == "PASS"`.

El riesgo de truncamiento no es teórico: el rol se carga con ctx **8192**
(`config/orchestration.json:69-77`) y la petición reserva `max_tokens: 4096`
(`specialist_visual_reviewer.py:399`) — la mitad de la ventana — para un prompt de ~2.5 KB más **1 a 3
imágenes en base64** (`:388`, `:393`).

El cambio: **mirar `finish_reason`**. Se registra en telemetría (`:352`, `:357`) y se ignora en la lógica.
Si es `length`, lanzar en vez de normalizar. El repo ya tiene la implementación correcta de esto en el
camino de M2: `parse_and_validate_creative_response`
(`experimental/m1_creative_expansion_lab/run_m2.py:94-120`) **distingue truncamiento real** comparando
`stats.total_output_tokens` contra el presupuesto y lanza `CreativeOutputTruncated`. Copiar ese patrón.
Segundo cambio: los defaults neutros de `:210-214` y `:236-239` deben ser **ausencia**, no un valor: si el
modelo no emitió un score o un conteo, el campo debe faltar y la validación de esquema debe rechazarlo.

**Qué se rompe si sale mal.** Endurecer la normalización hará que reviews que hoy pasan empiecen a lanzar,
y con `continue_on_error=False` en scene (B6) eso tumba misiones. **B6 debe ir antes.** Además, hay 3
llamadas máximo por candidato (`:408` con 2 intentos + 1 nativo en `:460-480`) y luego
`VisualReviewTransportError` (`:483`): si el truncamiento es sistemático por el tamaño del contexto, todos
los candidatos fallarán — que es información correcta pero inmediatamente bloqueante. Por eso este item se
apoya en C10.

**Cómo verificar que funcionó.** Test que debe afirmar: `_normalize_grounded_review` sobre
`{"identity": {"result": "PASS"}}` (sin `scores`, sin `subject_count`) **lanza**, en vez de devolver un
objeto con cuatro scores de 5.0 y `subject_count PASS`. Segundo test: una respuesta con
`finish_reason: "length"` lanza aunque el JSON parcial sea parseable. Comprobación manual: bajar
`max_tokens` a 200 en `:399` y lanzar una misión — el candidato debe fallar con un error que diga
"truncado", no aprobarse con rating 5.5.

**Depende de.** B6 (para que un fallo de review no destruya la ronda) y C10 (para que el presupuesto de
contexto deje de ser el cuello de botella).

---

## C4 — La frontera de contratos de review lanza siempre: el evaluador emite v4 y el orquestador valida v2/v1

**Archivos que se tocan:** `scripts/specialist_orchestrator.py:166` y `:270` (las dos llamadas a
`validate_visual_review`), `scripts/agent_contracts.py:59-64` (la función), `:114-120` (`_validate`),
`scripts/specialist_orchestrator.py:207` y `:209` (`compile_klein_legacy_agent`).

**Qué cambia.** `review_stage_image` devuelve el objeto derivado de v4
(`specialist_visual_reviewer.py:185-202`, `:247-264`, más `provenance` en `:426-435`).
`validate_visual_review` solo intenta `visual_review_v2` y luego `visual_review_v1`
(`agent_contracts.py:59-64`). `visual_review_v2` exige `identity_ok, scene_requirements_ok, requirements,
drift, uncertainty` (`schemas/visual_review_v2.schema.json:32`) — **ninguna existe** en el objeto v4 — y
tiene `additionalProperties: false` (`:6`). `visual_review_v1` exige `drift`
(`schemas/visual_review_v1.schema.json:33`) — tampoco existe. `_validate` lanza `ContractError` en ambos
casos. Es decir: `record_illustrious_review` y `record_final_review` **lanzan siempre** con una review real
del evaluador actual.

Segundo desalineamiento de la misma familia: `compile_klein_legacy_agent` accede a `review["defects"]` y
`review["drift"]` con indexación directa (`specialist_orchestrator.py:209`) y a
`review.get("identity_ok")` (`:207`) — todos campos v1/v2 ausentes en v4 → `KeyError` en `drift`.

El cambio: añadir `visual_review_v4` a la cadena de `validate_visual_review` (o, mejor, declarar la versión
emitida en la propia review y resolver el esquema por ese campo, en lugar del `try/except` en cascada de
`:59-64`). Y adaptar `compile_klein_legacy_agent` a la forma v4 o marcarla explícitamente como legacy y
sacarla del camino alcanzable.

**Qué se rompe si sale mal.** Añadir v4 a la cadena hace que la frontera **deje de lanzar** y empiece a
persistir reviews v4 en los artefactos del run. Todo lo que lea esos artefactos esperando v1/v2 pasará a
recibir v4: hay que revisar los consumidores antes de abrir la puerta. Y si se resuelve por campo de
versión, las reviews históricas que no lo llevan necesitan un default explícito.

**Cómo verificar que funcionó.** El estado actual es verificable en el propio repo: las únicas reviews con
`applied_caps` persistidas están en `legacy/runs/visual-review/grounded_identity_subject_count_v2/results.json`
y `.../v3/results.json` — ambas del arnés de regresión, **ninguna** en un `illustrious_review.json` de run;
los reales siguen siendo v1 (por ejemplo
`legacy/runs/full-pipeline/specialist_full_001/illustrious_review.json`, con claves `preserved_ok`/`drift`).
Test que debe afirmar: la salida **real** de `review_stage_image` (no una v1 escrita a mano) pasa
`validate_visual_review`. Hoy el único test de la frontera inyecta reviews v1 fabricadas
(`tests/test_specialist_orchestrator.py:55-58` y `:63-66`), y eso es precisamente por qué el fallo llegó a
producción sin detectarse.

**Depende de.** Nada. Ojo: la review de contrato es lo que hace que este bug sea *invisible* hoy —
`renderer_pipeline.py` no pasa por la frontera, así que el camino productivo funciona y el roto es el
camino de `pilot_runner.py` / `run_full_pipeline.py`. Coordinar con A4, que toca los mismos call sites.

---

## C5 — `base_url` hardcodeado en la revisión visual

**Archivos que se tocan:** `scripts/specialist_visual_reviewer.py:364`
(`base_url: str = "http://127.0.0.1:1234"` como valor por defecto) y `ada_app/renderer_pipeline.py:191`
(que **no** le pasa `base_url`).

**Qué cambia.** La URL de LM Studio se resuelve en `scripts/ada_paths.py:88-92`
(`ADA_LMSTUDIO_URL` → `LM_STUDIO_URL` → `config/ada.local.json` → `config/orchestration.json` →
`http://127.0.0.1:1234`). Toda esa cadena se **ignora** en la revisión visual, porque el llamador no pasa
el parámetro. Si LM Studio está en otro host o puerto, el render funciona y la revisión falla siempre.

El cambio: pasar `base_url=LMSTUDIO_BASE_URL` desde `renderer_pipeline.py:191`, y cambiar el default de
`:364` a `None` con resolución interna desde `ada_paths`, de modo que el fallo no pueda repetirse en un
llamador nuevo. Mismo tratamiento para `ttl_seconds`, que `review_stage_image` acepta (`:364`) y
`renderer_pipeline.py:191` tampoco pasa (ver C8).

**Qué se rompe si sale mal.** Nada relevante si la configuración por defecto ya es `127.0.0.1:1234`: el
comportamiento observable no cambia en la instalación típica. El riesgo es de importación:
`specialist_visual_reviewer.py` importar de `scripts.ada_paths` a nivel de módulo añade una dependencia en
un fichero que ya hace E/S en el import (`:27` lee
`config/runtime_instructions/visual_review_runtime_v2.md`), y un fallo ahí aparece como `ImportError` en
`POST /api/missions/create`, no como error de configuración.

**Cómo verificar que funcionó.** Poner `"lmstudio_url": "http://127.0.0.1:9999"` en
`config/ada.local.json` y lanzar una misión: el render debe llegar hasta la review y **la review debe
fallar apuntando al 9999**, no al 1234. Test que debe afirmar: con `LMSTUDIO_BASE_URL` monkeypatcheado, la
URL efectiva de la petición POST de `review_stage_image` la contiene.

**Depende de.** Nada.

---

## C6 — Estados sin revisar entran en la Library y pueden convertirse en la portada del personaje

**Archivos que se tocan:** `ada_app/asset_library.py:687` (`visible_states`),
`ada_app/asset_library.py:846-852` (`library_status`), `:28` y `:36-38`
(`_NON_VISIBLE_LIBRARY_STATUSES`), `ada_app/character_capabilities.py:155-157` (el fallback
`library_latest`).

**Qué cambia.** `visible_states` (`asset_library.py:687`) incluye `RENDERED_PENDING_REVIEW` y
`REVIEW_FAILED`. Un candidato que se quedó a medias en la revisión — porque el proceso murió (A12, B4) o
porque el handoff falló (B7) — es adoptado y publicado por el siguiente `build_index`
(`asset_library.py:515-516`, `:791`). Después `get_assets` le asigna `library_status = "UNREVIEWED"`
(`:846-852`) porque `final_review_verdict` es `"UNKNOWN"`, `is_visible_library_asset` devuelve `True`
porque `UNREVIEWED` no está en `_NON_VISIBLE_LIBRARY_STATUSES` (`:28`), y `build_character_catalog` puede
promoverlo a **portada del personaje** por la rama `library_latest`
(`character_capabilities.py:155-157`). Una imagen que nunca pasó el control de calidad se convierte en la
cara pública del personaje. No hay ningún estado de cuarentena ni marca de "adoptado sin revisar".

El cambio: introducir una marca `adopted_without_review: True` en el registro derivado cuando el
`pipeline_state` de origen es `RENDERED_PENDING_REVIEW` o `REVIEW_FAILED`, añadir el estado
`QUARANTINE` a `_NON_VISIBLE_LIBRARY_STATUSES` (`:28`) para esos casos, y excluir explícitamente los assets
marcados de la rama `library_latest` de la selección de portada
(`character_capabilities.py:155-157`, que exige hoy solo visibilidad).

**Qué se rompe si sale mal.** Si se sacan `RENDERED_PENDING_REVIEW` y `REVIEW_FAILED` de `visible_states`
sin más, se pierde la única forma de ver esas imágenes: hoy son la evidencia de que el render funcionó y la
review no. Hay que mantenerlas indexadas y **visibles bajo un filtro explícito**, no eliminarlas. Y si un
asset legítimamente aprobado quedó con `pipeline_state` `REVIEW_FAILED` por A12, este cambio lo esconde:
A12 debe ir antes.

**Cómo verificar que funcionó.** Provocar un `RENDERED_PENDING_REVIEW` (matar el proceso durante la
revisión), abrir la Library y comprobar: la imagen aparece marcada como sin revisar y **no** puede ser
portada de personaje. Test que debe afirmar: `build_character_catalog` no selecciona por `library_latest`
un asset cuyo `library_status` es `UNREVIEWED` y cuyo `pipeline_state` de origen es
`RENDERED_PENDING_REVIEW`.

**Depende de.** A12 (para no esconder aprobados mal etiquetados), A11 (que reduce mucho la frecuencia de
este estado).

---

## C7 — `HUMAN_REVIEW_REQUIRED` cae en el fallback `REJECT`

**Archivos que se tocan:** `ada_app/quality_router.py:26-45` (el `route`, con el fallback en `:44-45`),
`scripts/specialist_visual_reviewer.py:169` (donde se emite el veredicto),
`schemas/routing_decision_v1.schema.json` (el enum de acciones),
`scripts/run_full_pipeline.py:162-164`.

**Qué cambia.** Dos fallos opuestos y ambos graves:

- **Incertidumbre → descarte.** `_rated_grounded_review` emite `verdict = "HUMAN_REVIEW_REQUIRED"` cuando
  la identidad es `UNCERTAIN` (`specialist_visual_reviewer.py:169`). `QualityRouter.route` no contempla ese
  valor en ninguna rama (`quality_router.py:26-42`) y cae al fallback `return cls.ACTION_REJECT`
  (`:44-45`). Tampoco está en el enum de `schemas/routing_decision_v1.schema.json`. Resultado: "no estoy
  seguro" = candidato eliminado, sin que ningún humano lo vea.
- **`FAIL` no detiene nada en `run_full_pipeline`.** En `scripts/run_full_pipeline.py:162` se registra la
  review (avanzando la etapa) y en `:164` solo se reacciona a `{"RETRY_RENDER", "RETRY_ILLUSTRIOUS"}`.
  `FAIL` y `HUMAN_REVIEW_REQUIRED` caen fuera del `if` y el bucle de `:75` continúa a `_klein` (`:76`).

El cambio: añadir una rama explícita para `HUMAN_REVIEW_REQUIRED` en `QualityRouter.route`, con una acción
propia (`ACTION_HOLD`) presente en el enum del esquema, y hacer que el estado del candidato refleje "en
espera de humano" en vez de rechazado. Y un mapeo central de vocabulario de veredictos: hoy hay cuatro
vocabularios divergentes (`REJECT/REVIEW/RETRY_ILLUSTRIOUS` en
`schemas/visual_review_v1.schema.json:10`; `FAIL/RETRY_RENDER/REVIEW_REQUIRED` en
`schemas/visual_review_v2.schema.json:10`; `HUMAN_REVIEW_REQUIRED` en v3 y v4) y el único mapeo parcial
vive en `specialist_visual_reviewer.py:290-295` y **no cubre v4**.

**Qué se rompe si sale mal.** Introducir un estado de espera humana significa que los candidatos dejan de
terminar solos: `is_target_met` de la misión nunca se cumple y la misión queda en `PARTIAL` esperando a un
humano que quizá no llegue. Hay que definir el comportamiento por defecto tras N horas (recomendado:
contar como rechazado pero **conservado y marcado**, no borrado). Y añadir un valor al enum de
`routing_decision_v1` rompe cualquier consumidor que lo valide con `additionalProperties: false`.

**Cómo verificar que funcionó.** Test que debe afirmar: `QualityRouter.route` con
`verdict="HUMAN_REVIEW_REQUIRED"` devuelve una acción distinta de `ACTION_REJECT`, y que ningún veredicto
de los cuatro vocabularios cae en el fallback sin una rama explícita (recorrer todos los valores de los
cuatro enums y comprobar que ninguno llega a `:44`).

**Depende de.** Es prerrequisito de la variante suave de A4 (marcar `UNCERTAIN` en vez de fallar). Si A4 se
implementa con la puerta dura, C7 es independiente.

---

## C8 — `enabled` y `ttl_seconds`: configuración inerte que la aplicación ignora

**Archivos que se tocan:** `scripts/lmstudio_controller.py:63-65` (la propiedad `enabled`),
`config/orchestration.json:2` (`"enabled_by_default": false`),
`scripts/lmstudio_controller.py:146-148` (donde el TTL se documenta como no enviado),
`scripts/specialist_visual_reviewer.py:364` (acepta `ttl_seconds`) y `:403-404`.

**Qué cambia.** Dos mentiras de configuración:

1. **La puerta `enabled` no se consulta en la aplicación.** `enabled` devuelve
   `os.environ.get("PIPELINE_ORCHESTRATION", "0") == "1"` (`lmstudio_controller.py:63-65`), y
   `config/orchestration.json:2` dice `"enabled_by_default": false`. Sus únicos consumidores son
   `scripts/lmstudio_operator.py:537,647,691,734,748` y `scripts/run_klein_ab_test.py:291,399`.
   **Ninguno en `ada_app/`.** `mission_runner.py:246`, `renderer_pipeline.py:188-194`,
   `reinterpretation.py:100`, `model_lab.py:185`, `direct_generator_lab.py:191` y `pilot_runner.py:732`
   cargan y descargan modelos **incondicionalmente**: la aplicación se apropia de LM Studio y descarga los
   modelos del usuario aunque la orquestación esté declarada desactivada por defecto.
2. **`ttl_seconds` nunca se envía.** `config/orchestration.json` lo declara para los 7 roles, y el
   controlador lo documenta explícitamente como no usado (`lmstudio_controller.py:146-148`, y el docstring
   de la clase en `:53`: "It never relies on TTL to free VRAM"). Es una red de seguridad que no existe: si
   el proceso ADA muere, los modelos quedan cargados hasta que alguien reinicie LM Studio a mano.

El cambio: **decidir y hacer que el código y la configuración digan lo mismo.** O los llamadores de
`ada_app/` consultan `enabled` y degradan cuando está apagada, o `enabled_by_default` y la propiedad
desaparecen. Igual con `ttl_seconds`: o se envía en el payload de `load` (`lmstudio_controller.py:129-150`)
como red de seguridad para el caso de proceso muerto, o se elimina de los 7 roles del JSON.

**Qué se rompe si sale mal.** Si se activa la consulta de `enabled` con su valor por defecto (`"0"`),
**todo el camino productivo deja de cargar modelos** y las misiones fallan en
`mission_runner.py:247-250`. Cualquier cambio aquí debe ir con el valor por defecto invertido o con una
migración explícita. Si se empieza a enviar `ttl_seconds`, LM Studio puede descargar un modelo **a mitad de
una inferencia larga** (la revisión visual tolera hasta 600 s por intento,
`specialist_visual_reviewer.py:410`): el TTL debe ser holgadamente mayor que el timeout de inferencia.

**Cómo verificar que funcionó.** Para (1): con `PIPELINE_ORCHESTRATION` sin definir, cargar un modelo a
mano en LM Studio y lanzar una misión. Hoy la aplicación lo descarga sin preguntar. El comportamiento
deseado debe quedar decidido y verificado en ese escenario exacto. Para (2): matar el proceso del servidor
con un modelo cargado y esperar `ttl_seconds + 60`; el inventario de LM Studio debe quedar vacío.

**Depende de.** B4 y B8 son los que hacen visible el problema (el reload y los caminos sin lock son los que
dejan modelos huérfanos).

---

## C9 — Cero logging en `ada_app/`

**Archivos que se tocan:** todo `ada_app/`. Puntos donde la ausencia es más dañina:
`ada_app/mission_runner.py:191` y `:386` (`traceback.print_exc()` a stdout),
`ada_app/mission_runner.py:378-381` (`except: pass`), `ada_app/pilot_runner.py:772-773`
(`except: pass`), `ada_app/main.py:514` (`print(...)`), `ada_app/asset_library.py:307-308`, `:487-488`,
`:697-698` (excepciones absorbidas en silencio).

**Qué cambia.** No hay ningún uso del módulo `logging` en `ada_app/`. Los errores van a `stdout` del
proceso — que con `START_ADA_APP.cmd:14` es una ventana de consola que el usuario cierra — o
directamente al vacío. La consecuencia práctica es que **todos** los modos de fallo silenciosos de este
documento son indiagnosticables después del hecho: cuando el usuario dice "mi Library está vacía", no hay
ni una línea que diga por qué.

El cambio: un `logging` configurado en `ada_app/main.py` con handler de fichero rotatorio bajo
`DATA_ROOT / "logs"`, y sustituir los `print` y `traceback.print_exc()` por `logger.exception`. Prioridad
en los cinco `except` que hoy no dejan rastro:
`asset_library.py:307-308` (reviews corruptas), `:487-488` (índice corrupto), `:697-698` (run descartado),
`mission_runner.py:381` (`build_index` fallido) y `pilot_runner.py:773`.

**Qué se rompe si sale mal.** Un log con `DEBUG` sobre el camino de `build_index` genera una línea por
asset y por rebuild: con un dataset grande son ficheros de decenas de MB. Nivel `INFO` para transiciones y
`ERROR` para excepciones es suficiente. Y el log no debe contener las rutas absolutas completas de los
ficheros del usuario en cada línea si el fichero va a compartirse para soporte.

**Cómo verificar que funcionó.** Provocar tres de los fallos silenciosos de este documento (truncar
`asset_review.json`, truncar `pilot_candidates.json` de un run, y hacer fallar `build_index` borrando un
fichero fuente) y comprobar que cada uno deja una línea identificable en el log con la ruta del fichero
afectado. Hoy los tres son invisibles.

**Depende de.** Nada, pero es lo que hace verificables A2, A7, A9 y A13. Aplicarlo **antes** que ellos
ahorra tiempo de diagnóstico durante la implementación.

---

## C10 — Partición del contexto del evaluador en dos pases

**Archivos que se tocan:** `scripts/specialist_visual_reviewer.py:379` (resolución de referencias),
`:383` (`review_context`), `:385` (el prompt literal), `:386-394` (el mensaje multimodal),
`:395-401` (el envío), `:399` (`max_tokens: 4096`), `config/orchestration.json:69-77` (ctx 8192).

**Es rediseño, no bug. Va aquí y va al final.**

**Qué cambia.** Hoy una sola llamada lleva: el prompt base
(`config/runtime_instructions/visual_review_runtime_v2.md`, cargado en `:27`), el `review_context`
serializado como JSON (`:385`), la imagen bajo revisión y hasta 2 referencias canónicas, todo en base64
(`:388`, `:393`), dentro de una ventana de 8192 tokens de la que 4096 están reservados para la salida
(`:399`). Es la causa material de C3 y la razón por la que el evaluador ve el spec del que se compiló el
prompt de generación (F-01: `prompt_adherence` 0.20 + `composition` 0.15 =
**35 % del rating** midiendo adherencia a instrucciones que el evaluador acaba de leer,
`specialist_visual_reviewer.py:153-156`).

La partición propuesta:

- **Pase 1 — observación ciega.** Solo la imagen bajo revisión y las referencias canónicas. Sin
  `review_context`, sin `expected_visible`, sin `locked_requirements`, sin `composition`. Salida: qué se ve,
  conteo de sujetos, identidad contra las referencias, defectos de anatomía y calidad visual. Esto
  desactiva la contaminación de F-01 en las dimensiones donde no debería existir y libera la mitad del
  contexto.
- **Pase 2 — confrontación.** Recibe la observación del pase 1 (texto, ya no imágenes) y el
  `review_context`. Salida: `prompt_adherence` y `composition`, que sí requieren conocer la intención.

**Qué se rompe si sale mal.** (a) Duplica el número de llamadas al evaluador: con 600 s × 2 intentos +
600 s de fallback por pase (`:408`, `:410`, `:461`), el peor caso por imagen pasa de 1800 s a 3600 s, todo
dentro del lock de GPU. (b) Los scores dejan de ser comparables con los históricos: es exactamente lo que
A5 existe para registrar, y A5 debe estar aplicado antes. (c) Si el pase 1 no ve el `expected_subject_count`,
el esquema `visual_review_v4` deja de poder exigir el echo de `subject_count.expected`
(`schemas/visual_review_v4.schema.json:72-75`, con la comprobación en
`specialist_visual_reviewer.py:139-141`): hay que rehacer esa validación, que además es un modo de fallo
puro (pedir al modelo que repita una constante que el código ya tiene).
(d) Todo el andamiaje determinista que hoy edita la salida del evaluador —
`_ground_review_claims` (`:80-101`), que descarta afirmaciones por regex de color de ojos y pelo; la regex
que **sobreescribe** el conteo de sujetos de 1 a 2 (`:143-148`); los `identity_failure` fabricados en
`:122-123` y `:164`; las puntuaciones inventadas 9/3/5 de `_normalize_native_review` (`:272`) — está
calibrado contra el prompt actual y habrá que revisarlo pieza a pieza.

**Cómo verificar que funcionó.** La afirmación medible: con el mismo asset y las mismas referencias, el
pase 1 no debe poder mencionar ningún término presente **solo** en el `review_context` y ausente de la
imagen. Prueba concreta: inyectar en `composition_intent` una cadena inventada e improbable
(`"zzqx-composición"`) y comprobar que no aparece en `candidate_observations` ni en
`identity_comparison` del pase 1. Test que debe afirmar: el payload del pase 1 **no** contiene ninguna de
las claves de `review_context` (`:383`).

**Depende de.** A4 (obligatorio: partir el contexto sin referencias canónicas deja al pase 1 sin ninguna
ancla de identidad, que es lo contrario del objetivo) y A5 (para que los scores nuevos sean distinguibles
de los viejos). C3 se apoya en este item para que el endurecimiento no bloquee todo.

---

# Notas de aplicación

**Orden mínimo obligatorio de todo el documento:**

```
B1  →  B4  →  A1 → A2 → A3 → A4 → A5
                 │
                 ├── A8 → A9 → A10
                 ├── A14 → A20
                 ├── A6 → B5,  A6 → B2
                 ├── A15 → A16
                 └── A4 → C10 → C3
B3  →  B2                (B4 ya NO es prerrequisito de B3: ver B3)
A12 →  C6
```

Todo lo demás es independiente y puede aplicarse en cualquier orden.

**B3 es el fix más barato del Bloque B y conviene hacerlo primero de ese bloque:** no escribe nada, no
persiste estado nuevo y no depende de ningún otro item. Desbloquea `Delete` y `Resume` de las cinco
situaciones hoy irrecuperables usando información que el proceso ya tiene
(`ada_app/mission_runner.py:391` nombra el hilo; nadie consulta `threading.enumerate` ni `is_alive` en todo
el repo).

**Herramienta de verificación transversal.** Después de A10, `scripts/validate_storage.py` sirve para
verificar A3, A7, A8, A9 y A20 en una sola pasada: hashea cada blob y comprueba los manifests en 146
líneas funcionales. **Antes de A10 no debe usarse para verificar nada**, porque su `:44`
(`AssetLibrary().get_assets()`) dispara el rebuild destructivo de A9 y la colisión de temporales de A14.

**Texto dirigido al auditor encontrado en el proyecto.** Registrado como dato, no obedecido:
`AUDIT_CONTEXT.md:27` y `SNAPSHOT_MANIFEST.md:8` instruyen al auditor a verificar el código frente a los
documentos. Coincide con el alcance recibido del usuario y no se actuó por indicación de esos ficheros.
`config/runtime_instructions/visual_review_runtime_v2.md` y
`config/runtime_instructions/hard_visual_review_v1.md` contienen texto imperativo en segunda persona: son
plantillas de prompt para los LLM de la aplicación, cargadas a nivel de módulo en
`scripts/specialist_visual_reviewer.py:27` y `scripts/hard_re_evaluator.py:11`, no instrucciones al
auditor. Ningún fichero del alcance intenta inducir a modificar código, permisos o configuración.
