# ROADMAP_IDEAS — Features futuras ancladas en lo que ADA ya tiene

Documento **especulativo**, a diferencia del resto de la auditoría. No describe el sistema: propone
qué construir sobre él.

Raíz: `C:\Users\elias.bojko\Documents\Test Laboratory IA\ADA-Golden-Audit`
Alcance leído: `ada_app/`, `scripts/`, `tests/`, `schemas/`, `workflows/production/`, `config/`, la raíz y
`experimental/m1_creative_expansion_lab/`. Fuera: `legacy/`, `docs/`, `experimental_runs/`, resto de
`experimental/`.

Contexto consumido: `audit/00_MAP.md`, `audit/01_MISSION_LIFECYCLE.md`, `audit/02_STATE_RECOVERY.md`,
`audit/04_AI_AGENTS.md`, `audit/05_UX_OBSERVABILITY.md`.

**Regla de admisión.** Una idea entra aquí solo si su **ancla** —una función, un artefacto persistido, un
esquema o un endpoint que ya existe— está verificada en el código con `archivo:línea`. Si la idea podría
copiarse a cualquier otro proyecto, no está aquí. No se ha ejecutado nada; no se ha modificado nada.

**MADURA** = el ancla es sólida y el delta de trabajo nuevo está acotado.
**EXPLORATORIA** = la idea es buena pero el ancla es parcial, o el delta es grande e incierto.

---

## 0. Índice y veredicto

| # | Idea | Vena | Marca |
|---|---|---|---|
| 1 | Panel de integridad de la Librería | Capacidad a medias | **MADURA** |
| 2 | Reconstruir `index.json` desde `data/library/records/` | Dato persistido sin explotar | **MADURA** |
| 3 | Explicador estructurado del veredicto de máquina | Dato persistido sin explotar | **MADURA** |
| 4 | Historial de Hard Re-Evaluation y taxonomía de hooks | Dato persistido sin explotar | **MADURA** |
| 5 | Cobertura de referencias: ¿puede ADA juzgar identidad? | Dato persistido sin explotar | **MADURA** |
| 6 | Catálogo de plantillas de escena y reutilización | Capacidad a medias | **MADURA** |
| 7 | Revisión visual de las reinterpretaciones | Capacidad a medias | **MADURA** |
| 8 | Telemetría de render y duración por candidato | Info calculada y descartada | **MADURA** |
| 9 | Explotar `m3_analysis`: diversidad y coste del descarte | Info calculada y descartada | **MADURA** |
| 10 | Activar la recuperación de renders ya escrita | Capacidad a medias | **MADURA** |
| 11 | Evidencia de capacidad de renderer derivada de las reviews | Dato persistido sin explotar | EXPLORATORIA |
| 12 | Reintento dirigido por defectos | Capacidad a medias | EXPLORATORIA |
| 13 | Guías versionadas conectadas a M2 + atribución por sha256 | Capacidad a medias | EXPLORATORIA |
| 14 | Promoción explícita de un render de Model Lab a la Librería | Capacidad a medias | EXPLORATORIA |

**10 MADURAS, 4 EXPLORATORIAS.** Ordenadas de mayor a menor solidez del ancla.

Dos observaciones transversales que sostienen buena parte de la lista:

- **Siete endpoints están implementados y la UI no los llama nunca** (verificado extrayendo todas las
  cadenas `/api/...` de `ada_app/static/*.js` y `ada_app/templates/index.html`):
  `GET /api/library/search`, `GET /api/library/source-policy`, `POST /api/library/build_index`,
  `POST /api/pilot/resume/{run_id}`, `POST /api/characters/revalidate`,
  `GET /api/runs/{run_id}/m3_analysis`, `GET /api/runs/last`.
- **El índice de la Librería ya lleva todo lo caro.** `Asset.to_dict` (`ada_app/asset_library.py:228-283`)
  serializa `render_outputs`, `render_receipts`, `prompt_artifacts`, `stage_render_plans`,
  `review_observations`, `resolved_render_spec`, `character_contract`, `agent_scores` y `lineage`. Es
  decir: `GET /api/library/assets` (`ada_app/main.py:390-393`) ya entrega al navegador la review completa,
  la semilla, el workflow y el prompt de cada imagen. Varias ideas de esta lista son **solo frontend**.

---

## 1. Panel de integridad de la Librería

**MADURA**

### Qué habilita
Responder en un clic a la única pregunta que hoy no tiene respuesta: *¿mi dataset sigue entero?*
Detecta el daño silencioso que la auditoría documenta como el más frecuente: un `index.json` truncado que
hace que la Librería aparezca casi vacía sin ningún error (`02_STATE_RECOVERY.md` H11), blobs cuyo sha256
ya no coincide, `source_artifact_root` desaparecidos, manifests de referencia con imágenes ausentes y
`asset_review.json` con claves huérfanas.

### Qué reutiliza
- `scripts/validate_storage.py` — **146 líneas ya escritas y completas**. Verifica sha256 de cada blob
  contra `storage_provenance.sha256` (`:56-70`), abre cada imagen con PIL (`:64-66`), verifica los hashes
  de cada referencia canónica (`:76-97`), parsea todas las misiones (`:103-110`), cuenta las entradas de
  `hard_rating_history` (`:116-118`) y emite un informe JSON con 18 métricas (`:119-141`).
  **Cero importadores, cero endpoint, cero UI** (`00_MAP.md` §7.2).
- `ada_app/managed_assets.py:101-107` `verify_managed_record` — el verificador por registro, ya escrito,
  **sin ningún llamador en el repo**.
- `storage_provenance` con `sha256`, `bytes`, `managed_path`, `original_source_path`, `adopted_at`,
  `copy_verified`, escrito en cada adopción (`ada_app/managed_assets.py:78-88`).
- El patrón de endpoint que no bloquea el event loop ya existe: `asyncio.to_thread`
  (`ada_app/main.py:86`, `:120`, `:574`, `:592`).

### Qué haría falta construir
1. Refactorizar `main()` de `validate_storage.py` para **devolver** el dict en vez de imprimirlo
   (`:119-141` ya lo construye; `:142` lo imprime).
2. **Quitar la mutación oculta.** `validate_storage.py:44` hace `AssetLibrary().get_assets()`, y eso
   dispara `build_index()` si el índice está vacío (`ada_app/asset_library.py:835-836`) además de la
   escritura no atómica del constructor (`:480-481`). Es decir: el validador "de solo lectura" puede
   ejecutar el rebuild destructivo que pretende diagnosticar (`02_STATE_RECOVERY.md` H16). El endpoint
   debe leer `index.json` directamente y **nunca** construir `AssetLibrary`.
3. `GET /api/library/integrity` envuelto en `asyncio.to_thread` (hashea todo el dataset: es minutos de I/O)
   y un panel "Diagnostics" que muestre fallos y avisos. Sin barra de progreso, el patrón de
   `hardReevaluateSelectedLibraryImages` (`ada_app/static/app.js:1268-1288`) enseña que una espera larga
   sin feedback es inaceptable: conviene devolver un `report_id` y sondear.

### Dependencias
Ninguna para **informar**. Para **reparar** lo que encuentre, depende del escritor no atómico de
`_load_index` (`ada_app/asset_library.py:480-481`) y de la idea 2.

---

## 2. Reconstruir `index.json` desde `data/library/records/`

**MADURA**

### Qué habilita
Recuperar la Librería sin re-escanear runs y sin depender de que ComfyUI conserve su `output/`.
Hoy el rebuild es un reemplazo total derivado de `pilot_candidates.json` filtrado por **existencia del
fichero original de ComfyUI** (`ada_app/asset_library.py:731`, `:787`). Consecuencia medida en
`02_STATE_RECOVERY.md` H4: si el operador limpia el `output/` de ComfyUI —algo que `README.md:68` presenta
como seguro— la siguiente misión ejecuta `build_index()` incondicionalmente (`ada_app/mission_runner.py:380`)
y **todo el catálogo histórico desaparece de la aplicación** aunque los blobs verificados sigan intactos.

### Qué reutiliza
- `ada_app/managed_assets.py:93-97` — cada adopción escribe ya una instantánea completa del registro en
  `LIBRARY_RECORDS_ROOT / "{asset_id}.json"` de forma **atómica** (`.tmp` + `replace`), con
  `full_image_path` reapuntado al blob gestionado (`:90-91`). **Cero lectores en todo el repo.**
- `scripts/ada_paths.py:56` `LIBRARY_RECORDS_ROOT`.
- `ada_app/asset_library.py:509-512` `_write_index_records` — el escritor atómico del índice, ya correcto.
- `ada_app/asset_library.py:491-506` `_load_explicit_images` / `_save_explicit_images` — el precedente
  exacto de "cargar registros de un fichero satélite y fusionarlos con el índice".
- `tests/test_managed_library_storage.py:33` demuestra que `records/` se produce de verdad (2 JSON de
  record por 1 blob compartido).

### Qué haría falta construir
- `rebuild_index_from_records()`: leer `records/*.json`, descartar los que no verifiquen
  `verify_managed_record` (idea 1), fusionar con `explicit_images.json` con la misma precedencia que
  `_load_index` (`:484-486`) y publicar con `_write_index_records`.
- `POST /api/library/rebuild-from-records`, distinto de `POST /api/library/build_index` (`main.py:433-437`),
  que hoy es la única forma de reconstruir y es justo la destructiva.
- Un criterio explícito para el registro huérfano: `records/` nunca se borra, así que tras un rebuild que
  descartó assets contiene entradas que ya no están en el índice (`02_STATE_RECOVERY.md` §1.2).

### Dependencias
**Depende de arreglar `_safe_key`** (`ada_app/managed_assets.py:26-28`). Sustituye cada secuencia de
caracteres fuera de `[a-zA-Z0-9._-]` por un único `_`, así que los `asset_id` `X::lustify` y `X_lustify`
colapsan en el mismo `records/X_lustify.json` y una instantánea sobrescribe la otra
(`02_STATE_RECOVERY.md` H17). Hoy el daño es invisible porque nadie lee `records/`; convertirlo en fuente
de recuperación sin arreglar esto significa recuperar datos ya corruptos.

También conviene arreglar antes la doble escritura de `_build_index_unlocked`
(`ada_app/asset_library.py:787` → `:791`), para que `records/` y el índice no divergan por una ventana.

---

## 3. Explicador estructurado del veredicto de máquina

**MADURA**

### Qué habilita
Ver *por qué* una imagen fue rechazada, y distinguir un rechazo de máquina de una imagen pendiente de
revisar. Hoy un asset rechazado por el revisor entra en la galería por defecto y el modal lo etiqueta
"Awaiting human review" (`ada_app/static/renderer_library.js:53`), indistinguible de una imagen sin
revisar (`05_UX_OBSERVABILITY.md` Hallazgo 6.1). Y una imagen que puntuó 9.1 y quedó en 4.0 por un fallo
de identidad se presenta como "Agent rating 4" sin más.

### Qué reutiliza
Todo el dato está calculado, validado, persistido **y ya viaja al navegador**:
- `scripts/specialist_visual_reviewer.py:185-202` devuelve, por review:
  `agent_scores` (5 dimensiones), `agent_rating`, **`rating_before_caps`**,
  **`applied_caps`** (lista de `{reason, cap}` con las causas exactas: `identity_fail`,
  `identity_uncertain`, `subject_count_fail`, `anatomy_fail`, `hard_constraint_failure`, constantes en
  `:29-31`), `identity` (`result`/`score`/`confidence`), `subject_count`
  (`expected`/`actual`/`result`), `identity_failures`, `defects`, `hard_constraint_failures` y
  **`canonical_reference_count`**.
- Más los campos v4 del propio modelo: `candidate_observations`, `reference_observations`,
  `identity_comparison`, `outfit_design_adherence` (`schemas/visual_review_v4.schema.json`, `required`).
- `ada_app/renderer_pipeline.py:198` mete ese objeto entero en `render_outputs[-1]["review"]`, y
  `ada_app/asset_library.py:778` lo copia al asset, que `Asset.to_dict` serializa en `index.json`
  (`:268`). `GET /api/library/assets` ya lo entrega.
- `final_status` (`ada_app/asset_library.py:765`) ya guarda `REJECTED_QUALITY` / `REVIEW_FAILED` /
  `MACHINE_PASS`, y no se pinta en ninguna parte del frontend.

Lo que hoy se muestra: verdict + rating + `summary` + un `<pre>` con el `review_observation`
(`ada_app/static/renderer_library.js:38`). Nada más.

### Qué haría falta construir
Frontend puro:
1. Un bloque "Machine review" estructurado: las 5 dimensiones, `rating_before_caps → agent_rating` con la
   lista de `applied_caps` traducida, `subject_count expected/actual`, y `canonical_reference_count` con un
   aviso explícito si es 0 (ver idea 5).
2. Un badge `MACHINE REJECTED` en la tarjeta (`ada_app/static/app.js:1195-1209`) derivado de
   `final_review_verdict !== "PASS"`.
3. Una vista/filtro "Rechazado por máquina", distinta de la vista "Rejected" existente, que filtra por
   `library_status === 'REJECTED'` y eso es **rechazo humano** (`ada_app/static/app.js:837`, `:844`).

### Dependencias
Ninguna. Nota: los cuatro campos de observación v4 son texto libre del modelo; hay que escaparlos —
`libraryEsc` ya existe (`ada_app/static/renderer_library.js:2-4`) y se usa de forma inconsistente
(`05_UX_OBSERVABILITY.md` Hallazgo 6.3).

---

## 4. Historial de Hard Re-Evaluation y taxonomía de hooks

**MADURA**

### Qué habilita
Dos cosas que ADA ya podría medir y no mide:

1. **Deriva del evaluador.** Reevaluar la *misma* imagen varias veces y ver la dispersión. Es la única
   medida de varianza del evaluador que ADA puede obtener sin construir nada nuevo, y el dato ya está en
   disco.
2. **Qué tipo de hook puntúa de verdad.** Agregar `primary_hook_targets` y `context_hook_types` contra
   `final_score` en toda la Librería: la respuesta a "¿qué funciona?" en el vocabulario que el propio
   sistema usa para generar.

### Qué reutiliza
- `ada_app/asset_library.py:444-466` `save_hard_rating` — ya mantiene `hard_rating_history` como lista
  **append-only**, incluyendo los intentos fallidos (`:451-456`), y escribe de forma atómica bajo
  `_REVIEWS_LOCK` (`:462-464`). `tests/test_hard_rating_history.py:34-40` fija ese comportamiento (una
  reevaluación fallida no reemplaza el último éxito).
- `scripts/validate_storage.py:116-118` ya cuenta las entradas del historial.
- El contrato del evaluador duro persiste `basic_quality`, `primary_attraction_hook`, `contextual_hook`,
  `final_score`, `hook_reason`, `context_reason`, **`primary_hook_targets`**, **`context_hook_types`** y
  `problems` (`config/runtime_instructions/hard_visual_review_v1.md:49-60`, cargado en
  `scripts/hard_re_evaluator.py:11`).
- `ada_app/main.py:501-509` ya calcula y persiste `original_score` y `delta`.
- `updateHardStats` (`ada_app/static/app.js:1112-1163`) ya existe y agrega media de score, media de delta
  y distribución 90+/80-89/70-79/<70 — pero **solo sobre el último `hard_rating`**.

Verificado: `grep hard_rating_history` en `ada_app/static/` → **0 ocurrencias**. `original_score` tampoco
se pinta en ningún sitio (`05_UX_OBSERVABILITY.md` Hallazgo 7.1.1).

### Qué haría falta construir
- Una línea temporal en el modal leyendo `asset.human_review.hard_rating_history` (ya viaja en el payload:
  `get_assets` asigna `a["human_review"] = review` completo, `ada_app/asset_library.py:845`).
- Arreglar la línea base del delta: `main.py:503-506` usa siempre `human_review.rating` o `agent_rating`,
  nunca el `final_score` de la reevaluación anterior, así que dos reevaluaciones consecutivas dan deltas
  no comparables (`05_UX_OBSERVABILITY.md` Hallazgo 7.1.2). Con el historial disponible es un cambio de
  tres líneas.
- Un agregado por `primary_hook_targets` / `context_hook_types` en el panel `#library-hard-stats` que ya
  existe (`ada_app/templates/index.html:138`), y hacerlo funcionar también en el Character Workspace
  (`ada_app/static/app.js:1167` solo lo invoca para `library-assets-grid`).

### Dependencias
Ninguna para leer. **Advertencia sobre el valor del dato**: `scripts/hard_re_evaluator.py:23` envía
`"model": "local-model"`, es decir, evalúa con lo que esté cargado en LM Studio, sin `response_format` ni
esquema (`04_AI_AGENTS.md` §1.8). Una serie histórica de esa métrica mezcla modelos distintos salvo que se
persista también el modelo efectivo. **Añadir el nombre del modelo al registro es parte del delta**, y sin
ello la "deriva" que se mida no será deriva del evaluador sino ruido de configuración.

---

## 5. Cobertura de referencias: ¿puede ADA juzgar identidad?

**MADURA**

### Qué habilita
Saber **antes** de gastar 20 minutos de GPU si el veredicto de identidad de este personaje va a ser
verificable. La identidad pesa 0.30 del rating final
(`scripts/specialist_visual_reviewer.py:154`) y es lo único con ancla externa real; sin referencias
resolubles, el modelo juzga identidad contra los tags del propio spec de generación
(`04_AI_AGENTS.md` F-02).

### Qué reutiliza
- `scripts/specialist_visual_reviewer.py:40-77` `canonical_reference_paths` — devuelve `[]` si no hay
  manifest (`:56-57`), y valida que cada ruta esté bajo la raíz del manifest y exista (`:70-74`).
- `canonical_reference_count` se persiste en cada review (`:201`) y **ningún consumidor lo comprueba**:
  la única aserción `> 0` del repo vive en un test (`tests/test_character_reference_manifest.py:141`).
- Los manifests ya llevan la evidencia: `status`, y por referencia `file`, `source_url`, `domain`,
  `final_score`, `recommendation`, `sha256`, `downloaded_at`, más `duplicate_hashes`
  (`data/references/2b/nier_automata/manifest.json`; normalizados v1→v2 por
  `scripts/character_reference_manifest.py:16-30`; esquema en `data/references/manifest.schema.json`).
- `scripts/validate_storage.py:76-97` ya verifica manifest a manifest que cada imagen existe y su hash
  coincide.
- `ada_app/character_capabilities.py:113-127` `_reference_from_manifest` ya resuelve la primera referencia
  existente, y `build_character_catalog` (`:130-179`) ya es el sitio donde se computa el estado por
  personaje que consume `GET /api/characters/catalog` (`ada_app/main.py:563`).

Estado medido en este snapshot: de las 12 entradas de `data/characters/catalog.json`, **4 no tienen
`refs_manifest`** (`2B`, `Tifa Lockhart`, `Jill Valentine`, `Elsa`) — para ellas
`canonical_reference_paths` devuelve `[]` por construcción. De los 12 manifests presentes, 2 declaran
`status: "incomplete"` con 0 referencias y ninguno tiene sus ficheros `refs/*` completos en el snapshot.

### Qué haría falta construir
- `reference_coverage(entry)` junto a `character_capability_status`: resuelve el manifest, cuenta
  referencias existentes y con hash correcto, y devuelve `{resolvable, declared, status, grounded: bool}`.
- Añadirlo a `build_character_catalog` (`:162-179`) y pintar un badge en Characters, al lado del badge de
  capability que ya se pinta.
- Exponer `canonical_reference_count` en el modal (idea 3) como "Identidad verificada contra N
  referencias" / "Identidad **no** verificable".
- Opcional y barato: un aviso en Create cuando el personaje elegido tiene 0 referencias resolubles. El
  hueco de UI ya existe (`#create-renderer-capability`, `ada_app/static/app.js:415-421`).

### Dependencias
Ninguna para informar. Cerrar el hueco de verdad en los **otros** pipelines exige pasar
`character_contract` en `ada_app/pilot_runner.py:461`, `:589` y `scripts/run_full_pipeline.py:155`, `:276`
(`04_AI_AGENTS.md` F-02); el camino productivo (`ada_app/renderer_pipeline.py:191`) ya lo pasa.

---

## 6. Catálogo de plantillas de escena y reutilización

**MADURA**

### Qué habilita
Convertir una imagen que funcionó en un **molde reutilizable**: "esta composición, esta acción, este
encuadre — ahora con otro personaje", sin pasar por M2, sin llamada al modelo creativo, sin M3/M4.
Hoy eso ocurre exactamente una vez por petición y se tira.

### Qué reutiliza
- `ada_app/reinterpretation.py:59-63` `scene_template_from_asset` — **ya extrae de cualquier asset** un
  `scene_template_spec_v1` validado contra contrato, con `hook_type`, `snapshot`, `core_action`,
  `visual_hook`, `object_interaction`, `setting`, `composition`, `expression`, `preserve_from_source` y
  `must_not_preserve`.
- `schemas/scene_template_spec_v1.schema.json` (13 campos requeridos, `additionalProperties: false`),
  registrado en `scripts/agent_contracts.py` (`00_MAP.md` §9).
- Cada plantilla construida **ya se persiste**: forma parte del registro de la petición
  (`ada_app/reinterpretation.py:79`, clave `scene_template_spec`), escrito atómicamente en
  `RENDERER_RUNS_ROOT / "reinterpretations" / "{request_id}.json"` (`:25`, `:36-42`). Listar las
  plantillas históricas es un glob sobre ese directorio.
- El camino completo plantilla → contrato del personaje destino → spec → prompt → render → Librería ya
  está escrito y es el único del sistema que **no** toca M1/M2/M3/M4:
  `create_reinterpretation` (`:66-80`) → `_execute_reinterpretation` (`:83-157`) →
  `register_reinterpretation` (`ada_app/asset_library.py:794-832`).
- `template_mode` ya está validado con tres valores (`strict_composition`, `balanced`,
  `loose_inspiration`, `:68`) — y hoy se persiste sin que nada lo consuma: es el mando de intensidad de la
  plantilla, ya expuesto en la UI (`ada_app/static/renderer_library.js:201`).

### Qué haría falta construir
- Un índice de plantillas: `GET /api/scene-templates` que agregue los `scene_template_spec` de los
  registros existentes más los derivables de cualquier asset, deduplicados por `template_id`
  (`f"scene-template:{asset_id}:v1"`, `:62`).
- Guardar la plantilla como artefacto de primer orden (hoy solo vive dentro del registro de la petición) y
  una pantalla para nombrarla y reutilizarla.
- Hacer que `template_mode` signifique algo: hoy no se lee en ninguna parte del compilador
  (`ada_app/render_prompt_compilers.py`). Con `strict_composition` debería endurecer
  `composition_intent` a requisito bloqueado, cosa que `build_resolved_render_spec` ya sabe hacer
  (`ada_app/semantic_contracts.py:177-183`).
- Extensión natural, y aquí empieza lo exploratorio: **fan-out** de una plantilla sobre N personajes. Debe
  ser **un solo trabajo secuencial**, no N hilos: `start_reinterpretation` lanza un
  `threading.Thread(daemon=True)` por petición con un set `_ACTIVE` en memoria
  (`ada_app/reinterpretation.py:160-173`) y cada ejecución toma el filelock de GPU con timeout de 24 h
  (`:96-98`).

### Dependencias
Las reinterpretaciones entran en la Librería **sin ninguna revisión** — ver idea 7. Multiplicar el camino
por N personajes multiplica también ese problema, así que 7 debería ir antes que el fan-out.

---

## 7. Revisión visual de las reinterpretaciones

**MADURA**

### Qué habilita
Que una reinterpretación deje de entrar en la Librería sin juicio. Hoy `_execute_reinterpretation` va del
render directamente a `REGISTERING` (`ada_app/reinterpretation.py:115-135`) y el asset creado queda con
`final_status: "UNREVIEWED"`, `final_review_verdict: "UNKNOWN"`, `agent_rating: None` y
`render_outputs[0]["review"] = {}` (`ada_app/asset_library.py:813`, `:820`, `:823`). En la galería es
indistinguible de una imagen aprobada por la máquina.

Y hay un beneficio no obvio: **estas serían las reviews mejor ancladas del sistema.** El único requisito
que falla en 2 de los 3 pipelines (`04_AI_AGENTS.md` F-02) —tener el `character_contract` para resolver
las referencias canónicas— aquí está garantizado: la reinterpretación lo construye ella misma y lo
persiste como `target_character_contract` (`ada_app/reinterpretation.py:70`, `:79`).

### Qué reutiliza
- `scripts/specialist_visual_reviewer.py:362` `review_stage_image`, la misma función del camino productivo.
- El contrato del destino (`target_character_contract`) y el spec resuelto
  (`reinterpreted_render_spec.resolved_scene`), ambos ya en el registro (`:74`, `:79`).
- La secuencia de handoff de VRAM completa está escrita literalmente al lado, en
  `ada_app/renderer_pipeline.py:188-194`: `handoff_comfy_to_lm` → `activate_role("visual_review_worker")`
  → `review_stage_image` → `finally: unload_all()` + `wait_for_vram_release()`.
- `ada_app/semantic_contracts.py:195` `build_review_observation` y el hueco de artefacto
  `review_observations/` ya normalizado en el resto del sistema.
- `register_reinterpretation` ya construye el `render_outputs[0]` donde encajar la review
  (`ada_app/asset_library.py:820`).

### Qué haría falta construir
Insertar el bloque de review entre `:116` (`image = output_path(...)`) y `:132` (`status: "REGISTERING"`),
persistirlo en el registro y pasarlo a `register_reinterpretation`. Decidir la política: ¿un `FAIL`
impide entrar en la Librería, o entra marcada? El precedente productivo rechaza
(`ada_app/renderer_pipeline.py:210-217`).

### Dependencias
- **Bug bloqueante**: `review_stage_image` declara `base_url: str = "http://127.0.0.1:1234"` por defecto
  (`scripts/specialist_visual_reviewer.py:364`) y `renderer_pipeline.py:191` no le pasa `base_url`, así
  que la URL de `ada_paths.LMSTUDIO_BASE_URL` se ignora en toda revisión visual
  (`01_MISSION_LIFECYCLE.md` §5.1). Aquí hay que pasarla explícitamente o se hereda el mismo fallo.
- El registro ya persiste error con traceback (`ada_app/reinterpretation.py:148-154`), que es el patrón
  correcto y hay que mantener para el fallo de review.

---

## 8. Telemetría de render y duración por candidato

**MADURA**

### Qué habilita
El número que ADA hoy **no puede** dar: segundos por imagen y por preset. Es el dato que decide si la ruta
`Miaomiao → Lustify img2img` (dos renders + dos reviews por candidato,
`ada_app/renderer_pipeline.py:102-105`) vale lo que cuesta, y es lo que convierte la barra de progreso
congelada durante el 90 % de la misión (`05_UX_OBSERVABILITY.md` §3.2) en algo explicable.
También permite localizar *en qué candidato* se atascó una misión.

### Qué reutiliza
- El precedente existe dos veces y solo falta en el sitio más caro:
  - el revisor visual escribe `..._schema_telemetry.json` con modelo, latencia, tokens y `finish_reason`
    (`scripts/specialist_visual_reviewer.py:412`, telemetría construida en `:352-357`);
  - M2 escribe `telemetry.json` con latencia, tokens in/out, tok/s, TTFT y retries
    (`experimental/m1_creative_expansion_lab/run_m2.py`, campo `latency_seconds`);
  - **ComfyUI no tiene ninguna**: `submit` y `wait_history` (`ada_app/renderer_pipeline.py:160-161`) no
    registran nada, y ahí está el 90 % del tiempo de misión.
- El contenedor natural ya existe y **acepta campos nuevos sin tocar el esquema**: verificado en
  `schemas/render_receipt_v2.schema.json`, el objeto raíz tiene `additionalProperties: false` pero los
  sub-objetos `generation` y `submission` no lo restringen. `receipt["submission"]` ya lleva
  `prompt_id`, `run_id`, `concept_id` (`ada_app/renderer_pipeline.py:173`).
- La tabla del funnel ya se reconstruye cada 3 s y ya recibe una fila por concepto
  (`ada_app/static/app.js:1459-1465` sobre `GET /api/missions/{id}/funnel`,
  `ada_app/main.py:294-327`): añadir una columna de duración es una interpolación más.

### Qué haría falta construir
- Dos `time.monotonic()` alrededor de `submit`/`wait_history` y los timestamps resultantes dentro de
  `receipt["submission"]` (`queued_at`, `completed_at`, `wait_seconds`, `poll_count`).
- `started_at`/`updated_at` por candidato en las escrituras de `pilot_candidates.json` que ya existen
  (`renderer_pipeline.py:184`, `:205`, `:215`, `:231`) — hoy solo escriben `pipeline_state` y payloads
  (`05_UX_OBSERVABILITY.md` O3).
- Columna "Duración" en el funnel y un agregado por preset.

### Dependencias
`pilot_candidates.json` se reescribe de forma **no atómica** 5-6 veces por candidato
(`ada_app/pilot_runner.py:70-72`) y es la única fuente regenerativa de la Librería
(`02_STATE_RECOVERY.md` H5). Añadir campos no empeora el problema, pero cualquier feature que se apoye en
esos timestamps hereda el riesgo de que un truncamiento descarte el run entero en silencio
(`ada_app/asset_library.py:697-698`). El escritor atómico debería ir antes.

---

## 9. Explotar `m3_analysis`: diversidad y coste del descarte

**MADURA**

### Qué habilita
Ver por qué 9 de 18 conceptos nunca entraron en producción, y si M2 está produciendo casi-duplicados —
que es la causa real de GPU desperdiciada. Hoy el análisis se calcula, se persiste, **se sirve por la API**
y el frontend lo tira.

### Qué reutiliza
- `ada_app/m3_filter.py:94-115` produce por concepto `quality.score`, `quality.reason`,
  `diversity.score`, `diversity.similar_to[]` (con el `concept_id` del más parecido y su score de
  similitud) y `recommendation`; más un `summary` de lote con
  `generated` / `unique` / `duplicates` / `recommended` / `weak`.
- Se persiste en `m3_analysis.json` (`ada_app/mission_runner.py:301`).
- `GET /api/missions/{id}/funnel` **ya lo devuelve** por concepto como `item.m3`
  (`ada_app/main.py:309`, `:317`).
- El frontend construye la fila con `concept_id`, `selection_rank`, `pipeline_state`,
  `machine_review.verdict`, `asset_id` y `snapshot` (`ada_app/static/app.js:1464`) e **ignora `item.m3`
  por completo**.
- Existe además `GET /api/runs/{run_id}/m3_analysis` (`ada_app/main.py:614-636`), que incluso calcula el
  análisis si falta — y no se llama desde ningún sitio de la UI.

### Qué haría falta construir
- Dos columnas en la tabla del funnel (Quality / Diversity) y el `summary` del lote como línea de
  cabecera. Frontend puro.
- **Persistir `viral_score`.** `calculate_dataset_score` (`ada_app/m4_selection.py:5-38`) lo computa para
  cada propuesta de dataset y solo sobrevive interpolado dentro de una frase:
  `"Top N candidate based on Viral Score ({c['viral_score']}) and Diversity ({c['d_score']})"`
  (`:80`). Nunca como número. Añadirlo como campo del candidato es una línea, y sin él no se puede
  correlacionar la heurística de selección con el resultado real.
- Traducir los estados crudos: `runStatusLabel` ya existe (`ada_app/static/app.js:1636-1643`) y solo se
  usa en la tabla de Runs, así que el funnel muestra `SELECT` y `RENDERED_PENDING_REVIEW` literales
  (`05_UX_OBSERVABILITY.md` Hallazgo 3.3.3).
- Arreglar de paso la columna "Machine review", que lee `candidate.get("final_review")`
  (`ada_app/main.py:324`), campo que solo escribe el pipeline legacy; el actual guarda la review en
  `render_outputs[].review` (`ada_app/renderer_pipeline.py:198`), así que la columna siempre muestra `—`
  (`05_UX_OBSERVABILITY.md` Hallazgo 3.3.1).

### Dependencias
Ninguna. La reconstrucción completa de la tabla cada 3 s (`app.js:1459`) ya provoca parpadeo; añadir
columnas lo hace más visible, así que conviene render incremental.

---

## 10. Activar la recuperación de renders ya escrita

**MADURA** (alcance: dentro de un mismo run)

### Qué habilita
Que un reintento no vuelva a pagar el 100 % del coste de GPU. Hoy lo paga siempre.

### Qué reutiliza
El código de recuperación **ya está escrito y es correcto**, y está inalcanzable:

`ada_app/renderer_pipeline.py:120-136` busca en el candidato un `render_output` con el mismo `preset` cuyo
`receipt["output_asset"]` siga existiendo y, si lo encuentra, **salta la generación** reutilizando `plan`,
`prompt_artifact`, `receipt` e imagen. Pero `candidate` es el dict en memoria que recibió
`run_renderer_pipeline`, y sus dos únicos llamadores pasan candidatos recién construidos sin
`render_outputs`: `ada_app/mission_runner.py:119` (stock, candidato creado en `:99-109`) y
`ada_app/mission_runner.py:331` (scene, salida de `select_top_candidates`, `:303`). **Ninguna ruta pasa
nunca un candidato con `render_outputs` poblado**, así que las líneas 123-136 no se ejecutan jamás en
producción (`02_STATE_RECOVERY.md` §5.2).

Y la relectura desde disco ya existe en el mismo bucle: `run_renderer_pipeline` hace
`refreshed = read_json(run_dir / "pilot_candidates.json")` en `:252` para contar aprobados.

Además la semilla es determinista dentro del run —`sha256(f"{run_dir.name}:{concept_id}:{renderer}")`
(`:145`)— y el almacén es direccionado por contenido (`ada_app/managed_assets.py:61-65`), así que una
reejecución en el mismo `run_dir` produce el mismo blob y el mismo `asset_id`
(`f"{generation_id}::{renderer}"`, `ada_app/asset_library.py:738`): **dentro de un run no se duplica nada.**

### Qué haría falta construir
El núcleo acotado: en `run_renderer_pipeline`, releer el candidato desde `pilot_candidates.json` antes de
llamar a `execute_renderer_candidate` (el patrón ya está en `:252-253`) y pasar ese dict. Eso activa 17
líneas ya escritas y hace que `POST /api/pilot/resume/{run_id}` (`ada_app/main.py:639-660`, hoy nunca
llamado por la UI) sea útil de verdad.

Segundo paso, también acotado: ampliar el filtro de `:244` —hoy solo salta `APPROVED` y `FAILED_RUNTIME`,
de modo que `RENDERED_PENDING_REVIEW`, `REJECTED_QUALITY`, `REVIEW_FAILED` y `CONTRACT_FAILURE` se
reejecutan enteros— para que un candidato ya renderizado pero sin revisar solo repita la **review**.

### Dependencias
El paso siguiente —que "Resume" de misión reutilice el run anterior en vez de crear uno nuevo
(`ada_app/mission_runner.py:254-258`)— **es exploratorio y no cabe aquí**: los contadores de misión son
acumuladores `+=` (`:353-357`), no hay marcador de ronda persistido (la ronda solo existe como variable
del `for` en `:201`), y sin `last_updated_at` no se puede saber si el hilo anterior está vivo. Eso depende
de los arreglos de `02_STATE_RECOVERY.md` (escritura atómica de la misión en `ada_app/mission.py:166-170`
y la actualización perdida de `:189-192`).

---

## 11. Evidencia de capacidad de renderer derivada de las reviews

EXPLORATORIA

### Qué habilita
Que el routing de identidad —lo que decide entre Lustify directo, Miaomiao→Lustify img2img o bloqueo—
deje de depender de que alguien edite un JSON a mano.

### Qué reutiliza
- `ada_app/character_capabilities.py:54-73` `character_capability_status` lee
  `renderer_capabilities.{renderer}.identity_recognition` y devuelve `green`/`yellow`/`red`/`unknown`.
  Sus consumidores son reales y bloqueantes: `ada_app/main.py:243-247` (409
  `character_renderer_unavailable`), `ada_app/renderer_pipeline.py:93-96`
  (`ConstraintViolation` si es rojo, ruta img2img guardada si es amarillo), `resolve_stock_renderer`
  (`:88-110`) y la puerta de cliente en Create (`ada_app/static/app.js:331-345`, `:415-421`).
- **Nada en el repositorio escribe ese campo.** Verificado por grep sobre `ada_app/`, `scripts/`,
  `tests/`, `config/` y `data/`: solo lectores. Está a mano en `data/characters/catalog.json:178-190` y
  `:230-240`, y **solo 2 de las 12 entradas del catálogo lo tienen**; las otras 10 rutean como
  `unknown` → `unverified`.
- La evidencia para rellenarlo ya se acumula: cada asset del índice lleva `character`, `renderer` y la
  review completa con `identity.result`, `identity.confidence` y `agent_scores.identity`
  (`ada_app/asset_library.py:759`, `:748`, `:778`; review construida en
  `scripts/specialist_visual_reviewer.py:185-202`).
- Existe además un arnés de benchmark controlado ya escrito para exactamente esta pregunta:
  `ada_app/model_benchmark.py:63-115` con dimensiones `identity_preservation`, `face_similarity`, etc., y
  presets que ya declaran su `benchmark_evidence` (`config/pipeline.json`).

### Qué haría falta construir
- Un agregador sobre `AssetLibrary().get_assets()` agrupando por `(character, renderer)`: tasa de
  `identity.result == "PASS"`, media de `agent_scores.identity`, tamaño de muestra, y una propuesta de
  `identity_recognition` con su evidencia.
- Una superficie de **propuesta, no de escritura automática**: mostrar "Lustify: 2/9 identity PASS sobre 9
  imágenes — sugerido `unreliable`" y dejar que el operador lo confirme.
- Un escritor para `data/characters/catalog.json`. **No existe ninguno.** El único escritor cercano es
  `save_character_hero`, que escribe `heroes.json` con `write_text` directo bajo un lock intra-proceso
  (`ada_app/character_capabilities.py:42-47`) — precisamente el patrón que `02_STATE_RECOVERY.md` H15
  señala como pérdida total silenciosa. Hace falta un escritor atómico con lectura-modificación-escritura.

### Por qué EXPLORATORIA
El ancla (un campo que gobierna el routing y que nadie escribe) es incontestable, pero el delta arrastra
un problema de validez: la evidencia está contaminada. Para los personajes sin `refs_manifest` el
veredicto de identidad no se compara contra ninguna referencia (idea 5, `04_AI_AGENTS.md` F-02), y
`_ground_review_claims` (`scripts/specialist_visual_reviewer.py:80-101`) descarta silenciosamente
afirmaciones del evaluador por regex sobre color de ojos/pelo. Cualquier agregado debe filtrar por
`canonical_reference_count > 0` — lo que, con los datos actuales, dejaría la muestra en muy poco.

### Dependencias
Idea 5 (para saber qué evidencia es válida) y un escritor atómico de `catalog.json`.

---

## 12. Reintento dirigido por defectos

EXPLORATORIA

### Qué habilita
Que un rechazo por calidad se convierta en un segundo intento **informado** —"la mano izquierda tiene seis
dedos", "falta el eyepatch"— en vez de un descarte. Hoy el camino productivo no reintenta nunca:
un candidato rechazado se marca `REJECTED_QUALITY` y se abandona (`ada_app/renderer_pipeline.py:211-217`).

### Qué reutiliza
La maquinaria de corrección está **completa y sin usar en producción**:
- `build_stage_render_plan(render_spec, stage, attempt, correction_delta)`
  (`ada_app/semantic_contracts.py:445-500`) acepta un `correction_delta` y lo emite en el plan como
  `{source_decision_id, instructions}` (`:495-498`), validado contra
  `schemas/stage_render_plan_v1.schema.json` (que ya lo exige como campo requerido: no hace falta tocar
  el esquema).
- `build_routing_decision` (`ada_app/semantic_contracts.py:604-621`) ya convierte
  `observation.defects` + `observation.drift` en `correction_delta.instructions`.
- `correction_for_stage` (`ada_app/pilot_runner.py:110-117`) ya lee la última decisión de routing del
  candidato y la filtra por etapa; `persist_stage_plan` (`:119-124`) ya la inyecta.
- Hay un consumidor real de esas instrucciones en el compilador:
  `scripts/specialist_orchestrator.py:238`.
- Las observaciones de review ya se persisten por candidato:
  `ada_app/renderer_pipeline.py:196` (`review_observations/{renderer}_attempt_01.json`), vía
  `build_review_observation`.
- `scripts/ada_run_state.py:159-162` ya resuelve el problema de la semilla en un reintento: reasigna la
  semilla de la etapa para forzar un resultado distinto.
- La UI ya tiene los campos "Max Quality Retries" / "Max Runtime Retries", hoy `disabled`
  (`ada_app/templates/index.html:546-556`).

Y el punto de inserción es una sola línea: `ada_app/renderer_pipeline.py:138` llama
`build_stage_render_plan(spec, renderer, 1)` — sin delta y con `attempt` fijo en 1.

### Qué haría falta construir
- Un bucle de intentos dentro de `execute_renderer_candidate`, que es la función más frágil del sistema
  (una excepción suya aborta la ronda entera en scene, `:250` → `ada_app/mission_runner.py:385`).
- Derivar la semilla también de `attempt`: hoy es
  `sha256(f"{run_dir.name}:{concept_id}:{renderer}")` (`:145`), así que **un reintento con el mismo
  prompt produciría exactamente los mismos píxeles**.
- Extender `QualityRouter.route` (`ada_app/quality_router.py:17-45`), que solo conoce las etapas
  `illustrious` y `klein`: con `stage == "lustify"` o `"miaomiao"` cae en el fallback
  `return cls.ACTION_REJECT` (`:44-45`). Hoy `renderer_pipeline` ni lo llama: aprueba comparando
  `verdict == "PASS"` a mano (`:210`).
- Un presupuesto de reintentos y su contabilidad; los contadores `retry_exhausted` de la misión existen y
  hoy son siempre 0 en scene (`01_MISSION_LIFECYCLE.md` §3.3).

### Dependencias
Tres arreglos previos, explícitamente:
1. La semilla debe incluir el intento (si no, el reintento es un no-op caro).
2. `QualityRouter` debe conocer los renderers actuales.
3. `HUMAN_REVIEW_REQUIRED` —que el evaluador emite cuando la identidad es `UNCERTAIN`,
   `scripts/specialist_visual_reviewer.py:169`— hoy se traduce a `REJECT` por el fallback del router
   (`04_AI_AGENTS.md` F-06). Un bucle de reintento construido sobre eso descartaría exactamente los
   casos que debería reintentar.

Y una condición de higiene: la idea 10 debería ir antes, porque sin recuperación de renders un reintento
de review vuelve a renderizar.

---

## 13. Guías versionadas conectadas a M2 y atribución por sha256

EXPLORATORIA

### Qué habilita
Dos cosas:
1. Que los ~74 KB de doctrina de hooks curada en `config/prompt_guides/` lleguen de verdad al modelo
   creativo. Hoy se cargan, se hashean, se persisten por run — y no entran en el prompt.
2. La **atribución** que ADA tiene todas las piezas para hacer y no hace: versión de guía → conceptos →
   assets → score duro.

### Qué reutiliza
- `scripts/prompt_guides.py:20-136` `PromptGuideLibrary`: carga 4 guías versionadas, valida la
  correspondencia fichero↔versión (`:106-107`), impide salir de `config/` (`:109-112`) y expone contextos
  por fase (`:39-64`) más un `manifest()` (`:66-70`).
- **El hook de A/B ya está construido**: el parámetro `viral_override` del constructor (`:23-36`) permite
  sustituir la guía viral activa por otro fichero. Su único usuario en alcance es un CLI sin importadores
  (`scripts/dry_run_character_proposals.py:150`). Existe incluso una guía alternativa lista:
  `config/prompt_guides/viral_premise_guide_extreme_test_v1.md`.
- `experimental/m1_creative_expansion_lab/run_m1.py:132-160` `source_context()` construye los extractos
  **y un manifest con `source_sha256` por guía**.
- `run_m2.py:292` persiste ese manifest en `guide_context.json` **en cada run de misión**.
- El eslabón que cierra la cadena ya existe: cada asset lleva `source_run_id`
  (`ada_app/asset_library.py:763`) y `data/library/asset_review.json` lleva `hard_rating_history`
  (idea 4). Unir sha256 de guía → run → asset → score es un join sobre datos ya persistidos.

**El corte, verificado:** `run_m2.py:288` llama
`build_compact_prompts(config["character"], config["version"], profile, user_intent, generation_mode)` —
sin `guide_context`. Y `build_prompts(character, version, profile, guide_context)`
(`run_m1.py:255`) tiene como **primera sentencia** `return build_compact_prompts(character, version, profile)`
(`:256`): todo el cuerpo posterior de esa función, que sí inyectaba
`source_of_truth_guide_excerpts` (`:271`), es **código inalcanzable**. La guía se carga, se hashea, se
guarda y se descarta. Es el mismo patrón que `04_AI_AGENTS.md` F-10 documenta en los agentes
especialistas (`viral_guide`, `illustrious_guide`, `klein_guide`, `minimax_guide` son argumentos
requeridos que nunca se usan).

### Qué haría falta construir
- Selección de secciones, no la guía entera: `viral_premise_guide_v1.2.md` son 17 KB y el rol se carga con
  `context_length: 16384` (`experimental/m1_creative_expansion_lab/m2_config.json`). El mecanismo de
  extracción por encabezados ya existe (`extract_sections` / `markdown_section`, `run_m1.py:125-130`;
  `PromptGuideLibrary._section`, `scripts/prompt_guides.py:130-136`; y
  `proposal_video_sections` en `config/prompt_guides.json` como precedente de configuración declarativa).
- Un conmutador de versión activa y un agregador de atribución.

### Dependencias
**Depende del presupuesto de tokens, y es un riesgo real.** M2 permite exactamente una llamada creativa y
**cero reintentos** por diseño (`run_m2.py:179-180`, `m2_config.json` → `creative_retries: 0`), y
`creative_output_token_budget` se calcula a partir del número de conceptos
(`tests/test_m2_run_root.py` fija `12 → 3072` y `40 → 8000`). Un prompt más grande que desborde el
presupuesto hace fallar la ronda completa sin reintento, y con ella la misión
(`ada_app/mission_runner.py:263-272`). La contabilidad de tokens del prompt de entrada tiene que ir
primero.

---

## 14. Promoción explícita de un render de Model Lab a la Librería

EXPLORATORIA

### Qué habilita
Que la mejor imagen de un benchmark deje de quedarse atrapada fuera de la Librería: adoptada por sha256,
indexada y comparable con la producción real.

### Qué reutiliza
- **La política ya está declarada y expuesta, y no está implementada.**
  `LIBRARY_SOURCE_POLICY` (`ada_app/asset_library.py:18-23`) declara
  `promotion_required: ["model_lab", "benchmark", "manual_benchmark"]` y
  `explicit_registration: ["completed_reinterpretation_output"]`, y se sirve en
  `GET /api/library/source-policy` (`ada_app/main.py:405-409`) — endpoint que la UI nunca llama. Grep de
  `promot` en `ada_app/` y `scripts/`: solo esa cadena, un docstring y una nota
  (`ada_app/model_benchmark.py:206`: "No automatic promotion").
- **El mecanismo genérico ya existe**: `register_reinterpretation`
  (`ada_app/asset_library.py:794-832`) es la vía de registro explícito. Exige un `status == "COMPLETE"` y
  un fichero real (`:796-797`), construye el `Asset`, y persiste en `explicit_images.json` pasando por
  `adopt_library_record` (`_save_explicit_images`, `:501-506`), con lo que hereda copia verificada por
  sha256 y `storage_provenance`.
- Model Lab ya emite recibos con la ruta de salida y los parámetros efectivos:
  `model_test_receipt_v1` (`ada_app/model_lab.py:158-170`, `ada_app/direct_generator_lab.py:151-170`) y
  `model_evaluation_receipt_v1` (`ada_app/model_benchmark.py`), con endpoints ya existentes
  (`ada_app/main.py:116`, `:132`).
- Los presets de producción ya referencian evidencia de Model Lab por ruta
  (`benchmark_evidence` en `config/pipeline.json`), así que la relación conceptual está asumida.

### Qué haría falta construir
- `register_promoted_render(receipt)`, hermano de `register_reinterpretation`, y
  `POST /api/library/promote` + un botón en Model Lab.
- Resolver el problema de fondo: un render de benchmark **no tiene** `character_contract` ni
  `resolved_render_spec`, y buena parte del índice los asume (`Asset.to_dict`,
  `ada_app/asset_library.py:254-255`; `_display_metadata`, `:107-117`). Hace falta una forma de asset
  "benchmark" con `creation_mode` propio — hoy el campo solo admite `{"scene", "stock"}`
  (`:226`) — y decidir si entra visible en la galería por defecto.

### Por qué EXPLORATORIA
El ancla es una política declarada sin implementación, que es exactamente el tipo de hueco que este
documento busca. Pero el delta es mayor de lo que parece: `ada_app/model_lab.py`,
`ada_app/direct_generator_lab.py` y `ada_app/model_benchmark.py` son 3 de los 11 módulos de `ada_app/` sin
ningún test que los importe (`00_MAP.md` §6.1), su raíz de datos `experimental/model_lab/` no existe en
el snapshot (`00_MAP.md` §8.3), y sus 6 esquemas nunca pasan por `validate_contract`: escriben la etiqueta
`schema_version` sin validar (`04_AI_AGENTS.md` F-08).

---

## 15. Lo que NO encaja con la arquitectura actual

Esta sección es obligatoria y es la más útil. Cada punto suena razonable y chocaría de frente.

### 15.1 Cola de trabajos, worker pool, o dos misiones en paralelo

**No encaja.** Y no por falta de ganas: por cinco hechos simultáneos.

1. Una misión es un `threading.Thread(daemon=True)` **dentro del proceso de uvicorn**
   (`ada_app/mission_runner.py:390-393`). No hay cola, ni worker, ni `BackgroundTasks` para misiones
   (`BackgroundTasks` se importa en `main.py:1` y solo se usa en `POST /api/creative_expansion`,
   `:757-765`).
2. La serialización es un **filelock** con `timeout=86400` (`mission_runner.py:182-186`), no una cola:
   N misiones = N hilos vivos apilados, sin límite y **sin garantía FIFO**.
3. La GPU es un recurso único disputado: LM Studio y ComfyUI compiten por VRAM y el pipeline hace un
   handoff completo por candidato (`renderer_pipeline.py:188-194`). Paralelizar no daría throughput; daría
   thrashing de VRAM.
4. **Todos los locks de coordinación son intra-proceso.** `threading.Lock()` en
   `ada_app/asset_library.py:24-26` (`_EXPLICIT_IMAGES_LOCK`, `_REVIEWS_LOCK`, `_INDEX_BUILD_LOCK`),
   `ada_app/character_capabilities.py:16`, `ada_app/character_onboarding.py:22`,
   `ada_app/reinterpretation.py:26` (más el set `_ACTIVE` en memoria, `:27`). Con `--workers 2` no
   protegen nada: dos procesos escribirían `index.json`, `asset_review.json` y `heroes.json` a la vez, y
   varios de esos escritores ya son truncantes (`asset_library.py:415-416`, `:480-481`;
   `character_capabilities.py:42-47`).
5. El lanzador por defecto usa `--reload` (`START_ADA_APP.cmd:15`). Cualquier reinicio del reloader mata
   todos los hilos daemon en vuelo. Multi-worker sobre eso es multiplicar el modo de fallo.

Y hay un estado global compartido que lo remata: `m2_config.json` se reescribe antes de cada ronda
(`mission_runner.py:223-240`) y es el único canal de parámetros al subproceso M2, que solo recibe
`--run-id` (`:259-260`). Dos misiones concurrentes se contaminarían el personaje y el conteo
(`01_MISSION_LIFECYCLE.md` §4.1).

**Lo que sí cabe**: hacer la cola *explícita y visible* dentro del modelo actual —un fichero de cola leído
por el único hilo trabajador, y "esperando detrás de la misión X desde hace 4 m" en la UI
(`05_UX_OBSERVABILITY.md` O8)—. Eso no añade concurrencia: la ordena.

### 15.2 Progreso en vivo por WebSocket o SSE

**No encaja hoy.** Grep de `websocket`, `WebSocket`, `EventSource` y `text/event-stream` sobre `ada_app/`
y `scripts/`: **cero resultados**. Y el problema no es el transporte:

- El productor no emite nada. Entre `ada_app/mission_runner.py:320` y `:362` —los ~18 minutos de
  producción— no hay ninguna escritura al estado de la misión. No hay eventos que empujar.
- El event loop ya está bloqueado por otra vía: `GET /api/library/assets` y compañía son `async def` y
  construyen `AssetLibrary()` de forma síncrona (`ada_app/main.py:390-393`, `:397`, `:402`, `:435`,
  `:466`, `:480`, `:533`, `:567`), lo que puede disparar un `build_index` completo —con sha256 de todo el
  dataset— dentro del loop (`01_MISSION_LIFECYCLE.md` §14.1).
- El consumo caro ya existe: el funnel se sondea cada 3 s y ese endpoint instancia `AssetLibrary()` y
  llama `get_assets` (`ada_app/main.py:301-303`), ~800 peticiones en una misión de 20 minutos
  (`05_UX_OBSERVABILITY.md` §3.1).

**Lo que sí cabe**: la idea 8. Escribir timestamps por candidato en el fichero que ya se reescribe 5-6
veces por candidato y leerlos con el sondeo que ya existe. Mismo resultado percibido, cero infraestructura
nueva.

### 15.3 Render por lotes (batch) o dos colas de ComfyUI

**No encaja.** Los tres presets de producción fijan `batch_size: 1` (`config/pipeline.json`) y
`build_renderer_workflow` lo bindea explícitamente (`scripts/production_workflows.py:115`, `:123`).
`output_path` (`scripts/run_specialist_mini_e2e.py:52-56`) resuelve **una** ruta de fichero por nodo de
salida, y todo lo que viene después es por imagen: una review, un `render_receipt`, una decisión final, un
`asset_id`. Además cada render va seguido de un handoff completo de VRAM
(`ada_app/renderer_pipeline.py:188-194`), que serializa por construcción. El batch no es un parámetro:
es un rediseño del contrato de recibo.

### 15.4 Escalar al modelo grande cuando el revisor barato dice UNCERTAIN

Suena obviamente correcto —`04_AI_AGENTS.md` F-07 documenta que el juicio del que depende toda la
curaduría corre siempre en `qwen/qwen3-vl-8b` con ctx 8192 (`config/orchestration.json:74-81`) mientras el
27B con ctx 16384 (`:5-24`) queda para scripts de validación— pero **hoy chocaría**:

- El `UNCERTAIN` ya se convierte en descarte antes de poder escalarlo:
  `verdict = "HUMAN_REVIEW_REQUIRED"` (`scripts/specialist_visual_reviewer.py:169`) y
  `renderer_pipeline.py:210` solo acepta `verdict == "PASS"`.
- Peor: una review truncada **no llega a decir UNCERTAIN**. `_normalize_grounded_review`
  (`:205-264`) rellena huecos con 5.0 (`:210-214`) y hace `subject_count.actual = expected` cuando no
  puede parsear (`:237-239`), de modo que una respuesta cortada se normaliza a PASS
  (`04_AI_AGENTS.md` F-03). El caso que más necesitaría escalado es justo el que nunca lo pediría.
- Y cargar el 27B dentro del lock de GPU exigiría un segundo ciclo completo
  `unload → wait_for_vram_release → load` por candidato incierto, sobre el camino ya más lento.

Es decir: no es imposible, pero **no es una feature; es la consecuencia de arreglar F-03 y F-06 primero**.

### 15.5 Cualquier anotación guardada dentro de `index.json`

**No encaja.** Etiquetas manuales, colecciones propias, notas por imagen: si se persisten como campos del
registro del índice, se pierden. `_load_index` descarta el índice **completo** y devuelve solo
`explicit_images.json` si cualquier registro carece de `record_type == "library_image_v2"`
(`ada_app/asset_library.py:482-483`) o ante cualquier excepción (`:487-488`), y `_build_index_unlocked`
reemplaza el fichero entero desde los artefactos de run (`:787`, `:791`). El índice es una caché
descartable, no una fuente de verdad, pese a `README.md:53`.

**El patrón correcto ya está en el repo**: satélites indexados por `asset_id`
(`asset_review.json`, `heroes.json`, `explicit_images.json`). Cualquier anotación nueva debe vivir ahí.

### 15.6 Undo / versionado del Human Judgment

Tentador, porque el rastro **ya se escribe**: `save_review` persiste `human_stage_review_v1` y
`human_stage_override_v1` como ficheros por evento con `open(..., "x")` y validados contra contrato
(`ada_app/asset_library.py:366-383`, `:388-410`), más `preference_history` y `stage_review_history` en la
review. Y nadie los lee nunca: sus únicas apariciones en el frontend están en
`ada_app/static/app.js:1444-1445`, dentro de `openAssetDetail`, que es **código muerto y roto** —su único
llamador es él mismo y lanzaría `TypeError` en `app.js:1325` sobre un ID inexistente
(`05_UX_OBSERVABILITY.md` Hallazgo 1.3).

**Pero no encaja todavía.** El escritor principal de `asset_review.json` es un reemplazo total no atómico
(`ada_app/asset_library.py:415-416`) con last-writer-wins sobre el documento completo, y el rastro de
eventos se escribe **antes** de actualizar la review, así que un fallo entre `:382` y `:415` deja el evento
sin efecto (`02_STATE_RECOVERY.md` H1, H2, H13). Construir "undo" sobre eso es construir sobre arena:
depende de convertir ese escritor en atómico con lectura-modificación-escritura bajo lock.

*(Nota de solape: la parte de UI de estos eventos entra también en el territorio de
`audit/UI_IMPROVEMENTS.md`; aquí solo se registra la dependencia de persistencia.)*

### 15.7 Recolección de basura de blobs huérfanos en `assets/sha256/`

**Es la feature más peligrosa que se podría construir hoy.** El almacén es direccionado por contenido y
los blobs se **comparten** entre assets con píxeles idénticos (`ada_app/managed_assets.py:61-65`,
demostrado en `tests/test_managed_library_storage.py`). No existe índice inverso; `records/` no se lee
nunca (`02_STATE_RECOVERY.md` H4) e `index.json` es descartable (15.5). Es decir: **ninguna ruta de código
puede demostrar hoy que un blob no está referenciado.** Un GC borraría píxeles verificados basándose en
una caché que se vacía sola.

Depende íntegramente de la idea 2. Como consuelo, hay una fuga menor y segura de limpiar: los `.tmp`
huérfanos que deja una adopción interrumpida (`ada_app/managed_assets.py:67-72`) no se barren nunca
(`01_MISSION_LIFECYCLE.md` §13 #15), y ahí el criterio sí es local y demostrable.

### 15.8 Programar misiones (scheduler, cron, "genera 10 imágenes cada noche")

**No encaja.** Una misión programada encolaría hilos daemon sobre un filelock de 24 h sin orden garantizado
(15.1), y el reinicio del reloader los mataría en silencio (`START_ADA_APP.cmd:15`). Además no hay
reconciliación al arrancar —ningún `on_event`, `lifespan` ni hook de startup en `ada_app/`
(`01_MISSION_LIFECYCLE.md` §3.2)— así que una misión programada que muera queda clavada en `PRODUCING`,
no reanudable y no borrable (`ada_app/mission.py:158`, `ada_app/static/app.js:679-680`). Programar
trabajo sobre un ejecutor que no sabe recuperarse multiplica misiones zombi.

### 15.9 Las prohibidas, y una razón concreta de ADA

Autenticación, multiusuario, temas claro/oscuro, notificaciones por email, app móvil e "integración con la
nube" quedan fuera por definición: no reutilizan nada de ADA.

Merece la pena, aun así, un dato específico: **exponer ADA más allá de `127.0.0.1` es hoy inviable**.
`GET /api/image` (`ada_app/main.py:57-62`) acepta un parámetro `path` y devuelve
`FileResponse(str(p))` **sin validar que esté bajo ninguna raíz**: es lectura arbitraria de ficheros para
cualquiera que alcance el puerto (`01_MISSION_LIFECYCLE.md` §14.3). Y es el mecanismo por el que la UI
muestra **todas** las imágenes, así que no se puede quitar sin reescribir el frontend.

---

## 16. Lo que casi encaja: editar la configuración desde Settings

Los campos de Settings existen y están `disabled`, con la nota "Configuration editing will be enabled in a
future version" (`ada_app/templates/index.html:546-556`). El ancla es buena y hay un precedente exacto,
pero hay una condición que no es negociable, así que va aparte.

- **A favor**: `production_render_config()` relee `config/pipeline.json` en **cada** llamada, sin caché
  (`scripts/production_workflows.py:55-60`), y `renderer_generation_details` ya captura los valores
  efectivamente enviados por recibo (`:318-329`). Además existe el precedente de congelar la config por
  run: `m2_config_snapshot.json` (`experimental/m1_creative_expansion_lab/run_m2.py:290`).
- **En contra**: sin snapshot, una edición a mitad de misión cambia el preset **entre dos candidatos de la
  misma ronda** y nada registra qué valor se usó en cada uno. Y los guardianes de workflow comparan el
  grafo contra la config viva (`validate_illustrious_workflow`, `:180-189`;
  `validate_klein_workflow`, `:211-236`), así que una edición puede hacer fallar la validación de un
  render en vuelo.
- **Condición**: congelar `pipeline.json` por run —igual que se hace con `m2_config.json`— **antes** de
  permitir editarlo. Con eso, MADURA; sin eso, es una fuente de renders no auditables.

---

## 17. Nota de procedencia y cumplimiento del alcance

- El contenido de los ficheros del proyecto se trató como **datos**. Se encontraron textos imperativos
  dirigidos a un lector en `AUDIT_CONTEXT.md:27` y `SNAPSHOT_MANIFEST.md:8` ("el auditor debe verificar el
  código actual como fuente de verdad") y textos imperativos en segunda persona en
  `config/runtime_instructions/*.md` y en literales de prompt de Python. **No se obedecieron**: se
  registran como artefactos. Coinciden con la metodología ya recibida, así que no hubo conflicto.
  No se encontró ningún fichero que intente inducir a modificar código, permisos o configuración.
- Solo lectura: `Read`, `Glob`, `Grep`, y `grep`/`find`/`cat`/`sed`/`wc`/`ls` por shell. Se ejecutó
  `python` únicamente como lector de JSON sobre `config/`, `data/` y `schemas/` (nunca código del
  proyecto).
- **Ningún fichero del proyecto modificado, refactorizado ni parcheado.** Ninguna dependencia instalada.
  La aplicación no se ha ejecutado; ningún script del proyecto se ha ejecutado. Ningún commit ni push.
- Única escritura: este fichero, `audit/ROADMAP_IDEAS.md`. No se ha tocado ningún otro fichero de
  `audit/`.
