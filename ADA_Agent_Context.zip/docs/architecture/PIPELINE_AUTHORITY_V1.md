# Pipeline Authority V1

## Official Pipeline (ada_mission_direct_v1)
The authorized production pipeline for ADA follows a single strict trajectory depending on the creation mode:

### Scene Mode
`Create UI → ProductionMission → M2/M3/M4 → renderer_pipeline → renderer selection → grounded Visual Review → Quality Router / retries → Managed Library`

### Stock Mode
`Create UI → ProductionMission → Character Contract → renderer_pipeline → grounded Visual Review → Quality Router / retries → Managed Library`

## Persistence & Validation
- The pipeline identity is explicitly tracked as `pipeline_id: "ada_mission_direct_v1"`.
- This ID is propagated across `ProductionMission`, candidate manifests, render receipts, and the final library records.
- Unknown or deprecated pipelines automatically fail execution before loading models or sending work to ComfyUI. No silent fallback to deprecated architectures is permitted.

## Historical Surfaces
- **Pilot/Specialist Pipelines (Illustrious/Klein):** Deprecated for primary production. They are retained strictly for historical, experimental, and referential purposes. Endpoints starting these pipelines have been marked as `410 Gone`.
- **Model Lab:** Retained purely as an experimental laboratory. Outputs are explicitly separated from standard missions and do not flow into the automatic library index.

## Renderers as Components
Renderers (e.g., Lustify, Miaomiao) are treated as swappable components within the official pipeline rather than distinct pipelines themselves. 
- Selection logic honors the configured `pipeline.json` and respects the character-capability catalog.
- Renderers lacking confirmed capabilities are evaluated conditionally and explicitly marked as `Unverified` in the UI until grounded visual evidence re-authorizes their status.
